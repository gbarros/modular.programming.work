#if ! defined( JOGO_ )
#define JOGO_
/**********************************************************************************************************
*
*  -> M�dulo de defini��o: JOG M�dulo jogo que implementa uma partida de Jogo de Damas
*
*  Arquivo gerado: JOGO.h
*  Letras identificadoras: JOG
*
*  Autores: tr - Tadeu Ribeiro
*			ag - Alexandre Garcia
*			jc - Jocimar Candido
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      tr, al, jc   18/set/2012    in�cio do desenvolvimento
*      1.1      tr, al, jc   02/nov/2012    revis�o e modifica��o das explica��es, assertivas e dos prot�tipos das fun��es
*
*  -> Descri��o do m�dulo:
*     Este m�dulo implementa um conjunto de fun��es que utilizam m�dulos gen�ricos de pe�a e tabuleiro, 
*     para manipular um Jogo de Damas completo entre duas pessoas seguindo as regras oficiais 
*     preestabelecidas de tal jogo. 
*     
**********************************************************************************************************/

#if defined( JOGO_OWN )
   #define JOGO_EXT
#else
   #define JOGO_EXT extern
#endif

/***** Declara��es exportadas pelo m�dulo *****/

/* Tipo refer�ncia para um jogo (partida) */

typedef struct JOG_tagJogo * JOG_tppJogo ;

/***********************************************************************
*
*  Tipo de dados: JOG Condi��es de retorno
*
*  Descri��o do tipo:
*     Condi��es de retorno das fun��es do jogo
*
*  Fun��es por N�mero:      
*        IniciarPartida      = 1 
*        PreencherTabuleiro  = 2 
*        MoverPeca           = 3 
*        VerificarMovimento  = 4 
*        VerificarCaptura    = 5 
*        ContarPontos        = 6 
*        SolicitarAcao       = 7 
*        GerenciarEmpate     = 8 
*        FinalizarPartida    = 9 
*
***********************************************************************/


   typedef enum {

        JOG_CondRetOK = 0 ,
        /* Concluiu corretamente */
		/* Fun��es que utilizam : 1, 2, 3, 4, 5, 6, 7, 8, 9 */

		JOG_CondRetErroJogo = 1 ,
        /* Erro ao chamar uma fun��o do m�dulo Jogo */
		/* Fun��es que utilizam : 9 */

		JOG_CondRetErroPeca = 2 ,
		/* Erro ao chamar uma fun��o do m�dulo Pe�a */
	    /* Fun��es que utilizam : 2, 3 */

		JOG_CondRetErroTabuleiro = 3 ,
		/* Erro ao chamar uma fun��o do m�dulo Tabuleiro */
		/* Fun��es que utilizam : 1, 2, 3, 4, 5, 7 */

		JOG_CondRetMovimentoErrado = 4 ,
		/* Erro no movimento de uma pe�a */
	    /* Fun��es que utilizam : 4 */

		JOG_CondRetNaoExisteCapturaPossivel = 5,
		/* Caso em que nao existe captura possivel */
		/* Fun��es que utilizam : 5 */

		JOG_CondRetJogoEmpatado = 6,
		/* Caso o jogo termine em empate por 20 jogadas sucessivas sem captura */
		/* Fun��es que utilizam : 7, 8 */

		JOG_CondRetSolicitarEmpate = 7,
		/* Resposta "Sim" para a opcao Solcitar Empate */
		/* Fun��es que utilizam : 7 */

		JOG_CondRetSolicitarFim = 8,
		/* Resposta "Sim" para a opcao Solcitar Encerramento da Partida */
		/* Fun��es que utilizam : 7 */

		JOG_CondRetSair = 9
		/* Sair do Jogo */
		/* Fun��es que utilizam : 7 */

   } JOG_tpCondRet ;


/***********************************************************************
*
*  -> Fun��o: JOG Iniciar Partida
*
*  -> Descri��o da fun��o:
*     Inicializa uma partida criando todas as condi��es necess�rias para 
*     o in�cio do jogo.
*
*  -> Valor retornado:
*     JOG_CondRetOK
*     JOG_CondRetErroTabuleiro
*
*  -> Assertivas:
*	  Entrada - N�o h�. (void)
*
*     Sa�da - Retorna a partida inicializada com o tabuleiro preenchido e
*     o menu de a��es exibido para o primeiro jogador.
*
***********************************************************************/

JOG_tpCondRet JOG_IniciarPartida (void) ;

/***********************************************************************
*
*  -> Fun��o: JOG Preencher Tabuleiro
*
*  -> Descri��o da fun��o:
*     Preenche um tabuleiro virgem com pe�as conforme o jogo de damas.
*     (essa fun��o � chamada somente ao iniciar uma partida)
*
*  -> Par�metros:
*	  Tab		  - Ponteiro para o tabuleiro.
*
*  -> Valor retornado:
*     JOG_CondRetOK
*	  JOG_CondRetErroPeca
*     JOG_CondRetErroTabuleiro
*
*  -> Assertivas:
*	  Entrada - Recebe um tabuleiro, por refer�ncia, a ser preenchido.
*
*     Sa�da - Retorna o tabuleiro preenchido conforme as regras do Jogo de Damas.
*
***********************************************************************/

JOG_tpCondRet JOG_PreencherTabuleiro (TAB_tppTabuleiro * Tab) ;

/***********************************************************************
*
*  -> Fun��o: JOG Mover Peca
*
*  -> Descri��o da fun��o:
*     Efetua o movimento de uma pe�a no tabuleiro.
*
*  -> Par�metros:
*	  Tab		         - Ponteiro para o tabuleiro.
*     CoordLinhaIncial   - Coordenada x (linha) inicial da pe�a.
*     CoordColunaIncial  - Coordenada y (coluna) inicial da pe�a.
*     CoordLinhaFinal    - Coordenada x (linha) de destino da pe�a.
*     CoordColunaFinal   - Coordenada y (coluna) de destino da pe�a.
*
*  -> Valor retornado:
*     JOG_CondRetOK
*	  JOG_CondRetErroPeca
*     JOG_CondRetErroTabuleiro
*
*  -> Assertivas:
*	  Entrada - Recebe o tabuleiro, por refer�ncia, e as coordenadas linha 
*     e coluna atuais e de destino da pe�a a ser movida.
*
*     Sa�da - Retorna o tabuleiro, por refer�ncia, com a pe�a movida de lugar
*     ou n�o conforme as regras do Jogo de Damas. Caso n�o mova, retorna a
*     condi��o de retorno esperada.
*
***********************************************************************/

JOG_tpCondRet JOG_MoverPeca (TAB_tppTabuleiro * Tab, int CoordLinhaInicial, 
	                    int CoordColunaInicial, int CoordLinhaFinal, int CoordColunaFinal) ;

/***********************************************************************
*
*  -> Fun��o: JOG Verificar Movimento
*
*  -> Descri��o da fun��o:
*     Verifica se o movimento requerido � v�lido conforme as regras do jogo de damas.
*
*  -> Par�metros:
*	  Tab		         - Ponteiro para o tabuleiro.
*     CoordLinhaIncial   - Coordenada x (linha) inicial da pe�a.
*     CoordColunaIncial  - Coordenada y (coluna) inicial da pe�a.
*     CoordLinhaFinal    - Coordenada x (linha) de destino da pe�a.
*     CoordColunaFinal   - Coordenada y (coluna) de destino da pe�a.
*
*  -> Valor retornado:
*     JOG_CondRetOK
*	  JOG_CondRetMovimentoErrado
*     JOG_CondRetErroTabuleiro
*
*  -> Assertivas:
*	  Entrada - Recebe o tabuleiro, por refer�ncia, as coordenadas linha 
*     e coluna atuais e de destino da pe�a a ser movida para verificar a corretude
*     do movimento da mesma conforme nas regras do Jogo de Damas.
*
*     Sa�da - Retorna as condi��es de retorno correspondentes a verifica��o
*     se o movimente que se deseja realizar est� correto ou n�o conforme as
*     regras do Jogo de Damas.
*
***********************************************************************/

JOG_tpCondRet JOG_VerificarMovimento (TAB_tppTabuleiro * Tab, int CoordLinhaInicial, 
	                             int CoordColunaInicial, int CoordLinhaFinal, int CoordColunaFinal) ;

/***********************************************************************
*
*  -> Fun��o: JOG Verificar Captura
*
*  -> Descri��o da fun��o:
*     Ir� verificar se h� alguma pe�a ou pe�as a serem capturadas (pois pode ser 
*     captura simples ou em cadeia) de tal forma a obrigar o movimento de captura 
*     conforme as regras do jogo.
*
*  -> Par�metros:
*	  Tab		         - Ponteiro para o tabuleiro.
*     CoordLinhaIncial   - Coordenada x (linha) inicial da pe�a.
*     CoordColunaIncial  - Coordenada y (coluna) inicial da pe�a.
*
*  -> Valor retornado:
*     JOG_CondRetOK
*	  JOG_CondRetNaoExisteCapturaPossivel
*     JOG_CondRetErroTabuleiro
*
*  -> Assertivas:
*	  Entrada - Recebe o tabuleiro, por refer�ncia, e as coordenadas linha 
*     e coluna da pe�a a ser movida para verificar se h� possibilidades de 
*     captura em torno da mesma.
*
*     Sa�da - Retorna as condi��es de retorno correspondente ao existir ou n�o
*     a possibilidade de captura na jogada.
*
***********************************************************************/

JOG_tpCondRet JOG_VerificarCaptura (TAB_tppTabuleiro * Tab, int CoordLinhaInicial, int CoordColunaInicial) ;

/***********************************************************************
*
*  -> Fun��o: JOG Contar Pontos
*
*  -> Descri��o da fun��o:
*     Conta os pontos de cada jogador a cada jogada. Os pontos nada mais s�o 
*     do que a quantidade de pe�as que um jogador capturou do advers�rio.
*
*  -> Par�metros:
*	  Jogo            - Ponteiro para o jogo (partida).
*
*  -> Valor retornado:
*     JOG_CondRetOK
*	  JOG_CondRetJogoInexistente
*
*  -> Assertivas:
*	  Entrada - N�o h�. (void)
*
*     Sa�da - Retorna o placar atual da partida.
*
***********************************************************************/

JOG_tpCondRet JOG_ContarPontos (void) ;

/***********************************************************************
*
*  -> Fun��o: JOG Solicitar Acao
*
*  -> Descri��o da fun��o:
*     Menu do jogo onde o jogador dever� digitar o n�mero da op��o que 
*     corresponde a a��o que o mesmo deseja fazer. As op��es s�o:
*     1 � Mover Peca
*     2 � Solicitar Empate
*     3 � Solicitar Encerramento da Partida
*     4 � Sair do Jogo
*
*  -> Valor retornado:
*     JOG_CondRetOK
*     JOG_CondRetSolicitarEmpate
*     JOG_CondRetSolicitarFim
*     JOG_CondRetSair
*     JOG_CondRetJogoEmpatado
*     JOG_CondRetErroTabuleiro
*
*  -> Assertivas:
*	  Entrada - Recebe o par�metro do tipo ponteiro para a fun��o JOG_GerenciarEmpate. 
*
*     Sa�da - Retorna as condi��es de retorno esperadas com base nas a��es de cada 
*     op��o escolhida.
*
***********************************************************************/

JOG_tpCondRet JOG_SolicitarAcao (JOG_tpCondRet (*GerenciarEmpate)(void)) ;

/***********************************************************************
*
*  -> Fun��o: JOG Gerenciar Empate
*
*  -> Descri��o da fun��o:
*     Gerencia o n�mero de lances sem captura de pe�a para verificar se ocorreram 
*     20 lances consecutivos sem captura. Caso isso ocorra, a fun��o chamar� o fim
*     da partida relatando um empate.
*
*  -> Valor retornado:
*     JOG_CondRetOK
*     JOG_CondRetJogoEmpatado
*
*  -> Assertivas:
*	  Entrada - N�o h�. (void)
*
*     Sa�da - Caso o n�mero de jogadas sucessivas sem captura seja igual a 20, ir� retornar
*     a condi��o de retorno esperada e exibir o empate. Caso contr�rio continua a partida.
*
***********************************************************************/

JOG_tpCondRet JOG_GerenciarEmpate (void) ;

/***********************************************************************
*
*  -> Fun��o: JOG Finalizar Partida
*
*  -> Descri��o da fun��o:
*     Esta fun��o ir� finalizar a partida. (housekeeping)
*
*  -> Valor retornado:
*     JOG_CondRetOK
*     JOG_CondRetErroJogo
*
*  -> Assertivas:
*	  Entrada - N�o h�. (void)
*
*     Sa�da - Toda mem�ria alocada e utilizada pelas estruturas da aplica��o
*     sendo liberada.
*
***********************************************************************/

JOG_tpCondRet JOG_FinalizarPartida (void) ;


#undef JOGO_EXT

/********** Fim do m�dulo de defini��o: JOG Jogo de Damas **********/

#else
#endif
