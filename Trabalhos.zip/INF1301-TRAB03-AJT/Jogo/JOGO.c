/**********************************************************************************************************
*
*  -> M�dulo de implementa��o: JOG M�dulo jogo que implementa uma partida de Jogo de Damas
*
*  Arquivo gerado: JOGO.c
*  Letras identificadoras: JOG
*
*  Autores: tr - Tadeu Ribeiro
*			ag - Alexandre Garcia
*			jc - Jocimar Candido
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      tr, al, jc   09/out/2012    in�cio do desenvolvimento
*      1.1      tr, al, jc   02/nov/2012    criando as fun��es e alterando estruturas
*      1.2      tr, al, jc   04/nov/2012    revis�o e modifica��o das explica��es, assertivas e dos prot�tipos das fun��es
*
*  -> Descri��o do m�dulo:
*     Este m�dulo implementa um conjunto de fun��es que utilizam m�dulos gen�ricos de pe�a e tabuleiro, 
*     para manipular um Jogo de Damas completo entre duas pessoas seguindo as regras oficiais 
*     preestabelecidas de tal jogo. 
*     
**********************************************************************************************************/

#include   <stdlib.h>
#include   <stdio.h>
#include   <string.h>
#include   <memory.h>
#include   <malloc.h>
#include   <assert.h>

#include   "PECA1.h"
#include   "TABULEIRO.h"
#include   "JOGO.h"

/***********************************************************************
*
*  Tipo de dados: JOG Estrutura de um jogo
*
***********************************************************************/

typedef struct JOG_tagJogo{
	
	char NomeJogadorBranco [11];

	char NomeJogadorPreto [11];

	char * NomeJogadorAtual;

	int codJogadorAtual;

	int pontosJogadorBranco;

	int pontosJogadorPreto;

	int numJogadasSemCaptura;
	
}JOG_tpJogo;


JOG_tpJogo pJogo;

TAB_tppTabuleiro pTab = NULL;

PEC_tppPeca  pPeca = NULL;

/*****  C�digo das fun��es exportadas pelo m�dulo  *****/


//deve ser excluido depois!!!!!!!
JOG_tpCondRet JOG_PreencherTabuleiro2 (TAB_tppTabuleiro * Tab)
{
	JOG_tpCondRet retJOG = JOG_CondRetOK;
	TAB_tpCondRet retTAB = TAB_CondRetOK;
	PEC_tpCondRet retPEC = PEC_CondRetOK;
	
	//cria um tabuleiro novo para o jogo de damas
	retTAB = TAB_CriarTabuleiro (&pTab, 8, 8);
	//trata erro gerado pela funcao TAB_CriarTabuleiro
	if (retTAB != TAB_CondRetOK)
	{
		printf("\nOcorreu o erro %d ao criar um tabuleiro para o jogo\n", retTAB);
		retJOG = JOG_CondRetErroTabuleiro;
	}//fim do if que trata erro gerado pela funcao TAB_CriarTabuleiro

	//cria um peao branco novo para ser colocado no tabuleiro
	retPEC = PEC_CriarPeca ( &pPeca, PEC_NomePeao, PEC_CorBranca, 'b');
	//trata erro gerado pela funcao PEC_CriarPeca
	if (retPEC != PEC_CondRetOK)
	{
		printf("\nOcorreu o erro %d ao criar uma peca\n", retPEC);
		retJOG = JOG_CondRetErroPeca;
	}//fim do if que trata erro gerado pela funcao PEC_CriarPeca

	//coloca o peao na posicao
	retTAB = TAB_InserirPeca(&pTab, &pPeca, 2, 7);
	//trata erro gerado pela funcao TAB_InserirPeca
	if (retTAB != TAB_CondRetOK)
	{
		printf("\nOcorreu o erro %d ao inserir uma peca no tabuleiro\n", retTAB);
		retJOG = JOG_CondRetErroTabuleiro;
	}//fim do if que trata erro gerado pela funcao TAB_InserirPeca
	//limpa o ponteiro de peca
	pPeca = NULL;

	//cria um peao preto novo para ser colocado no tabuleiro
	retPEC = PEC_CriarPeca ( &pPeca, PEC_NomePeao, PEC_CorPreta, 'p');
	//trata erro gerado pela funcao PEC_CriarPeca
	if (retPEC != PEC_CondRetOK)
	{
		printf("\nOcorreu o erro %d ao criar uma peca\n", retPEC);
		retJOG = JOG_CondRetErroPeca;
	}//fim do if que trata erro gerado pela funcao PEC_CriarPeca

	//coloca o peao na posicao
	retTAB = TAB_InserirPeca(&pTab, &pPeca, 1, 6);
	//trata erro gerado pela funcao TAB_InserirPeca
	if (retTAB != TAB_CondRetOK)
	{
		printf("\nOcorreu o erro %d ao inserir uma peca no tabuleiro\n", retTAB);
		retJOG = JOG_CondRetErroTabuleiro;
	}//fim do if que trata erro gerado pela funcao TAB_InserirPeca
	//limpa o ponteiro de peca
	pPeca = NULL;

	//cria um peao preto novo para ser colocado no tabuleiro
	retPEC = PEC_CriarPeca ( &pPeca, PEC_NomePeao, PEC_CorPreta, 'p');
	//trata erro gerado pela funcao PEC_CriarPeca
	if (retPEC != PEC_CondRetOK)
	{
		printf("\nOcorreu o erro %d ao criar uma peca\n", retPEC);
		retJOG = JOG_CondRetErroPeca;
	}//fim do if que trata erro gerado pela funcao PEC_CriarPeca

	//coloca o peao na posicao
	retTAB = TAB_InserirPeca(&pTab, &pPeca, 3, 6);
	//trata erro gerado pela funcao TAB_InserirPeca
	if (retTAB != TAB_CondRetOK)
	{
		printf("\nOcorreu o erro %d ao inserir uma peca no tabuleiro\n", retTAB);
		retJOG = JOG_CondRetErroTabuleiro;
	}//fim do if que trata erro gerado pela funcao TAB_InserirPeca
	//limpa o ponteiro de peca
	pPeca = NULL;

	//cria um peao preto novo para ser colocado no tabuleiro
	retPEC = PEC_CriarPeca ( &pPeca, PEC_NomePeao, PEC_CorPreta, 'p');
	//trata erro gerado pela funcao PEC_CriarPeca
	if (retPEC != PEC_CondRetOK)
	{
		printf("\nOcorreu o erro %d ao criar uma peca\n", retPEC);
		retJOG = JOG_CondRetErroPeca;
	}//fim do if que trata erro gerado pela funcao PEC_CriarPeca

	//coloca o peao na posicao
	retTAB = TAB_InserirPeca(&pTab, &pPeca, 5, 4);
	//trata erro gerado pela funcao TAB_InserirPeca
	if (retTAB != TAB_CondRetOK)
	{
		printf("\nOcorreu o erro %d ao inserir uma peca no tabuleiro\n", retTAB);
		retJOG = JOG_CondRetErroTabuleiro;
	}//fim do if que trata erro gerado pela funcao TAB_InserirPeca
	//limpa o ponteiro de peca
	pPeca = NULL;



}



/***********************************************************************
*
*  Fun��o: JOG Iniciar Partida
*
***********************************************************************/

JOG_tpCondRet JOG_IniciarPartida (void)
{
	JOG_tpCondRet retJOG = JOG_CondRetOK;
	TAB_tpCondRet retTAB = TAB_CondRetOK;
	
	//variaveis utilisatadas no metodo utilizado para capturar uma string de stdin evitando buffer overflow
	char * posicaoEnter = NULL;
	int c = 0;

	//inicializa o numero de jogadas sem captura para zero
	pJogo.numJogadasSemCaptura=0;
	
	//inicializa o codigo do jogador atual como sendo o jogador branco
	pJogo.codJogadorAtual = 0;
	
	printf("------------------------------------------------------------------\n");
	printf("                    BEM VINDO AO JOGO DE DAMAS                    \n");
	printf("------------------------------------------------------------------\n\n");
	printf("Para iniciar o jogo, insira o nome dos jogadores...\n\n");
	printf("OBS: O jogador 1 controla as pecas brancas e inicia a partida.\n");
	printf("OBS: O jogador 2 controla as pecas pretas.\n\n");
	printf(">>> Nome do Jogador 1 (branco): ");
	//metodo utilizado para capturar uma string de stdin evitando buffer overflow 
	if (fgets(pJogo.NomeJogadorBranco, 11, stdin) != NULL)
	{
		//troca o simbolo de "enter" por simbolo de fim de string
		posicaoEnter = strchr(pJogo.NomeJogadorBranco, '\n');
		if (posicaoEnter != NULL)
		{
			*posicaoEnter = '\0';
		}//fim do if que troca os simbolos
		//limpa o buffer de stdin
		else
		{
			while (c != '\n' && c != EOF)
			{
				c = getchar();
			}
		}
	}
	//caso onde ocorreu erro de leitura, limpa o buffer de stdin
	else
	{
		while (c != '\n' && c != EOF)
			{
				c = getchar();
			}
		printf("\n\nERRO!!! Problema ao ler a string\n");
	}//fim do metodo utilizado para capturar uma string de stdin evitando buffer overflow
	
	printf(">>> Nome do Jogador 2 (preto): ");
	//metodo utilizado para capturar uma string de stdin evitando buffer overflow
	if (fgets(pJogo.NomeJogadorPreto, 11, stdin) != NULL)
	{
		//troca o simbolo de "enter" por simbolo de fim de string
		posicaoEnter = strchr(pJogo.NomeJogadorPreto, '\n');
		if (posicaoEnter != NULL)
		{
			*posicaoEnter = '\0';
		}//fim do if que troca os simbolos
		//limpa o buffer de stdin
		else
		{
			while (c != '\n' && c != EOF)
			{
				c = getchar();
			}
		}
	}
	//caso onde ocorreu erro de leitura, limpa o buffer de stdin
	else
	{
		while (c != '\n' && c != EOF)
			{
				c = getchar();
			}
		printf("\n\nERRO!!! Problema ao ler a string\n");
	}//fim do metodo utilizado para capturar uma string de stdin evitando buffer overflow

	//define o nome do jogador atual
	pJogo.NomeJogadorAtual = pJogo.NomeJogadorBranco;
	printf("\n\n------- Os Jogadores %s e %s podem comecar a partida -------\n\n", pJogo.NomeJogadorBranco, pJogo.NomeJogadorPreto);
	printf("\n>>> Eh a vez de %s jogar <<<\n", pJogo.NomeJogadorBranco);
	
	//preenche o tabuleiro com pe�as novas
	retJOG = JOG_PreencherTabuleiro(&pTab);
	//tratar erro da funcao JOG_PreencherTabuleiro
	if (retJOG != JOG_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao preencher o tabuleiro\n", retJOG);
		retJOG = JOG_CondRetErroTabuleiro;
		//exit(0);
	}//fim do if que trata o erro da funcao JOG_PreencherTabuleiro
	
	//exibe o tabuleiro pronto na tela para os jogadores
	retTAB = TAB_ExibirTabuleiro(&pTab);
	//trata erro da funcao TAB_ExibirTabuleiro
	if (retTAB != TAB_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao exibir o tabuleiro\n", retTAB);
		retJOG = JOG_CondRetErroTabuleiro;
	}//fim do if que trata o erro da funcao TAB_ExibirTabuleiro
	
	return retJOG;

} /* Fim fun��o: JOG Iniciar Partida */



/***********************************************************************
*
*  Fun��o: JOG Preencher Tabuleiro
*
***********************************************************************/

JOG_tpCondRet JOG_PreencherTabuleiro (TAB_tppTabuleiro * Tab)
{
	JOG_tpCondRet retJOG = JOG_CondRetOK;
	TAB_tpCondRet retTAB = TAB_CondRetOK;
	PEC_tpCondRet retPEC = PEC_CondRetOK;
	
	//variaveis utlisadas para percorrer o tabuleiro
	int i, j;
	
	//cria um tabuleiro novo para o jogo de damas
	retTAB = TAB_CriarTabuleiro (&pTab, 8, 8);
	//trata erro gerado pela funcao TAB_CriarTabuleiro
	if (retTAB != TAB_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao criar um tabuleiro para o jogo\n", retTAB);
		retJOG = JOG_CondRetErroTabuleiro;
	}//fim do if que trata erro gerado pela funcao TAB_CriarTabuleiro
	
	//preenche as tres primeiras fileiras do tabuleiro com peoes brancos
	for(i=0; i<3; i++)
	{
		//percorre todas as colunas da linha i
		for(j=0; j<8; j++)
		{
			//verifica se uma peca deve ser colocada nesta posicao
			if (((i%2 == 0) && (j%2 == 1))||((i%2 == 1) && (j%2 == 0)))
			{
				//cria um peao branco novo para ser colocado no tabuleiro
				retPEC = PEC_CriarPeca ( &pPeca, PEC_NomePeao, PEC_CorBranca, 'b');
				//trata erro gerado pela funcao PEC_CriarPeca
				if (retPEC != PEC_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao criar uma peca\n", retPEC);
					retJOG = JOG_CondRetErroPeca;
				}//fim do if que trata erro gerado pela funcao PEC_CriarPeca
				
				//coloca o peao na posicao ij atual
				retTAB = TAB_InserirPeca(&pTab, &pPeca, i, j);
				//trata erro gerado pela funcao TAB_InserirPeca
				if (retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao inserir uma peca no tabuleiro\n", retTAB);
					retJOG = JOG_CondRetErroTabuleiro;
				}//fim do if que trata erro gerado pela funcao TAB_InserirPeca
				
				//limpa o ponteiro de peca
				pPeca = NULL;
			}//fim do if que verifica se uma peca deve ser colocada nesta posicao
		}//fim do for que percorre todas as colunas
	}//fim do for que preenche as tres primeiras fileiras do tabuleiro

	//preenche as tres ultimas fileiras do tabuleiro com peoes pretos
	for(i=5; i<8; i++)
	{
		//percorre todas as colunas da linha i
		for(j=0; j<8; j++)
		{
			//verifica se uma peca deve ser colocada nesta posicao
			if (((i%2 == 0) && (j%2 == 1))||((i%2 == 1) && (j%2 == 0)))
			{
				//cria um peao preto novo para ser colocado no tabuleiro
				retPEC = PEC_CriarPeca ( &pPeca, PEC_NomePeao, PEC_CorPreta, 'p');
				//trata erro gerado pela funcao PEC_CriarPeca
				if (retPEC != PEC_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao criar uma peca\n", retPEC);
					retJOG = JOG_CondRetErroPeca;
					//exit(0);
				}//fim do if que trata erro gerado pela funcao PEC_CriarPeca

				//coloca o peao na posicao ij atual
				retTAB = TAB_InserirPeca(&pTab, &pPeca, i, j);
				//trata erro gerado pela funcao TAB_InserirPeca
				if (retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao inserir uma peca no tabuleiro\n", retTAB);
					retJOG = JOG_CondRetErroTabuleiro;
				}//fim do if que trata erro gerado pela funcao TAB_InserirPeca
				
				//limpa o ponteiro de peca
				pPeca = NULL;
			}//fim do if que verifica se uma peca deve ser colocada nesta posicao
		}//fim do for que percorre todas as colunas
	}//fim do for que preenche as tres ultimas fileiras do tabuleiro

	return retJOG;

} /* Fim fun��o: JOG Preencher Tabuleiro */



/***********************************************************************
*
*  Fun��o: JOG Mover Peca
*
***********************************************************************/

JOG_tpCondRet JOG_MoverPeca (TAB_tppTabuleiro * Tab, int CoordLinhaIncial, int CoordColunaIncial, int CoordLinhaFinal, int CoordColunaFinal)
{
	JOG_tpCondRet retJOG = JOG_CondRetOK;
	TAB_tpCondRet retTAB = TAB_CondRetOK;
	PEC_tpCondRet retPEC = PEC_CondRetOK;
	
	//variaveis auxiliares para guardar os dados da peca a ser movida
	PEC_tpNomePeca nomePeca;
	PEC_tpCorPeca corPeca;
	char codPeca = '\0';
	char codPecaIntermediario = '\0';

	//variaveis auxiliares para percorrer o tabuleiro
	int i = CoordLinhaIncial;
	int j = CoordColunaIncial;

	//variavel usada para simbolisar a existencia de captura
	int houveCaptura = 0;

	//obtem a peca da casa de origem
	retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, CoordLinhaIncial, CoordColunaIncial, &codPeca);
	//tratar erro da funcao TAB_ObterConteudoCasa
	if(retTAB != TAB_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de origem\n", retTAB);
		return JOG_CondRetErroTabuleiro;
	}//fim do if que trata o erro da funcao TAB_ObterConteudoCasa
	retPEC = PEC_ObterNomePeca(&pPeca, &nomePeca);
	//tratar erro da funcao PEC_ObterNomePeca
	if(retPEC != PEC_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao o nome da peca\n", retPEC);
		return JOG_CondRetErroPeca;
	}//fim do if que trata o erro da funcao PEC_ObterNomePeca
	retPEC = PEC_ObterCorPeca(&pPeca, &corPeca);
	//tratar erro da funcao PEC_ObterCorPeca
	if(retPEC != PEC_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao a cor da peca\n", retPEC);
		return JOG_CondRetErroPeca;
	}//fim do if que trata o erro da funcao PEC_ObterCorPeca

	//limpa o ponteiro da peca
	pPeca = NULL;

	//verifica se a peca sera transformada em dama
	if(((codPeca == 'b')&&(CoordLinhaFinal==7))||((codPeca == 'p')&&(CoordLinhaFinal==0)))
	{
		nomePeca = PEC_NomeDama;
		if(codPeca == 'b')
		{
			codPeca = 'B';
		}
		else if(codPeca == 'p')
		{
			codPeca = 'P';
		}
	}
	
	//move a peca
	//retira a peca da casa de origem
	retTAB = TAB_RetirarPeca(&pTab, CoordLinhaIncial, CoordColunaIncial);
	//tratar erro da funcao TAB_RetirarPeca
	if(retTAB != TAB_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao retirar uma peca\n", retTAB);
		return JOG_CondRetErroTabuleiro;
	}//fim do if que trata o erro da funcao TAB_RetirarPeca
	//cria uma nova peca para inserir na casa de destino
	retPEC = PEC_CriarPeca(&pPeca, nomePeca, corPeca, codPeca);
	//tratar erro da funcao PEC_CriarPeca
	if(retPEC != PEC_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao criar uma peca\n", retPEC);
		return JOG_CondRetErroPeca;
	}//fim do if que trata o erro da funcao PEC_CriarPeca
	//insere a peca na casa de origem
	retTAB = TAB_InserirPeca(&pTab, &pPeca, CoordLinhaFinal, CoordColunaFinal);
	//tratar erro da funcao TAB_InserirPeca
	if(retTAB != TAB_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao inserir uma peca\n", retTAB);
		return JOG_CondRetErroTabuleiro;
	}//fim do if que trata o erro da funcao TAB_InserirPeca
	//limpa ponteiro da peca
	pPeca = NULL;
	//incrementa o contador de numero de jogadas sem captura
	pJogo.numJogadasSemCaptura++;


	//tratar captura
	//caso de um movimento para cima
	if((CoordLinhaIncial-CoordLinhaFinal)>1)
	{
		//movimento para nordeste
		if((CoordColunaIncial-CoordColunaFinal)<0)
		{
			//percorre todas as casas por onde ira passar
			while(i>(CoordLinhaFinal+1))
			{
				i--;
				j++;
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codPecaIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de origem\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro da funcao TAB_ObterConteudoCasa
				//exclui a peca
				if(pPeca!=NULL)
				{
					//limpa ponteiro de peca
					pPeca = NULL;
					
					//retira a peca da casa
					retTAB = TAB_RetirarPeca(&pTab, i, j);
					//tratar erro da funcao TAB_RetirarPeca
					if(retTAB != TAB_CondRetOK)
					{
						printf("\n\nERRO!!! Ocorreu o erro %d ao retirar uma peca\n", retTAB);
						return JOG_CondRetErroTabuleiro;
					}//fim do if que trata o erro da funcao TAB_RetirarPeca
					

					//contabiliza ponto para jogador branco
					if(pJogo.codJogadorAtual==0)
					{
						pJogo.pontosJogadorBranco++;
						houveCaptura++;
						pJogo.numJogadasSemCaptura=0;
					}//fim do if que adiciona ponto ao branco
					//contabiliza ponto para jogador preto
					else if(pJogo.codJogadorAtual==1)
					{
						pJogo.pontosJogadorPreto++;
						houveCaptura++;
						pJogo.numJogadasSemCaptura=0;
					}//fim do if que adiciona ponto ao preto

				}//fim do if que exclui a peca
			}//fim do while que percorre todas as casas por onde ira passar
		}//fim do if que trata movimento para nordeste
		//movimento para noroeste
		else if((CoordColunaIncial-CoordColunaFinal)>0)
		{
			//percorre todas as casas por onde ira passar
			while(i>(CoordLinhaFinal+1))
			{
				i--;
				j--;
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codPecaIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de origem\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro da funcao TAB_ObterConteudoCasa
				//exclui a peca
				if(pPeca!=NULL)
				{
					//limpa ponteiro de peca
					pPeca = NULL;
					
					//retira a peca da casa
					retTAB = TAB_RetirarPeca(&pTab, i, j);
					//tratar erro da funcao TAB_RetirarPeca
					if(retTAB != TAB_CondRetOK)
					{
						printf("\n\nERRO!!! Ocorreu o erro %d ao retirar uma peca\n", retTAB);
						return JOG_CondRetErroTabuleiro;
					}//fim do if que trata o erro da funcao TAB_RetirarPeca
					
					//contabiliza ponto para jogador branco
					if(pJogo.codJogadorAtual==0)
					{
						pJogo.pontosJogadorBranco++;
						houveCaptura++;
						pJogo.numJogadasSemCaptura=0;
					}//fim do if que adiciona ponto ao branco
					//contabiliza ponto para jogador preto
					else if(pJogo.codJogadorAtual==1)
					{
						pJogo.pontosJogadorPreto++;
						houveCaptura++;
						pJogo.numJogadasSemCaptura=0;
					}//fim do if que adiciona ponto ao preto

				}//fim do if que exclui a peca
			}//fim do while que percorre todas as casas por onde ira passar
		}//fim do if que trata movimento para noroeste
	}//fim do if que trata um movimento para cima
	//caso de um movimento para baixo
	else if ((CoordLinhaIncial-CoordLinhaFinal)<-1)
	{
		//movimento para sudeste
		if((CoordColunaIncial-CoordColunaFinal)<0)
		{
			//percorre todas as casas por onde ira passar
			while(i<(CoordLinhaFinal-1))
			{
				i++;
				j++;
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codPecaIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de origem\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro da funcao TAB_ObterConteudoCasa
				//exclui a peca
				if(pPeca!=NULL)
				{
					//limpa ponteiro de peca
					pPeca = NULL;
					
					//retira a peca da casa
					retTAB = TAB_RetirarPeca(&pTab, i, j);
					//tratar erro da funcao TAB_RetirarPeca
					if(retTAB != TAB_CondRetOK)
					{
						printf("\n\nERRO!!! Ocorreu o erro %d ao retirar uma peca\n", retTAB);
						return JOG_CondRetErroTabuleiro;
					}//fim do if que trata o erro da funcao TAB_RetirarPeca
					
					//contabiliza ponto para jogador branco
					if(pJogo.codJogadorAtual==0)
					{
						pJogo.pontosJogadorBranco++;
						houveCaptura++;
						pJogo.numJogadasSemCaptura=0;
					}//fim do if que adiciona ponto ao branco
					//contabiliza ponto para jogador preto
					else if(pJogo.codJogadorAtual==1)
					{
						pJogo.pontosJogadorPreto++;
						houveCaptura++;
						pJogo.numJogadasSemCaptura=0;
					}//fim do if que adiciona ponto ao preto

				}//fim do if que exclui a peca
			}//fim do while que percorre todas as casas por onde ira passar
		}//fim do if que trata movimento para sudeste
		//movimento para sudoeste
		else if((CoordColunaIncial-CoordColunaFinal)>0)
		{
			//percorre todas as casas por onde ira passar
			while(i<(CoordLinhaFinal-1))
			{
				i++;
				j--;
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codPecaIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de origem\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro da funcao TAB_ObterConteudoCasa
				//exclui a peca
				if(pPeca!=NULL)
				{
					//limpa ponteiro de peca
					pPeca = NULL;
					
					//retira a peca da casa
					retTAB = TAB_RetirarPeca(&pTab, i, j);
					//tratar erro da funcao TAB_RetirarPeca
					if(retTAB != TAB_CondRetOK)
					{
						printf("\n\nERRO!!! Ocorreu o erro %d ao retirar uma peca\n", retTAB);
						return JOG_CondRetErroTabuleiro;
					}//fim do if que trata o erro da funcao TAB_RetirarPeca
					
					//contabiliza ponto para jogador branco
					if(pJogo.codJogadorAtual==0)
					{
						pJogo.pontosJogadorBranco++;
						houveCaptura++;
						pJogo.numJogadasSemCaptura=0;
					}//fim do if que adiciona ponto ao branco
					//contabiliza ponto para jogador preto
					else if(pJogo.codJogadorAtual==1)
					{
						pJogo.pontosJogadorPreto++;
						houveCaptura++;
						pJogo.numJogadasSemCaptura=0;
					}//fim do if que adiciona ponto ao preto

				}//fim do if que exclui a peca
			}//fim do while que percorre todas as casas por onde ira passar
		}//fim do if que trata movimento para sudoeste
	}//fim do if que trata movimento para baixo

	//verifica a possibilidade de captura em cadeia
	retJOG = JOG_VerificarCaptura(&pTab, CoordLinhaFinal, CoordColunaFinal);
	//trata erro da funca JOG_VerificarCaptura
	if((retJOG != JOG_CondRetOK)&&(retJOG != JOG_CondRetNaoExisteCapturaPossivel))
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao verificar captura\n", retJOG);
		return retJOG;
	}//fim do if de tratamento do erro da funcao JOG_VerificarCaptura
	//nao existe possibilidade de captura em cadeia
	else if ((retJOG == JOG_CondRetNaoExisteCapturaPossivel)||(houveCaptura == 0))
	{
		//muda a vez do jogador para preto
		if(pJogo.codJogadorAtual==0)
		{
			pJogo.codJogadorAtual=1;
			pJogo.NomeJogadorAtual=pJogo.NomeJogadorPreto;
		}//fim do if que muda a vez do jogador para preto
		//muda a vez do jogador para branco
		else if(pJogo.codJogadorAtual==1)
		{
			pJogo.codJogadorAtual=0;
			pJogo.NomeJogadorAtual=pJogo.NomeJogadorBranco;
		}//fim do if que muda a vez do jogador para branco
	}//fim do if em que nao existe possibilidade de captura em cadeia
	
	return JOG_CondRetOK;

} /* Fim fun��o: JOG Mover Peca */



/***********************************************************************
*
*  Fun��o: JOG Verificar Movimento
*
***********************************************************************/

JOG_tpCondRet JOG_VerificarMovimento (TAB_tppTabuleiro * Tab, int CoordLinhaInicial, int CoordColunaInicial, int CoordLinhaFinal, int CoordColunaFinal)
{
	
	JOG_tpCondRet retJOG = JOG_CondRetOK;
	TAB_tpCondRet retTAB = TAB_CondRetOK;

	//variaveis auxiliares para guardar codigo das pecas presentes nas casas
	char codConteudoOrigem = '\0';
	char codConteudoDestino = '\0';
	char codConteudoIntermediario = '\0';

	//inicializa as variaveis para percorrer o tabuleiro
	int i=CoordLinhaInicial;
	int j=CoordColunaInicial;
	int pecaEncontrada=0;
	int vagaEncontrada=0;
	int movimentoOK=0;
	
	//verificar se as coordenadas sao validas (estao dentro do tabuleiro)
	if(!((CoordLinhaInicial>=0) && (CoordLinhaInicial<8) && (CoordColunaInicial>=0) && (CoordColunaInicial<8) && (CoordLinhaFinal>=0) && (CoordLinhaFinal<8) && (CoordColunaFinal>=0) && (CoordColunaFinal<8)))
	{
		return JOG_CondRetMovimentoErrado;
	}//fim do if que verifica se as coordenadas sao validas
	
	//verificar se a casa de destino estah ocupada
	retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, CoordLinhaFinal, CoordColunaFinal, &codConteudoDestino);
	//tratar erro da funcao TAB_ObterConteudoCasa
	if(retTAB != TAB_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
		return JOG_CondRetErroTabuleiro;
	}//fim do if que trata o erro da funcao TAB_ObterConteudoCasa
	//verificar se a casa de destino estah ocupada
	if (pPeca!=NULL)
	{
		printf("\n\nATENCAO!!! A coordenada de destino estah ocupada...\n");
		pPeca = NULL;
		return JOG_CondRetMovimentoErrado;
	}//fim do if que verifica se a casa de destino esta ocupada

	//verificar se casa de origem contem uma peca do jogador atual
	retTAB = TAB_ObterConteudoCasa(&pTab, &pPeca, CoordLinhaInicial, CoordColunaInicial, &codConteudoOrigem);
	//tratar erro da funcao TAB_ObterConteudoCasa
	if(retTAB != TAB_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de origem\n", retTAB);
		return JOG_CondRetErroTabuleiro;
	}//fim do if que trata o erro da funcao TAB_ObterConteudoCasa
	//tratar caso em que a peca nao existe (a casa estah vazia)
	if (pPeca == NULL)
	{
		printf("\n\nATENCAO!!! A coordenada de origem nao contem peca a ser movida...\n");
		return JOG_CondRetMovimentoErrado;
	}//fim do if que trata inexistencia da peca
	//verifica se o jogador branco esta jogando com a peca correta
	else if ((pJogo.codJogadorAtual == 0) && ((codConteudoOrigem != 'b')&&(codConteudoOrigem != 'B')))
	{
		printf("\n\n>>> Eh a vez de %s jogar <<<\n", pJogo.NomeJogadorAtual);
		pPeca = NULL;
		return JOG_CondRetMovimentoErrado;
	}//fim do if que verifica se o jogador branco esta jogando com a peca correta
	//verifica se o jogador preto esta jogando com a peca correta
	else if ((pJogo.codJogadorAtual == 1) && ((codConteudoOrigem != 'p')&&(codConteudoOrigem != 'P')))
	{
		printf("\n\n>>> Eh a vez de %s jogar <<<\n", pJogo.NomeJogadorAtual);
		pPeca = NULL;
		return JOG_CondRetMovimentoErrado;
	}//fim do if que verifica se o jogador preto esta jogando com a peca correta
	//limpa o ponteiro pPeca antes de continuar
	else
	{
		pPeca = NULL;
	}

	//verificar se existem capturas a serem efetuadas
	retJOG = JOG_VerificarCaptura(&pTab, CoordLinhaInicial, CoordColunaInicial);

	//tratar o caso em que o movimento nao acarretara captura
	if (retJOG == JOG_CondRetNaoExisteCapturaPossivel)
	{
		//caso de movimento de um peao branco
		if(codConteudoOrigem == 'b')
		{
			//verifica se o peao esta sendo movido para frente
			if((CoordLinhaFinal == (CoordLinhaInicial + 1)) && ((CoordColunaFinal == (CoordColunaInicial + 1))||(CoordColunaFinal == (CoordColunaInicial - 1))))
			{
				return JOG_CondRetOK;
			}
			else
			{
				printf("\n\nATENCAO!!! O peao nao pode efetuar esse tipo de movimento...\n");
				return JOG_CondRetMovimentoErrado;
			}
		}//fim do if que trata o movimento de um peao branco sem captura
		
		//caso de movimento de um peao preto
		else if (codConteudoOrigem == 'p')
		{
			//verifica se o peao esta sendo movido para frente
			if((CoordLinhaFinal == (CoordLinhaInicial - 1)) && ((CoordColunaFinal == (CoordColunaInicial + 1))||(CoordColunaFinal == (CoordColunaInicial - 1))))
			{
				return JOG_CondRetOK;
			}
			else
			{
				printf("\n\nATENCAO!!! O peao nao pode efetuar esse tipo de movimento...\n");
				return JOG_CondRetMovimentoErrado;
			}
		}//fim do if que trata o movimento de um peao preto sem captura
		
		//caso de movimento de uma dama
		else if ((codConteudoOrigem == 'B')||(codConteudoOrigem == 'P'))
		{
			//verifica se a dama esta sendo movimentada na diagonal
			if(((CoordLinhaInicial-CoordLinhaFinal)==(CoordColunaInicial-CoordColunaFinal))||((CoordLinhaInicial-CoordLinhaFinal)==(-(CoordColunaInicial-CoordColunaFinal))))
			{
				return JOG_CondRetOK;
			}
			else
			{
				printf("\n\nATENCAO!!! A dama nao pode efetuar esse tipo de movimento...\n");
				return JOG_CondRetMovimentoErrado;
			}
		}//fim do if que trata o movimento de uma dama sem captura
	}//fim do if que trata o movimento de uma peca sem captura

	//tratar o caso em que o movimento possue uma captura
	else if (retJOG == JOG_CondRetOK)
	{
		//caso de movimento de um peao
		if ((codConteudoOrigem == 'b')||(codConteudoOrigem == 'p'))
		{	
			//verifica se o peao esta sendo movimentado na diagonal e se ele esta capturando uma peca
			if(!(((CoordLinhaInicial-CoordLinhaFinal)==2)||((CoordLinhaInicial-CoordLinhaFinal)==-2)))
			{
				printf("\n\nATENCAO!!! Um movimento de captura eh obrigatorio...\n");
				return JOG_CondRetMovimentoErrado;
			}
			//primeiro caso: movimento para nordeste
			if(((CoordLinhaInicial-CoordLinhaFinal)==2)&&((CoordColunaInicial-CoordColunaFinal)==-2))
			{
				//verifica se o movimento ira capturar uma peca
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, CoordLinhaInicial-1, CoordColunaInicial+1, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				if(pPeca !=NULL)
				{
					//limpa ponteiro para peca
					pPeca = NULL;

					//verifica se a peca a ser capturada eh do adversario
					if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
					{
						printf("\n\nATENCAO!!! O movimento solicitado captura uma peca sua...\n");
						return JOG_CondRetMovimentoErrado;
					}//fim do if que verifica se o jogador tentou comer uma peca dele mesmo

					return JOG_CondRetOK;
				}
				else
				{
					printf("\n\nATENCAO!!! Um movimento de captura eh obrigatorio...\n");
					return JOG_CondRetMovimentoErrado;
				}
			}//fim if do caso de um movimento para nordeste
			
			//segundo caso: movimento para noroeste
			else if(((CoordLinhaInicial-CoordLinhaFinal)==2)&&((CoordColunaInicial-CoordColunaFinal)==2))
			{
				//verifica se o movimento ira capturar uma peca
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, CoordLinhaInicial-1, CoordColunaInicial-1, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				if(pPeca !=NULL)
				{
					//limpa ponteiro para peca
					pPeca = NULL;
					
					//verifica se a peca a ser capturada eh do adversario
					if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
					{
						printf("\n\nATENCAO!!! O movimento solicitado captura uma peca sua...\n");
						return JOG_CondRetMovimentoErrado;
					}//fim do if que verifica se o jogador tentou comer uma peca dele mesmo
					
					return JOG_CondRetOK;
				}
				else
				{
					printf("\n\nATENCAO!!! Um movimento de captura eh obrigatorio...\n");
					return JOG_CondRetMovimentoErrado;
				}
			}//fim if do caso de um movimento para noroeste
			
			//terceiro caso: movimento para sudeste
			else if(((CoordLinhaInicial-CoordLinhaFinal)==-2)&&((CoordColunaInicial-CoordColunaFinal)==-2))
			{
				//verifica se o movimento ira capturar uma peca
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, CoordLinhaInicial+1, CoordColunaInicial+1, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				if(pPeca !=NULL)
				{
					//limpa ponteiro para peca
					pPeca = NULL;
					
					//verifica se a peca a ser capturada eh do adversario
					if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
					{
						printf("\n\nATENCAO!!! O movimento solicitado captura uma peca sua...\n");
						return JOG_CondRetMovimentoErrado;
					}//fim do if que verifica se o jogador tentou comer uma peca dele mesmo

					return JOG_CondRetOK;
				}
				else
				{
					printf("\n\nATENCAO!!! Um movimento de captura eh obrigatorio...\n");
					return JOG_CondRetMovimentoErrado;
				}
			}//fim if do caso de um movimento para sudeste
			
			//quarto e ultimo caso: movimento para sudoeste
			else if(((CoordLinhaInicial-CoordLinhaFinal)==-2)&&((CoordColunaInicial-CoordColunaFinal)==2))
			{
				//verifica se o movimento ira capturar uma peca
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, CoordLinhaInicial+1, CoordColunaInicial-1, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				if(pPeca !=NULL)
				{
					//limpa ponteiro para peca
					pPeca = NULL;
					
					//verifica se a peca a ser capturada eh do adversario
					if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
					{
						printf("\n\nATENCAO!!! O movimento solicitado captura uma peca sua...\n");
						return JOG_CondRetMovimentoErrado;
					}//fim do if que verifica se o jogador tentou comer uma peca dele mesmo
					
					return JOG_CondRetOK;
				}
				else
				{
					printf("\n\nATENCAO!!! Um movimento de captura eh obrigatorio...\n");
					return JOG_CondRetMovimentoErrado;
				}
			}//fim if do caso de um movimento para sudoeste
		}//fim do if que trata o movimento de um peao com captura obrigatoria

		//caso de movimento de uma dama
		else if ((codConteudoOrigem == 'B')||(codConteudoOrigem == 'P'))
		{
			//verifica se dama esta sendo movimentada na diagonal e se ela esta capturando uma peca
			//primeiro caso: movimento para nordeste
			if(((CoordLinhaInicial-CoordLinhaFinal)==(-(CoordColunaInicial-CoordColunaFinal)))&&((CoordLinhaInicial-CoordLinhaFinal)>1)&&((CoordColunaInicial-CoordColunaFinal)<-1))
			{
				//inicializa as variaveis para percorrer o tabuleiro
				i=CoordLinhaInicial;
				j=CoordColunaInicial;
				pecaEncontrada=0;
				vagaEncontrada=0;
				movimentoOK=0;
				
				//percorre todas as casas onde a dama irah percorrer em busca de pecas a serem capturadas
				while((i!=CoordLinhaFinal)&&(i>0)&&(i<8)&&(j>=0)&&(j<7))
				{
					//posiciona os indices na proxima casa � nordeste
					i--;
					j++;

					//verifica se o movimento ira capturar uma peca
					retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codConteudoIntermediario);
					//tratar erro da funcao TAB_ObterConteudoCasa
					if(retTAB != TAB_CondRetOK)
					{
						printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
						return JOG_CondRetErroTabuleiro;
					}//fim do if que trata o erro
					//verifica se uma peca foi encontrada
					if(pPeca !=NULL)
					{
						//limpa ponteiro para peca
						pPeca = NULL;
						
						//verifica se a peca a ser capturada eh do adversario
						if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
						{
							printf("\n\nATENCAO!!! O movimento solicitado captura uma peca sua...\n");
							return JOG_CondRetMovimentoErrado;
						}//fim do if que verifica se o jogador tentou comer uma peca dele mesmo
						pecaEncontrada=1;
						if(movimentoOK==1)
						{
							movimentoOK=0;
						}
					}//fim do if que verifica se existe uma peca a ser capturada
					//verifica se uma vaga  para colocar a dama apos a captura foi encontrada, para o caso de uma captura em cadeia
					else
					{
						if(pecaEncontrada==1)
						{
							vagaEncontrada=1;
							movimentoOK=1;
							pecaEncontrada=0;
						}
					}//fim do else para o caso onde se trata de uma vaga encontrada
				}//fim do while que percorre todas as casas por onde a passa para verificar se a captura sera feita
			}//fim do primeiro caso: movimento para nordeste

			//segundo caso: movimento para noroeste
			if(((CoordLinhaInicial-CoordLinhaFinal)==((CoordColunaInicial-CoordColunaFinal)))&&((CoordLinhaInicial-CoordLinhaFinal)>1)&&((CoordColunaInicial-CoordColunaFinal)>1))
			{
				//inicializa as variaveis para percorrer o tabuleiro
				i=CoordLinhaInicial;
				j=CoordColunaInicial;
				pecaEncontrada=0;
				vagaEncontrada=0;
				movimentoOK=0;

				//percorre todas as casas onde a dama irah percorrer em busca de pecas a serem capturadas
				while((i!=CoordLinhaFinal)&&(i>0)&&(i<8)&&(j>0)&&(j<8))
				{
					//posiciona os indices na proxima casa � noroeste
					i--;
					j--;

					//verifica se o movimento ira capturar uma peca
					retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codConteudoIntermediario);
					//tratar erro da funcao TAB_ObterConteudoCasa
					if(retTAB != TAB_CondRetOK)
					{
						printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
						return JOG_CondRetErroTabuleiro;
					}//fim do if que trata o erro
					//verifica se uma peca foi encontrada
					if(pPeca !=NULL)
					{
						//limpa ponteiro para peca
						pPeca = NULL;
						
						//verifica se a peca a ser capturada eh do adversario
						if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
						{
							printf("\n\nATENCAO!!! O movimento solicitado captura uma peca sua...\n");
							return JOG_CondRetMovimentoErrado;
						}//fim do if que verifica se o jogador tentou comer uma peca dele mesmo
						pecaEncontrada=1;
						if(movimentoOK==1)
						{
							movimentoOK=0;
						}
					}//fim do if que verifica se existe uma peca a ser capturada
					//verifica uma vaga  para colocar a dama apos a captura foi encontrada, para o caso de uma captura em cadeia
					else
					{
						if(pecaEncontrada==1)
						{
							vagaEncontrada=1;
							movimentoOK=1;
							pecaEncontrada=0;
						}
					}//fim do else para o caso onde se trata de uma vaga encontrada
				}//fim do while que percorre todas as casas por onde a passa para verificar se a captura sera feita
			}//fim do segundo caso: movimento para noroeste

			//terceiro caso: movimento para sudeste
			if(((CoordLinhaInicial-CoordLinhaFinal)==((CoordColunaInicial-CoordColunaFinal)))&&((CoordLinhaInicial-CoordLinhaFinal)<-1)&&((CoordColunaInicial-CoordColunaFinal)<-1))
			{
				//inicializa as variaveis para percorrer o tabuleiro
				i=CoordLinhaInicial;
				j=CoordColunaInicial;
				pecaEncontrada=0;
				vagaEncontrada=0;
				movimentoOK=0;

				//percorre todas as casas onde a dama irah percorrer em busca de pecas a serem capturadas
				while((i!=CoordLinhaFinal)&&(i>=0)&&(i<7)&&(j>=0)&&(j<7))
				{
					//posiciona os indices na proxima casa � sudeste
					i++;
					j++;

					//verifica se o movimento ira capturar uma peca
					retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codConteudoIntermediario);
					//tratar erro da funcao TAB_ObterConteudoCasa
					if(retTAB != TAB_CondRetOK)
					{
						printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
						return JOG_CondRetErroTabuleiro;
					}//fim do if que trata o erro
					//verifica se uma peca foi encontrada
					if(pPeca !=NULL)
					{
						//limpa ponteiro para peca
						pPeca = NULL;
						
						//verifica se a peca a ser capturada eh do adversario
						if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
						{
							printf("\n\nATENCAO!!! O movimento solicitado captura uma peca sua...\n");
							return JOG_CondRetMovimentoErrado;
						}//fim do if que verifica se o jogador tentou comer uma peca dele mesmo
						pecaEncontrada=1;
						if(movimentoOK==1)
						{
							movimentoOK=0;
						}
					}//fim do if que verifica se existe uma peca a ser capturada
					//verifica uma vaga  para colocar a dama apos a captura foi encontrada, para o caso de uma captura em cadeia
					else
					{
						if(pecaEncontrada==1)
						{
							vagaEncontrada=1;
							movimentoOK=1;
							pecaEncontrada=0;
						}
					}//fim do else para o caso onde se trata de uma vaga encontrada
				}//fim do while que percorre todas as casas por onde a passa para verificar se a captura sera feita
			}//fim do terceiro caso: movimento para sudeste

			//quarto e ultimo caso: movimento para sudoeste
			if(((CoordLinhaInicial-CoordLinhaFinal)==(-(CoordColunaInicial-CoordColunaFinal)))&&((CoordLinhaInicial-CoordLinhaFinal)<-1)&&((CoordColunaInicial-CoordColunaFinal)>1))
			{
				//inicializa as variaveis para percorrer o tabuleiro
				i=CoordLinhaInicial;
				j=CoordColunaInicial;
				pecaEncontrada=0;
				vagaEncontrada=0;
				movimentoOK=0;

				//percorre todas as casas onde a dama irah percorrer em busca de pecas a serem capturadas
				while((i!=CoordLinhaFinal)&&(i>=0)&&(i<7)&&(j>0)&&(j<8))
				{
					//posiciona os indices na proxima casa � sudoeste
					i++;
					j--;

					//verifica se o movimento ira capturar uma peca
					retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codConteudoIntermediario);
					//tratar erro da funcao TAB_ObterConteudoCasa
					if(retTAB != TAB_CondRetOK)
					{
						printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
						return JOG_CondRetErroTabuleiro;
					}//fim do if que trata o erro
					//verifica se uma peca foi encontrada
					if(pPeca !=NULL)
					{
						//limpa ponteiro para peca
						pPeca = NULL;

						//verifica se a peca a ser capturada eh do adversario
						if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
						{
							printf("\n\nATENCAO!!! O movimento solicitado captura uma peca sua...\n");
							return JOG_CondRetMovimentoErrado;
						}//fim do if que verifica se o jogador tentou comer uma peca dele mesmo
						pecaEncontrada=1;
						if(movimentoOK==1)
						{
							movimentoOK=0;
						}
					}//fim do if que verifica se existe uma peca a ser capturada
					//verifica uma vaga  para colocar a dama apos a captura foi encontrada, para o caso de uma captura em cadeia
					else
					{
						if(pecaEncontrada==1)
						{
							vagaEncontrada=1;
							movimentoOK=1;
							pecaEncontrada=0;
						}
					}//fim do else para o caso onde se trata de uma vaga encontrada
				}//fim do while que percorre todas as casas por onde a passa para verificar se a captura sera feita
			}//fim do quarto e ultimo caso: movimento para sudoeste

			//retorna se o movimento da dama foi validado ou nao
			if(movimentoOK==1)
			{
				return JOG_CondRetOK;
			}
			else
			{
				printf("\n\nMOVIMENTO INVALIDO!!!\n");
				return JOG_CondRetMovimentoErrado;
			}//fim do if que trata o retorno adequado para esse tipo de movimento

		}//fim do if que trata o movimento de uma dama com captura obrigatoria
	}//fim do if que trata o movimento de uma peca com captura
	
	//ocorreu um erro na funcao JOG_VerificarCaptura
	else
	{
		printf("\n\nERRO!!! Ocorreu o %d ao verificar captura\n", retJOG);
		return retJOG;
	}//fim do tratamento do erro da funcao JOG_VerificarCaptura

} /* Fim fun��o: JOG Verificar Movimento */



/***********************************************************************
*
*  Fun��o: JOG Verificar Captura
*
***********************************************************************/

JOG_tpCondRet JOG_VerificarCaptura (TAB_tppTabuleiro * Tab, int CoordLinhaInicial, int CoordColunaInicial)
{
	TAB_tpCondRet retTAB = TAB_CondRetOK;

	//variaveis auxiliares para guardar codigo das pecas presentes nas casas
	char codConteudoOrigem = '\0';
	char codConteudoIntermediario = '\0';

	//variaveis para percorrer o tabuleiro
	int i, j;

	//verifica qual peca estah sendo movimentada
	retTAB = TAB_ObterConteudoCasa(&pTab, &pPeca, CoordLinhaInicial, CoordColunaInicial, &codConteudoOrigem);
	//tratar erro da funcao TAB_ObterConteudoCasa
	if(retTAB != TAB_CondRetOK)
	{
		printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
		return JOG_CondRetErroTabuleiro;
	}//fim do if que trata o erro

	//limpa o ponteiro para peca
	pPeca = NULL;

	//verifica se existe captura possivel para o caso de um peao
	if((codConteudoOrigem == 'p')||(codConteudoOrigem == 'b'))
	{
		//primeiro caso: verifica se existe alguma peca a ser capturada para nordeste
		if((CoordLinhaInicial>1)&&(CoordColunaInicial<6))
		{
			retTAB = TAB_ObterConteudoCasa(&pTab, &pPeca, CoordLinhaInicial-1, CoordColunaInicial+1, &codConteudoIntermediario);
			//tratar erro da funcao TAB_ObterConteudoCasa
			if(retTAB != TAB_CondRetOK)
			{
				printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
				return JOG_CondRetErroTabuleiro;
			}//fim do if que trata o erro
			//limpa ponteiro para peca
			pPeca = NULL;
			
			//verifica se a peca encontrada eh do adversario
			if(((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
			{
				//verifica se existe uma vaga para posicionar a peca apos a captura
				retTAB = TAB_ObterConteudoCasa(&pTab, &pPeca, CoordLinhaInicial-2, CoordColunaInicial+2, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				
				if(pPeca==NULL)
				{
					return JOG_CondRetOK;
				}
				//limpa ponteiro para peca
				pPeca = NULL;
			}//fim do if que verifica se a peca encontrada eh do adversario
		}//fim do primeiro caso: verifica se existe alguma peca a ser capturada para nordeste

		//segundo caso: verifica se existe alguma peca a ser capturada para noroeste
		if((CoordLinhaInicial>1)&&(CoordColunaInicial>1))
		{
			retTAB = TAB_ObterConteudoCasa(&pTab, &pPeca, CoordLinhaInicial-1, CoordColunaInicial-1, &codConteudoIntermediario);
			//tratar erro da funcao TAB_ObterConteudoCasa
			if(retTAB != TAB_CondRetOK)
			{
				printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
				return JOG_CondRetErroTabuleiro;
			}//fim do if que trata o erro
			//limpa ponteiro para peca
			pPeca = NULL;
			
			//verifica se a peca encontrada eh do adversario
			if(((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
			{
				//verifica se existe uma vaga para posicionar a peca apos a captura
				retTAB = TAB_ObterConteudoCasa(&pTab, &pPeca, CoordLinhaInicial-2, CoordColunaInicial-2, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				if(pPeca==NULL)
				{
					return JOG_CondRetOK;
				}
				//limpa ponteiro para peca
				pPeca = NULL;
			}//fim do if que verifica se a peca encontrada eh do adversario
		}//fim do segundo caso: verifica se existe alguma peca a ser capturada para noroeste

		//terceiro caso: verifica se existe alguma peca a ser capturada para sudeste
		if((CoordLinhaInicial<6)&&(CoordColunaInicial<6))
		{
			retTAB = TAB_ObterConteudoCasa(&pTab, &pPeca, CoordLinhaInicial+1, CoordColunaInicial+1, &codConteudoIntermediario);
			//tratar erro da funcao TAB_ObterConteudoCasa
			if(retTAB != TAB_CondRetOK)
			{
				printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
				return JOG_CondRetErroTabuleiro;
			}//fim do if que trata o erro
			//limpa ponteiro para peca
			pPeca = NULL;
			
			//verifica se a peca encontrada eh do adversario
			if(((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
			{
				//verifica se existe uma vaga para posicionar a peca apos a captura
				retTAB = TAB_ObterConteudoCasa(&pTab, &pPeca, CoordLinhaInicial+2, CoordColunaInicial+2, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				if(pPeca==NULL)
				{
					return JOG_CondRetOK;
				}
				//limpa ponteiro para peca
				pPeca = NULL;
			}//fim do if que verifica se a peca encontrada eh do adversario
		}//fim do terceiro caso: verifica se existe alguma peca a ser capturada para sudeste

		//quarto e ultimo caso: verifica se existe alguma peca a ser capturada para sudoeste
		if((CoordLinhaInicial<6)&&(CoordColunaInicial>1))
		{
			retTAB = TAB_ObterConteudoCasa(&pTab, &pPeca, CoordLinhaInicial+1, CoordColunaInicial-1, &codConteudoIntermediario);
			//tratar erro da funcao TAB_ObterConteudoCasa
			if(retTAB != TAB_CondRetOK)
			{
				printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
				return JOG_CondRetErroTabuleiro;
			}//fim do if que trata o erro
			//limpa ponteiro para peca
			pPeca = NULL;
			
			//verifica se a peca encontrada eh do adversario
			if(((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
			{
				//verifica se existe uma vaga para posicionar a peca apos a captura
				retTAB = TAB_ObterConteudoCasa(&pTab, &pPeca, CoordLinhaInicial+2, CoordColunaInicial-2, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				if(pPeca==NULL)
				{
					return JOG_CondRetOK;
				}
				//limpa ponteiro para peca
				pPeca = NULL;
			}//fim do if que verifica se a peca encontrada eh do adversario
		}//fim do quarto e ultimo caso: verifica se existe alguma peca a ser capturada para sudoeste

		//caso em que nao existe captura possivel
		return JOG_CondRetNaoExisteCapturaPossivel;

	}//fim do if que trata do caso de um peao

	//verifica se existe uma captura possivel para o caso de uma dama
	else if((codConteudoOrigem == 'P')||(codConteudoOrigem == 'B'))
	{
		//primeiro caso: verifica se existe alguma peca a ser capturada para nordeste
		//inicializa as variaveis para percorrer o tabuleiro
		i=CoordLinhaInicial;
		j=CoordColunaInicial;
		//percorre todas as casas onde a dama irah percorrer em busca de pecas a serem capturadas
		while((i>1)&&(j<6)&&(i<8)&&(j>=0))
		{
			//posiciona os indices na proxima casa � nordeste
			i--;
			j++;
			//verifica se o movimento ira capturar uma peca
			retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codConteudoIntermediario);
			//tratar erro da funcao TAB_ObterConteudoCasa
			if(retTAB != TAB_CondRetOK)
			{
				printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
				return JOG_CondRetErroTabuleiro;
			}//fim do if que trata o erro
			//verifica se uma peca foi encontrada
			if(pPeca !=NULL)
			{
				//limpa ponteiro para peca
				pPeca = NULL;

				//verifica se a peca a ser capturada eh do adversario
				if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
				{
					//encerra a busca
					break;
				}//fim do if que verifica se a peca a ser capturada eh do adversario
				
				//verifica se existe uma vaga para posicionar a peca apos a captura
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i-1, j+1, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				if(pPeca == NULL)
				{
					return JOG_CondRetOK;
				}
				else
				{
					pPeca = NULL;
					//encerra a busca
					break;
				}
				
			}//fim do if que verifica se uma peca foi encontrada
		}//fim do while que percorre todas as casas por onde a passa para verificar se a captura sera feita
		//fim do primeiro caso: movimento para nordeste

		//segundo caso: verifica se existe alguma peca a ser capturada para noroeste
		//inicializa as variaveis para percorrer o tabuleiro
		i=CoordLinhaInicial;
		j=CoordColunaInicial;
		//percorre todas as casas onde a dama irah percorrer em busca de pecas a serem capturadas
		while((i>1)&&(j>1)&&(i<8)&&(j<8))
		{
			//posiciona os indices na proxima casa � noroeste
			i--;
			j--;
			//verifica se o movimento ira capturar uma peca
			retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codConteudoIntermediario);
			//tratar erro da funcao TAB_ObterConteudoCasa
			if(retTAB != TAB_CondRetOK)
			{
				printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
				return JOG_CondRetErroTabuleiro;
			}//fim do if que trata o erro
			//verifica se uma peca foi encontrada
			if(pPeca !=NULL)
			{
				//limpa ponteiro para peca
				pPeca = NULL;
				
				//verifica se a peca a ser capturada eh do adversario
				if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
				{
					//encerra a busca
					break;
				}//fim do if que verifica se a peca a ser capturada eh do adversario
				
				//verifica se existe uma vaga para posicionar a peca apos a captura
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i-1, j-1, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				if(pPeca == NULL)
				{
					return JOG_CondRetOK;
				}
				else
				{
					pPeca = NULL;
					//encerra a busca
					break;
				}
				
			}//fim do if que verifica se uma peca foi encontrada
		}//fim do while que percorre todas as casas por onde a passa para verificar se a captura sera feita
		//fim do segundo caso: movimento para noroeste

		//terceiro caso: verifica se existe alguma peca a ser capturada para sudeste
		//inicializa as variaveis para percorrer o tabuleiro
		i=CoordLinhaInicial;
		j=CoordColunaInicial;
		//percorre todas as casas onde a dama irah percorrer em busca de pecas a serem capturadas
		while((i<6)&&(j<6)&&(i>=0)&&(j>=0))
		{
			//posiciona os indices na proxima casa � noroeste
			i++;
			j++;
			//verifica se o movimento ira capturar uma peca
			retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codConteudoIntermediario);
			//tratar erro da funcao TAB_ObterConteudoCasa
			if(retTAB != TAB_CondRetOK)
			{
				printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
				return JOG_CondRetErroTabuleiro;
			}//fim do if que trata o erro
			//verifica se uma peca foi encontrada
			if(pPeca !=NULL)
			{
				//limpa ponteiro para peca
				pPeca = NULL;
				
				//verifica se a peca a ser capturada eh do adversario
				if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
				{
					//encerra a busca
					break;
				}//fim do if que verifica se a peca a ser capturada eh do adversario
				
				//verifica se existe uma vaga para posicionar a peca apos a captura
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i+1, j+1, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				if(pPeca == NULL)
				{
					return JOG_CondRetOK;
				}
				else
				{
					pPeca = NULL;
					//encerra a busca
					break;
				}
				
			}//fim do if que verifica se uma peca foi encontrada
		}//fim do while que percorre todas as casas por onde a passa para verificar se a captura sera feita
		//fim do terceiro caso: movimento para sudeste

		//quarto e ultimo caso: verifica se existe alguma peca a ser capturada para sudoeste
		//inicializa as variaveis para percorrer o tabuleiro
		i=CoordLinhaInicial;
		j=CoordColunaInicial;
		//percorre todas as casas onde a dama irah percorrer em busca de pecas a serem capturadas
		while((i<6)&&(j>1)&&(i>=0)&&(j<8))
		{
			//posiciona os indices na proxima casa � noroeste
			i++;
			j--;
			//verifica se o movimento ira capturar uma peca
			retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i, j, &codConteudoIntermediario);
			//tratar erro da funcao TAB_ObterConteudoCasa
			if(retTAB != TAB_CondRetOK)
			{
				printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
				return JOG_CondRetErroTabuleiro;
			}//fim do if que trata o erro
			//verifica se uma peca foi encontrada
			if(pPeca !=NULL)
			{
				//limpa ponteiro para peca
				pPeca = NULL;
				
				//verifica se a peca a ser capturada eh do adversario
				if(((pJogo.codJogadorAtual==1)&&((codConteudoIntermediario=='p')||(codConteudoIntermediario=='P')))||((pJogo.codJogadorAtual==0)&&((codConteudoIntermediario=='b')||(codConteudoIntermediario=='B'))))
				{
					//encerra a busca
					break;
				}//fim do if que verifica se a peca a ser capturada eh do adversario
				
				//verifica se existe uma vaga para posicionar a peca apos a captura
				retTAB = TAB_ObterConteudoCasa (&pTab, &pPeca, i+1, j-1, &codConteudoIntermediario);
				//tratar erro da funcao TAB_ObterConteudoCasa
				if(retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao ler o conteudo da casa de destino\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}//fim do if que trata o erro
				if(pPeca == NULL)
				{
					return JOG_CondRetOK;
				}
				else
				{
					pPeca = NULL;
					//encerra a busca
					break;
				}
				
			}//fim do if que verifica se uma peca foi encontrada
		}//fim do while que percorre todas as casas por onde a passa para verificar se a captura sera feita
		//fim do quarto e ultimo caso: movimento para sudoeste

		//caso em que nao existe captura possivel
		return JOG_CondRetNaoExisteCapturaPossivel;

	}//fim do if que trata o caso de uma dama
		
		

} /* Fim fun��o: JOG Verificar Captura */



/***********************************************************************
*
*  Fun��o: JOG Contar Pontos
*
***********************************************************************/

JOG_tpCondRet JOG_ContarPontos (void)
{
	printf("\n%s possui %d pontos e %s possui %d pontos\n", pJogo.NomeJogadorBranco, pJogo.pontosJogadorBranco, pJogo.NomeJogadorPreto, pJogo.pontosJogadorPreto);
	if(pJogo.pontosJogadorBranco>pJogo.pontosJogadorPreto)
	{
		printf("(%s esta ganhando)\n", pJogo.NomeJogadorBranco);
	}
	else if(pJogo.pontosJogadorBranco<pJogo.pontosJogadorPreto)
	{
		printf("(%s esta ganhando)\n", pJogo.NomeJogadorPreto);
	}
	else if(pJogo.pontosJogadorBranco==pJogo.pontosJogadorPreto)
	{
		printf("(O jogo esta empatado)\n");
	}

	return JOG_CondRetOK;
} /* Fim fun��o: JOG Contar Pontos */



/***********************************************************************
*
*  Fun��o: JOG Solicitar Acao
*
***********************************************************************/

JOG_tpCondRet JOG_SolicitarAcao (JOG_tpCondRet (*GerenciarEmpate)(void))
{
	//variaveis utilizadas para obter condicoes de retorno das funcoes utlizadas
	JOG_tpCondRet retJOG = JOG_CondRetOK;
	TAB_tpCondRet retTAB = TAB_CondRetOK;
	
	//inicializa opcao e coordenadas
	int opcao = 0;
	int resposta = 0;
	int origemLinha = -1;
	int origemColuna = -1;
	int destinoLinha = -1;
	int destinoColuna = -1;


	while (opcao!=4)
	{
		//chama a funcao callback para verificar empate tecnico
		retJOG = GerenciarEmpate();
		//para o jogo empatado
		if(retJOG != JOG_CondRetOK)
		{
				break;
		}

		printf("\n\n==> Menu de opcoes do jogador %s\n", pJogo.NomeJogadorAtual);
		printf("1 - Mover Peca\n2 - Solicitar Empate\n3 - Solicitar Encerramento da Partida\n4 - Sair do Jogo\n");
		printf("\nEscolha uma opcao: ");
		scanf("%d", &opcao);
		
		//Opcao errada
		if(opcao < 1 || opcao > 4)
		{
			printf("\n\nOPCAO INVALIDA!!! Escolha novamente...\n");
		}

		//Mover Peca
		else if (opcao == 1)
		{
			printf("\n%s,\nDigite as coordenadas atuais e de destino do movimento a ser efetuado:\n", pJogo.NomeJogadorAtual);
			printf(">>> Coordenada da linha ATUAL: ");
			scanf("%d", &origemLinha);
			printf(">>> Coordenada da coluna ATUAL: ");
			scanf("%d", &origemColuna);
			printf(">>> Coordenada da linha de DESTINO: ");
			scanf("%d", &destinoLinha);
			printf(">>> Coordenada da coluna de DESTINO: ");
			scanf("%d", &destinoColuna);
			retJOG = JOG_VerificarMovimento(&pTab, origemLinha, origemColuna, destinoLinha, destinoColuna);
			if ((retJOG != JOG_CondRetOK) && (retJOG != JOG_CondRetMovimentoErrado))
			{
				printf("\n\nERRO!!! Ocorreu o erro %d ao verificar o movimento\n", retJOG);
			}
			else if (retJOG == JOG_CondRetMovimentoErrado)
			{
				printf("\n\nMOVIMENTO INVALIDO!!! Escolha uma opcao novamente...\n\n");
			}
			else
			{
				retJOG = JOG_MoverPeca(&pTab, origemLinha, origemColuna, destinoLinha, destinoColuna);
				if (retJOG != JOG_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao mover a peca\n", retJOG);
				}
				if((pJogo.pontosJogadorBranco==12)||(pJogo.pontosJogadorPreto==12))
				{
					return JOG_CondRetOK;
				}
			}


			retJOG = JOG_ContarPontos();

			retTAB = TAB_ExibirTabuleiro(&pTab);
			if (retTAB != TAB_CondRetOK)
			{
				printf("\n\nERRO!!! Ocorreu o erro %d ao exibir o tabuleiro\n", retTAB);
				return JOG_CondRetErroTabuleiro;
			}

		}

		//Solicitar Empate
		else if (opcao == 2)
		{
			if (pJogo.NomeJogadorAtual == pJogo.NomeJogadorBranco)
			{
				printf("\n\n>>> %s <<<\n", pJogo.NomeJogadorPreto);
			}
			else
			{
				printf("\n\n>>>> %s <<<\n>", pJogo.NomeJogadorBranco);
			}
			printf("\nO jogador %s solicitou terminar a partida em empate, voce aceita???\n",pJogo.NomeJogadorAtual);
			printf("1 - Sim\n2 - Nao\n");
			printf("Resposta: ");
			scanf("%d",&resposta);

			
			while(resposta!=1 && resposta!=2)
			{
				printf("\n\nRESPOSTA INVALIDA!!! Responda novamente...\n\n");
				printf("\nO jogador %s solicitou terminar a partida em empate, voce aceita???\n",pJogo.NomeJogadorAtual);
				printf("1 - Sim\n2 - Nao\n");
				printf("Resposta: ");
				scanf("%d",&resposta);
			}

			if (resposta == 1)
			{
				return JOG_CondRetSolicitarEmpate;
			}
			else
			{
				printf("\n\nSOLICITACAO DE EMPATE RECUSADA!!!\n");
				printf("\n\n>>> %s <<<\n",pJogo.NomeJogadorAtual);
				retTAB = TAB_ExibirTabuleiro(&pTab);
				if (retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao exibir o tabuleiro\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}
				
			}
		}

		//Solicitar Encerramento da Partida
		else if (opcao == 3)
		{
			if (pJogo.NomeJogadorAtual == pJogo.NomeJogadorBranco)
			{
				printf("\n\n>>> %s <<<\n", pJogo.NomeJogadorPreto);
			}
			else
			{
				printf("\n\n>>>> %s <<<\n>", pJogo.NomeJogadorBranco);
			}
			printf("\nO jogador %s solicitou o encerramento da partida, voce aceita???\n",pJogo.NomeJogadorAtual);
			printf("1 - Sim\n2 - Nao\n");
			printf("Resposta: ");
			scanf("%d",&resposta);

			while(resposta!=1 && resposta!=2)
			{
				printf("\n\nRESPOSTA INVALIDA!!! Responda novamente...\n\n");
				printf("\nO jogador %s solicitou o encerramento da partida, voce aceita???\n",pJogo.NomeJogadorAtual);
				printf("1 - Sim\n2 - Nao\n");
				printf("Resposta: ");
				scanf("%d",&resposta);
			}

			if (resposta == 1)
			{
				return JOG_CondRetSolicitarFim;
			}
			else
			{
				printf("\n\nSOLICITACAO DE ENCERRAMENTO DA PARTIDA RECUSADA!!!\n");
				printf("\n\n>>> %s <<<\n",pJogo.NomeJogadorAtual);
				retTAB = TAB_ExibirTabuleiro(&pTab);
				if (retTAB != TAB_CondRetOK)
				{
					printf("\n\nERRO!!! Ocorreu o erro %d ao exibir o tabuleiro\n", retTAB);
					return JOG_CondRetErroTabuleiro;
				}
			}
		}
		else if (opcao==4)
		{
			return JOG_CondRetSair;
		}
	}
	return JOG_CondRetJogoEmpatado;
} /* Fim fun��o: JOG Solicitar Acao */



/***********************************************************************
*
*  Fun��o: JOG Gerenciar Empate
*
***********************************************************************/

JOG_tpCondRet JOG_GerenciarEmpate (void)
{
	JOG_tpCondRet retJOG = JOG_CondRetOK;

	if(pJogo.numJogadasSemCaptura>=20)
	{
		printf("\n\n\n*******************************************************************");
		printf("\n                         FIM DE JOGO                               \n");
		printf("*******************************************************************\n\n");
		printf("\nResultado: ");
		printf("EMPATE!!!\n\n");
		printf("\nOBS: Foram contabilizadas 20 jogadas sucessivas sem captura.\n\n");
		return JOG_CondRetJogoEmpatado;
	}

	return JOG_CondRetOK;

} /* Fim fun��o: JOG Gerenciar Empate */



/***********************************************************************
*
*  Fun��o: JOG Finalizar Partida
*
***********************************************************************/

JOG_tpCondRet JOG_FinalizarPartida (void)
{
	
	JOG_tpCondRet retJOG = JOG_CondRetOK;
	TAB_tpCondRet retTAB = TAB_CondRetOK;

	//exclui todas as pecas que restam no tabuleiro e exclui o tabuleiro. Esta funcao desaloca todas as entidades alocadas na memoria
	retTAB = TAB_DestruirTabuleiro(&pTab);
	//trata erro gerado pela funcao TAB_DestruirTabuleiro
	if(retTAB != TAB_CondRetOK)
	{
		printf("\nERRO GRAVE!!! A funcao TAB_DestruirTabuleiro retornou %d e nao liberou a memoria\n", retTAB);
		return JOG_CondRetErroJogo;
	}//fim do if que trata o erro gerado pela funcao TAB_DestruirTabuleiro
	
	return JOG_CondRetOK;

} /* Fim fun��o: JOG Finalizar Partida */



/***********************************************************************
*
*  Fun��o: JOG Main
*
***********************************************************************/

int main (void)
{
	JOG_tpCondRet ret1, ret2, ret3;

	char c;//para evitar o fechamento automatico da janela apos o fim do programa

	//Inicializa o jogo como um todo
	ret1 = JOG_IniciarPartida();

	/* if Inicializar */
	if(ret1 == JOG_CondRetErroTabuleiro)
	{
		printf("\n\nERRO AO INICIALIZAR A PARTIDA!!!\n");
	}
	else
	{
		//Exibe o menu de a��es
		ret2 = JOG_SolicitarAcao(JOG_GerenciarEmpate);//a funcao JOG_GerenciarEmpate eh uma funcao callback que serve para gerenciar o numero de partidas sem ocorrencia de impate podem ocorrer

		//if resultados
		if ( (ret2 == JOG_CondRetOK) || (ret2 == JOG_CondRetSolicitarEmpate) || (ret2 == JOG_CondRetSolicitarFim) || (ret2 == JOG_CondRetSair) )
		{
			printf("\n\n\n*******************************************************************");
			printf("\n                         FIM DE JOGO                               \n");
			printf("*******************************************************************\n\n");
			printf("\nResultado: ");
		
			if (ret2 == JOG_CondRetOK)
			{
				if( pJogo.pontosJogadorBranco == 12 )
					printf("%s GANHOU!!!\n\n",pJogo.NomeJogadorBranco);
				else
					printf("%s GANHOU!!!\n\n",pJogo.NomeJogadorPreto);
				printf("\nPLACAR: %s %d x %d %s\n\n",pJogo.NomeJogadorBranco, pJogo.pontosJogadorBranco, pJogo.pontosJogadorPreto, pJogo.NomeJogadorPreto);
			}			
			if (ret2 == JOG_CondRetSolicitarEmpate)
			{
				printf("EMPATE!!!\n\n");
				printf("\nOBS: Os dois jogadores concordaram em terminar a partida empatados.\n\n");
			}
			if (ret2 == JOG_CondRetSolicitarFim)
			{
				if( pJogo.pontosJogadorBranco > pJogo.pontosJogadorPreto )
					printf("%s GANHOU!!!\n\n",pJogo.NomeJogadorBranco);
				else if ( pJogo.pontosJogadorBranco < pJogo.pontosJogadorPreto )
					printf("%s GANHOU!!!\n\n",pJogo.NomeJogadorPreto);
				else
					printf("EMPATE!!!\n\n");
				printf("\nOBS: Os dois jogadores concordaram em encerrar a partida como estava.\n\n");
				printf("\nPLACAR: %s %d x %d %s\n\n",pJogo.NomeJogadorBranco, pJogo.pontosJogadorBranco, pJogo.pontosJogadorPreto, pJogo.NomeJogadorPreto);
			}
			if (ret2 == JOG_CondRetSair)
			{
				if ( 0 == pJogo.codJogadorAtual )
					printf("%s GANHOU!!!\n\n",pJogo.NomeJogadorPreto);
				else
					printf("%s GANHOU!!!\n\n",pJogo.NomeJogadorBranco);
				printf("\nOBS: O jogador %s saiu da partida.\n\n",pJogo.NomeJogadorAtual);
			}
		}//fim do if resultados

		//if finalizar
		if (  ret2 == JOG_CondRetSolicitarEmpate || ret2 == JOG_CondRetSolicitarFim || ret2 == JOG_CondRetSair || ret2 == JOG_CondRetJogoEmpatado)
		{
			//Finaliza uma partida
			ret3 = JOG_FinalizarPartida();
			//trata erro gerado pela funcao JOG_FinalizarPartida
			if(ret3 != JOG_CondRetOK)
			{
				printf("\n\nERRO!!! Ocorreu o erro %d ao finalizar a partida\n", ret3);
			}//fim do if que trata o erro gerado pela funcao JOG_FinalizarPartida
		}
		else
		{
			printf("\n\nERRO AO FINALIZAR A PARTIDA!!!\n");
		}//fim do if finalizar

	}//fim do if inicializar

	printf("\n\n\nTecle qualquer coisa para fechar a janela\n");
	c = getchar();
	c = getchar();

	return 0;
} /* Fim fun��o: JOG Main */



/********** Fim do m�dulo de implementa��o: JOG Jogo de Damas **********/
