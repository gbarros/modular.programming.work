#if ! defined( TABULEIRO_ )
#define TABULEIRO_
/**********************************************************************************************************
*
*  -> M�dulo de defini��o: TAB M�dulo de tabuleiro gen�rico
*
*  Arquivo gerado: TABULEIRO.h
*  Letras identificadoras: TAB
*
*  Autores: tr - Tadeu Ribeiro
*			ag - Alexandre Garcia
*			jc - Jocimar Candido
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      tr, al, jc   18/set/2012    in�cio do desenvolvimento
*      1.1      tr, al, jc   03/out/2012    revis�o e modifica��o das explica��es, assertivas e dos prot�tipos das fun��es
*      1.2      tr, al, jc   07/out/2012    adi��o de novas fun��es juntamente com seus coment�rios
*
*  -> Descri��o do m�dulo:
*     Este m�dulo implementa um conjunto de fun��es que manipulam um tabuleiro gen�rico para 
*     que possa ser utilizado futuramente em qualquer tipo de jogo de tabuleiro.
*     
**********************************************************************************************************/

#if defined( TABULEIRO_OWN )
   #define TABULEIRO_EXT
#else
   #define TABULEIRO_EXT extern
#endif

#include   "PECA2.h"


/***** Declara��es exportadas pelo m�dulo *****/

/* Tipo refer�ncia para uma casa */

typedef struct TAB_tagCasa * TAB_tppCasa ;

/* Tipo refer�ncia para um tabuleiro */

typedef struct TAB_tagTabuleiro * TAB_tppTabuleiro ;

/***********************************************************************
*
*  Tipo de dados: TAB Condi��es de retorno
*
*  Descri��o do tipo:
*     Condi��es de retorno das fun��es do m�dulo tabuleiro
*
*  Fun��es por N�mero:      
*        CriarTabuleiro     = 1 
*        DestruirTabuleiro  = 2 
*        ExibirTabuleiro    = 3 
*        ObterConteudoCasa  = 4 
*        InserirPeca        = 5 
*        RetirarPeca        = 6
*
***********************************************************************/

   typedef enum {

         TAB_CondRetOK ,
               /* Concluiu corretamente */
			   /* Fun��es que utilizam : 1, 2, 3, 4, 5, 6 */

         TAB_CondRetFaltouMemoria ,
               /* Faltou mem�ria ao tentar criar o tabuleiro */
			   /* Fun��es que utilizam : 1 */

		TAB_CondRetErroEstrutura ,
               /* Tabuleiro j� existe */
               /* Fun��es que utilizam : 1, 4, 5, 6 */

		 TAB_CondRetTabInexistente ,
               /* Tabuleiro inv�lido ou inexistente (N�o foi criado) */
			   /* Fun��es que utilizam : 2, 3, 4, 5, 6 */
				 
	     TAB_CondRetPecaInexistente ,
               /* Pe�a inv�lida ou inexistente (N�o foi criada) */
			   /* Fun��es que utilizam : 5, 6 */

		 TAB_CondRetErroPeca
               /* Erro ao utilizar uma fun��o da estrutura Peca */
			   /* Fun��es que utilizam : 4, 6 */


   } TAB_tpCondRet ;


/***********************************************************************
*
*  Tipo de dados: ARV Modos de deturpar
*
***********************************************************************/


#ifdef _DEBUG

   typedef enum {

       //Modifica o tipo de espa�o Tabuleiro
	   DeturparTipoTabuleiro = 1,

	   //Modifica o tipo de espa�o Casas
	   DeturparTipoCasas =2,

	   //Modifica o codigo de uma casa
	   DeturparCodigoCasa = 3,

	   //Modifica tipo do conteudo da casa
	   DeturparTipoConteudoCasa = 4,

	   //Modifica uma casa vazia
	   DeturparCasaVazia = 5



   } TAB_tpModosDeturpacao ;

#endif


/***********************************************************************
*
*  -> Fun��o: TAB Criar Tabuleiro
*
*  -> Descri��o da fun��o:
*     Cria um tabuleiro quadrado com um dado n�mero de linhas e colunas.
*
*  -> Par�metros:
*	  pTab		      - Ponteiro para o tabuleiro.
*	  NumLinhas		  - N�mero de linhas que o tabuleiro a ser criado 
*                       deve conter.
*	  NumColunas	  - N�mero de colunas que o tabuleiro a ser criado 
*                       deve conter.
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetFaltouMemoria
*	  TAB_CondRetErroEstrutura
*
*  -> Assertivas:
*	  Entrada - Recebe o ponteiro para o tipo tabuleiro, por refer�ncia, a ser criado juntamente 
*     com os tipos int NumLinhas e int NumColunas. Estes ser�o os atributos n�mero de 
*     linhas e n�mero de colunas a preencherem a estrutura do tabuleiro. 
*
*     Sa�da - Se executou corretamente retorna, por refer�ncia, o tabuleiro
*     com o n�mero de linhas e n�mero de colunas passados como par�metros associados. 
*
***********************************************************************/

TAB_tpCondRet TAB_CriarTabuleiro (TAB_tppTabuleiro * pTab, int NumLinhas, int NumColunas) ;

/***********************************************************************
*
*  -> Fun��o: TAB Destruir Tabuleiro
*
*  -> Descri��o da fun��o:
*     Destr�i o tabuleiro liberando toda mem�ria utilizada por aquela 
*     estrutura.
*
*  -> Par�metros:
*	  pTab		  - Ponteiro para o tabuleiro.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe o ponteiro para a estrutura tabuleiro, por refer�ncia, que utilizou e alocou
*     mem�ria e que se deseja destruir.
*
*     Sa�da - Retorna o tabuleiro por refer�ncia, desalocado, com toda mem�ria utilizada pela 
*     estrutura do tabuleiro sendo liberada.
*     Caso o tabuleiro n�o exista retorna o retorno correspondente.
*
***********************************************************************/

TAB_tpCondRet TAB_DestruirTabuleiro (TAB_tppTabuleiro * pTab) ;

/***********************************************************************
*
*  -> Fun��o: TAB Exibir Tabuleiro
*
*  -> Descri��o da fun��o:
*     Imprime o tabuleiro na tela com ou sem pe�as conforme o tipo de 
*     jogo e da situa��o durante uma partida.
*
*  -> Par�metros:
*	  pTab		  - Ponteiro para o tabuleiro.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe o ponteiro para a estrutura tabuleiro, por refer�ncia, que ir� exibir na tela.
*
*     Sa�da - Exibe o tabuleiro com todas as casas e seus respectivos conte�dos.
*     Caso o tabuleiro n�o exista retorna o retorno correspondente.
*
***********************************************************************/

TAB_tpCondRet TAB_ExibirTabuleiro (TAB_tppTabuleiro * pTab) ;

/***********************************************************************
*
*  -> Fun��o: TAB Obter Conteudo Casa
*
*  -> Descri��o da fun��o:
*     Obt�m o conte�do da casa.
*
*  -> Par�metros:
*	  pTab		   - Ponteiro para o tabuleiro.
*	  pPeca		   - Ponteiro para a pe�a que est� na casa em quest�o.
*	  CoordLinha   - Coordenada x (linha) da casa em quest�o.
*	  CoordColuna  - Coordenada y (coluna) da casa em quest�o.
*	  ConteudoCasa - Ponteiro para o tipo char de conte�do da casa em quest�o.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*     TAB_CondRetErroEstrutura
*     TAB_CondRetErroPeca
*
*  -> Assertivas:
*	  Entrada - Recebe uma posi��o no tabuleiro pelos par�metros CoordLinha 
*     e CoordColuna juntamente com o seu conte�do pelo ConteudoCasa
*     e pPeca.
*
*     Sa�da - Retorna a situa��o da casa pelo par�metro ConteudoCasa. Se a 
*     casa estiver vazia, no par�metro ConteudoCasa retorna 0 caso ela seja 
*     clara ou 1 se for escura e retorna NULL no par�metro Peca. Se ela estiver 
*     ocupada, no par�metro ConteudoCasa retorna o c�digo da pe�a que nela se 
*     encontra e retorna a pe�a no par�metro Peca.
*
***********************************************************************/

TAB_tpCondRet TAB_ObterConteudoCasa ( TAB_tppTabuleiro * pTab, PEC_tppPeca * pPeca, int CoordLinha, int CoordColuna, char * ConteudoCasa ) ;

/***********************************************************************
*
*  -> Fun��o: TAB Inserir Peca
*
*  -> Descri��o da fun��o:
*     Isere uma pe�a numa dada coordenada do tabuleiro.
*
*  -> Par�metros:
*	  pTab		   - Ponteiro para o tabuleiro.
*	  pPeca		   - Ponteiro para a pe�a que se deseja inserir no tabuleiro.
*	  CoordLinha   - Coordenada x (linha) da casa onde se deseja inserir a pe�a.
*	  CoordColuna  - Coordenada y (coluna) da casa onde se deseja inserir a pe�a.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*     TAB_CondRetPecaInexistente
*	  TAB_CondRetErroEstrutura
*
*  -> Assertivas:
*	  Entrada - Recebe uma posi��o no tabuleiro pelos par�metros CoordLinha e CoordColuna
*     onde se deseja inserir a pe�a pPeca(recebida por refer�ncia) no tabuleiro pTab, tamb�m recebido
*     por refer�ncia.
*
*     Sa�da - Retorna o tabuleiro, por refer�ncia, com a pe�a pPeca inclusa nas coordenadas
*     CoordLinha e CoordColuna do tabuleiro. Caso contr�rio retorna a condi��o de retorno correspondente.
*
***********************************************************************/

TAB_tpCondRet TAB_InserirPeca (TAB_tppTabuleiro * pTab, PEC_tppPeca * pPeca, int CoordLinha, int CoordColuna) ;

/***********************************************************************
*
*  -> Fun��o: TAB Retirar Peca
*
*  -> Descri��o da fun��o:
*     Retira a pe�a contida numa dada coordenada do tabuleiro.
*
*  -> Par�metros:
*	  pTab		   - Ponteiro para o tabuleiro.
*	  CoordLinha   - Coordenada x (linha) da casa onde se deseja retirar uma pe�a.
*	  CoordColuna  - Coordenada y (coluna) da casa onde se deseja retirar uma pe�a.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*     TAB_CondRetPecaInexistente
*	  TAB_CondRetErroEstrutura
*	  TAB_CondRetErroPeca
*
*  -> Assertivas:
*	  Entrada - Recebe uma posi��o no tabuleiro pelos par�metros CoordLinha e CoordColuna de
*     onde se deseja retirar uma pe�a contida no tabuleiro passado por refer�ncia.
*
*     Sa�da - Retorna o tabuleiro, por refer�ncia, com a pe�a exclu�da das coordenadas
*     CoordLinha e CoordColuna fornecidas. Caso contr�rio retorna a condi��o de retorno correspondente.
*
***********************************************************************/

TAB_tpCondRet TAB_RetirarPeca (TAB_tppTabuleiro * pTab, int CoordLinha, int CoordColuna) ;


#ifdef _DEBUG

/***************************************************************************
*
*  Fun��o: TAB  Verificar Tabuleiro
*
*  -> Descri��o da fun��o:
*     Verifica completamente um determinado tabuleiro e marca todos os espa�os por ele ocupados.
*
*  -> Par�metros:
*	  pTab		   - Ponteiro para o tabuleiro.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*	  TAB_CondRetErroEstrutura
*
*  -> Assertivas:
*	  Entrada - Recebe o ponteiro para o tipo tabuleiro, por refer�ncia, a ser verificado.
*
*     Sa�da - Retorna o tabuleiro, por refer�ncia, verificado.
*
****************************************************************************/

TAB_tpCondRet TAB_VerificarTabuleiro( TAB_tppTabuleiro * pTab ) ;

#endif

#ifdef _DEBUG

/***************************************************************************
*
*  Fun��o: TAB  Deturpar Tabuleiro
*
*  -> Descri��o da fun��o:
*     Corrompe elementos espec�ficos da estrutura do tabuleiro. Essa fun��o destina-se 
*     a preparar os cen�rios de teste dos casos de teste utilizados ao testar os 
*     verificadores estruturais do tabuleiro.
*
*  -> Par�metros:
*	  pTab		   - Ponteiro para o tabuleiro.
*     ModoDeturpar - identifica como deve ser feita a deturpa��o
*                    TAB_tpModosDeturpacao identifica os modos de
*                    deturpa��o conhecidos.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe o ponteiro para o tipo tabuleiro, por refer�ncia, a ser deturpado.
*
*     Sa�da - Retorna o tabuleiro, por refer�ncia, deturpado.
*
****************************************************************************/

TAB_tpCondRet TAB_Deturpar( TAB_tppTabuleiro * pTab, TAB_tpModosDeturpacao ModoDeturpar ) ;

#endif


#undef TABULEIRO_EXT

/********** Fim do m�dulo de defini��o: TAB M�dulo de tabuleiro gen�rico **********/

#else
#endif
