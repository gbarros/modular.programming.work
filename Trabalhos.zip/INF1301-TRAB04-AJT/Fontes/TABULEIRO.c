/**********************************************************************************************************
*
*  -> M�dulo de implementa��o: TAB M�dulo de tabuleiro gen�rico
*
*  Arquivo gerado: TABULEIRO.c
*  Letras identificadoras: TAB
*
*  Autores: tr - Tadeu Ribeiro
*			ag - Alexandre Garcia
*			jc - Jocimar Candido
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      tr, al, jc   26/set/2012    in�cio do desenvolvimento
*      1.1      tr, al, jc   03/out/2012    revis�o do m�dulo inteiro e implementa��o de manipuladores de c�digo
*      1.2      tr, al, jc   07/out/2012    adi��o de novas fun��es e revis�o do m�dulo inteiro
* 
**********************************************************************************************************/

#include   <stdlib.h>
#include   <stdio.h>
#include   <string.h>
#include   <memory.h>
#include   <malloc.h>
#include   <assert.h>

#include   "TABULEIRO.h"

#ifdef _DEBUG
   #include   "Generico.h"
   #include   "Conta.h"
   #include   "cespdin.h"
   #include   "IdTiposEspaco.def"
#endif


/***********************************************************************
*
*  Tipo de dados: TAB Estrutura de uma casa
*
***********************************************************************/

typedef struct TAB_tagCasa{

	PEC_tppPeca Peca;
		/* pe�a que ir� ocupar a casa */
	char Casa;
		/* conte�do da casa */

#ifdef _DEBUG
	char Tipo;
		/* tipo da estrutura armazenada na casa: 
		0: casa branca vazia
		1: casa preta vazia
		p: pe�a
		c: char
		i: int
		d: double
		s: string 
		t: tabuleiro
		k: casa */
#endif


}TAB_tpCasa;

/***********************************************************************
*
*  Tipo de dados: TAB Estrutura de um tabuleiro
*
***********************************************************************/

typedef struct TAB_tagTabuleiro{

	int NumLinhas;
		/* n�mero de linhas do tabuleiro */

	int NumColunas;
		/* n�mero de colunas do tabuleiro */

	TAB_tpCasa * Tab;
		/* matriz de casas representada por um vetor a ser inicializada. Para acessar o elemento ij da matriz deve-se fazer: v[i*NumLinhas + j] */

	//para a estrutura auto verificavel esta estrutura nao necessita de um campo "tamanho" dado que para calcular seu tamanha basta fazer NumLinhas*NumColunas

}TAB_tpTabuleiro;



/*****  C�digo das fun��es exportadas pelo m�dulo  *****/

/***********************************************************************
*
*  Fun��o: TAB Criar Tabuleiro
*
***********************************************************************/

TAB_tpCondRet TAB_CriarTabuleiro (TAB_tppTabuleiro * pTab, int NumLinhas, int NumColunas)
{
	int i, j; //indices para percorrer a matriz
	
#ifdef _DEBUG
	CNT_CONTAR( "TAB_CriarTabuleiro" );
#endif

	/* Verifica a exist�ncia de um tabuleiro j� criado */
	if ( (*pTab) != NULL)
	{
		return TAB_CondRetErroEstrutura;
	} /* if */

	/* Aloca espa�o na mem�ria para o tabuleiro */
	(*pTab) = ( TAB_tppTabuleiro ) malloc ( sizeof( TAB_tpTabuleiro ) ) ;

	/* Verifica espa�o na mem�ria */
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetFaltouMemoria ;
	} /* If */

#ifdef _DEBUG
	CED_DefinirTipoEspaco( (*pTab) , TAB_TipoEspacoTabuleiro ) ;
#endif

	/* Faz as atribui��es */
	(*pTab)->NumLinhas = NumLinhas;
	(*pTab)->NumColunas = NumColunas;
	(*pTab)->Tab = ( TAB_tppCasa) malloc ( NumLinhas * NumColunas * sizeof( TAB_tpCasa ) ) ;

#ifdef _DEBUG
	CED_DefinirTipoEspaco( (*pTab)->Tab , TAB_TipoEspacoCasas ) ;
#endif

	/* incializa as casas */

	for ( i=0; i<NumLinhas; i++)
	{
		for ( j=0; j<NumColunas; j++)
		{
			(*pTab)->Tab[i*NumLinhas+j].Peca=NULL;
			if ((i%2 == 0) && (j%2 == 0))
			{
				(*pTab)->Tab[i*NumLinhas+j].Casa='0';
#ifdef _DEBUG
				(*pTab)->Tab[i*NumLinhas+j].Tipo='0';
#endif
			}
			else if ((i%2 == 1) && (j%2 == 1))
			{
				(*pTab)->Tab[i*NumLinhas+j].Casa='0';
#ifdef _DEBUG
				(*pTab)->Tab[i*NumLinhas+j].Tipo='0';
#endif
			}
			else
			{
				(*pTab)->Tab[i*NumLinhas+j].Casa='1';
#ifdef _DEBUG
				(*pTab)->Tab[i*NumLinhas+j].Tipo='1';
#endif
			}

		}
	}

	return TAB_CondRetOK ;

} /* Fim fun��o: TAB Criar Tabuleiro */



/***********************************************************************
*
*  Fun��o: TAB Destruir Tabuleiro
*
***********************************************************************/

TAB_tpCondRet TAB_DestruirTabuleiro (TAB_tppTabuleiro * pTab)
{
    int i, j; //indices para percorrer a matriz
	PEC_tpCondRet pecRet;

#ifdef _DEBUG
	CNT_CONTAR( "TAB_DestruirTabuleiro" ) ;
#endif

	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	}/* if */
	for ( i=0; i<(*pTab)->NumLinhas; i++)
	{
		for ( j=0; j<(*pTab)->NumColunas; j++)
		{
			if ( (*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca != NULL )
			{
				pecRet = PEC_ExcluirPeca(&(*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca);
			}
		}
	}
	free( (*pTab)->Tab );
	free( (*pTab) );
	
	(*pTab) = NULL;
	
	return TAB_CondRetOK ;

} /* Fim fun��o: TAB Destruir Tabuleiro */



/***********************************************************************
*
*  Fun��o: TAB Exibir Tabuleiro
*
***********************************************************************/

TAB_tpCondRet TAB_ExibirTabuleiro (TAB_tppTabuleiro * pTab)
{
	int i, j; //indices para percorrer a matriz
	PEC_tpCondRet pecRet;
	char peca;

#ifdef _DEBUG
	CNT_CONTAR( "TAB_ExibirTabuleiro" ) ;
#endif

	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Desenha o tabuleiro na tela */
	printf("\n   ");
	for (j=0; j<(*pTab)->NumColunas; j++)
	{
		printf("%d ", j);
	}
	printf("\n   ");
	for (j=0; j<(*pTab)->NumColunas; j++)
	{
		printf("_ ");
	}

	for ( i=0; i<(*pTab)->NumLinhas; i++)
	{
		printf("\n%d| ", i);
		for ( j=0; j<(*pTab)->NumColunas; j++)
		{
			if ( (*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca != NULL )
			{
				pecRet = PEC_ObterCodigoPeca(&(*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca, &peca);
				printf("%c ", peca);
			}
			else
			{
				printf("%c ",(*pTab)->Tab[i*(*pTab)->NumLinhas+j].Casa);
			}
		}
	}

	return TAB_CondRetOK ;

} /* Fim fun��o: TAB Exibir Tabuleiro */



/***********************************************************************
*
*  Fun��o: TAB Obter Conteudo Casa
*
***********************************************************************/

TAB_tpCondRet TAB_ObterConteudoCasa ( TAB_tppTabuleiro * pTab, PEC_tppPeca * pPeca, int CoordLinha, int CoordColuna, char * ConteudoCasa )
{
	PEC_tpCondRet pecRet;

#ifdef _DEBUG
	CNT_CONTAR( "TAB_ObterConteudoCasa" ) ;
#endif

	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Verifica se a coordenada existe */
	if ((CoordLinha>=(*pTab)->NumLinhas)||(CoordColuna>=(*pTab)->NumColunas))
	{
		return TAB_CondRetErroEstrutura;
	}

	/* Verifica se a pe�a existe */	
	if ( (*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca == NULL )
	{
		(*ConteudoCasa) = (*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Casa;
	}
	else
	{
		(*pPeca)=(*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca;
		pecRet = PEC_ObterCodigoPeca(&(*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca, ConteudoCasa);
		if(pecRet != PEC_CondRetOK)
		{
			return TAB_CondRetErroPeca;
		}
	}
	
	return TAB_CondRetOK ;
	
} /* Fim fun��o: TAB Obter Conteudo Casa */


/***********************************************************************
*
*  Fun��o: TAB Inserir Peca
*
***********************************************************************/

TAB_tpCondRet TAB_InserirPeca (TAB_tppTabuleiro * pTab, PEC_tppPeca * pPeca, int CoordLinha, int CoordColuna)
{

#ifdef _DEBUG
	CNT_CONTAR( "TAB_InserirPeca" ) ;
#endif

	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Verifica se a peca existe */
	if ( (*pPeca) == NULL )
	{
		return TAB_CondRetPecaInexistente;
	} /* if */

	/* Verifica se a coordenada existe */
	if ((CoordLinha>=(*pTab)->NumLinhas)||(CoordColuna>=(*pTab)->NumColunas))
	{
		return TAB_CondRetErroEstrutura;
	}

	(*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca = (*pPeca);

#ifdef _DEBUG
	(*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Tipo='p';
#endif
	
	return TAB_CondRetOK ;
	
} /* Fim fun��o: TAB Inserir Peca */


/***********************************************************************
*
*  Fun��o: TAB Retirar Peca
*
***********************************************************************/

TAB_tpCondRet TAB_RetirarPeca (TAB_tppTabuleiro * pTab, int CoordLinha, int CoordColuna)
{
	PEC_tpCondRet pecRet;

#ifdef _DEBUG
	CNT_CONTAR( "TAB_RetirarPeca" ) ;
#endif

	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Verifica se a coordenada existe */
	if ((CoordLinha>=(*pTab)->NumLinhas)||(CoordColuna>=(*pTab)->NumColunas))
	{
		return TAB_CondRetErroEstrutura;
	}

	/* Verifica se a pe�a existe */	
	if ( (*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca == NULL )
	{
		return TAB_CondRetPecaInexistente;
	} /* if */

	pecRet = PEC_ExcluirPeca(&((*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca));
	(*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca = NULL;
	
	if(pecRet != PEC_CondRetOK)
	{
		return TAB_CondRetErroPeca;
	}

#ifdef _DEBUG
	if ((CoordLinha%2 == 0) && (CoordColuna%2 == 0))
	{
		(*pTab)->Tab[CoordLinha*((*pTab)->NumLinhas)+CoordColuna].Tipo='0';
	}
	else if ((CoordLinha%2 == 1) && (CoordColuna%2 == 1))
	{
		(*pTab)->Tab[CoordLinha*((*pTab)->NumLinhas)+CoordColuna].Tipo='0';
	}
	else
	{
		(*pTab)->Tab[CoordLinha*((*pTab)->NumLinhas)+CoordColuna].Tipo='1';
	}
#endif

	return TAB_CondRetOK ;
	
} /* Fim fun��o: TAB Retirar Peca */


#ifdef _DEBUG

/***************************************************************************
*
*  Fun��o: TAB  Verificar Tabuleiro
*
****************************************************************************/

TAB_tpCondRet TAB_VerificarTabuleiro( TAB_tppTabuleiro * pTab )
{
	//TAB_tppTabuleiro pTab = NULL;
	//TAB_tpCasa * Tab = NULL;
	
	int i, j; //indices para percorrer a matriz
	PEC_tpCondRet pecRet;
	char codigoCasa;
	char codigoPeca;
	char tipoConteudoCasa;

	//marca todos os espa�os inativos
	CED_MarcarTodosEspacosInativos();

	//verifica se o tabuleiro existe
	if ( (*pTab) == NULL )
	{
		TST_NotificarFalha("Ponteiro para o tabuleiro encontra-se nulo");
		return TAB_CondRetTabInexistente;
	}/* if */

	//verifica se o espaco alocado para o tabuleiro � do tipo tabuleiro
	if((CED_ObterTipoEspaco((*pTab)))!=TAB_TipoEspacoTabuleiro)
	{
		TST_NotificarFalha("O ponteiro para o tabuleiro nao aponta para um espaco valido: TipoEspacoTabuleiro\n");
		return TAB_CondRetErroEstrutura;
	}
	
	//verifica se o espaco alocado para as casas � do tipo casas
	if((CED_ObterTipoEspaco((*pTab)->Tab))!=TAB_TipoEspacoCasas)
	{
		TST_NotificarFalha("O ponteiro para as casas nao aponta para um espaco valido: TipoEspacoCasas\n");
		return TAB_CondRetErroEstrutura;
	}

	//verifica todas as casas
	for ( i=0; i<(*pTab)->NumLinhas; i++)
	{
		for ( j=0; j<(*pTab)->NumColunas; j++)
		{
			codigoPeca = '\0';
			codigoCasa = (*pTab)->Tab[i*(*pTab)->NumLinhas+j].Casa;
			tipoConteudoCasa = (*pTab)->Tab[i*(*pTab)->NumLinhas+j].Tipo;

			//verifica se o codigo da casa esta correto
			if( (codigoCasa!='0') && (codigoCasa!='1') )
			{
				TST_NotificarFalha("Umas das casas do tabuleiro possui um codigo identificador da casa fora dos padroes");
				return TAB_CondRetErroEstrutura;
			}

			//verifica o caso em que exista uma peca na casa
			if ( (*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca != NULL )
			{
				pecRet = PEC_ObterCodigoPeca(&(*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca, &codigoPeca);
				
				//verifica se a peca pode ser manipulada normalmente

				if(pecRet != PEC_CondRetOK)
				{
					TST_NotificarFalha("Ocorre um erro ao tentar manipular uma peca contida numa casa");
					return TAB_CondRetErroEstrutura;
				}

				//verifica o tipo do elemento armazenado na casa
				if ( tipoConteudoCasa != 'p')
				{
					TST_NotificarFalha("Uma casa contem um elemento estranho nao esperado");
					return TAB_CondRetErroEstrutura;
				} 

			}
			//verifica o caso de uma casa vazia
			else
			{
				//verifica o tipo do elemento armazenado na casa
				if( tipoConteudoCasa!=codigoCasa)
				{
					TST_NotificarFalha("O tipo de elemento na casa eh diferente do tipo da casa");
					return TAB_CondRetErroEstrutura;
				}
			}
		}
	}

	
	CED_MarcarEspacoAtivo( (*pTab)->Tab ) ;

	CED_MarcarEspacoAtivo( (*pTab) ) ;

    return TAB_CondRetOK;

   } /* Fim fun��o: TAB  Verificar Tabuleiro */

#endif


#ifdef _DEBUG

/***************************************************************************
*
*  Fun��o: TAB  Deturpar Tabuleiro
*
*  *************************************************************************/

TAB_tpCondRet TAB_Deturpar( TAB_tppTabuleiro * pTab, TAB_tpModosDeturpacao ModoDeturpar )
{
	//indices para percorrer o tabuleiro
	int i, j;
	
	/* Verifica se o tabuleiro existe */
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */
	
	switch(ModoDeturpar)
	{
		//Modifica o tipo de espa�o Tabuleiro
	case DeturparTipoTabuleiro :
		{
			CED_DefinirTipoEspaco((*pTab), CED_ID_TIPO_VALOR_NULO);
			break;
		}//fim modifica tipo de espa�o Tabuleiro
		
		//Modifica o tipo de espa�o Casas
	case DeturparTipoCasas :
		{
			CED_DefinirTipoEspaco((*pTab)->Tab, CED_ID_TIPO_VALOR_NULO);
			break;
		}//fim modifica tipo de espa�o Casas
		
		//Modifica o codigo de uma casa
	case DeturparCodigoCasa :
		{
			(*pTab)->Tab[30].Casa='!';
			break;
		}//fim modifica codigo de uma casa

		//Modifica tipo do conteudo da casa
	case DeturparTipoConteudoCasa :
		{
			//percorre o tabuleiro em busca de um peca para deturpar
			for ( i=0; i<(*pTab)->NumLinhas; i++)
			{
				for ( j=0; j<(*pTab)->NumColunas; j++)
				{
					if((*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca != NULL)
					{
						(*pTab)->Tab[i*(*pTab)->NumLinhas+j].Tipo='!';
						break;
					}
				}

				if((*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca != NULL)
				{
					break;
				}
			}
			break;
		}//fim modifica tipo de conteudo de uma casa

		//Modifica uma casa vazia
	case DeturparCasaVazia :
		{
			if((*pTab)->Tab[0].Peca != NULL)
			{
				TAB_RetirarPeca (pTab, 0, 0) ;
			}

			(*pTab)->Tab[0].Tipo='!';
			break;
		}//fim modifica uma casa vazia

	}

	return TAB_CondRetOK;

} /* Fim fun��o: TAB  Deturpar Tabuleiro */

#endif



/********** Fim do m�dulo de implementa��o: TAB Tabuleiro gen�rico **********/

