/***************************************************************************
*  -> M�dulo de implementa��o: TTAB M�dulo de teste espec�fico para tabuleiro
*
*  Arquivo gerado: TEST_TAB.C
*  Letras identificadoras: TTAB
*
*  Autores: tr - Tadeu Ribeiro
*			ag - Alexandre Garcia
*			jc - Jocimar Candido
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      tr, al, jc   07/out/2012    in�cio do desenvolvimento
*
*  -> Descri��o do m�dulo:
*     Este m�dulo cont�m as fun��es espec�ficas para o teste do
*     m�dulo tabuleiro.
*
*  -> Interface com o usu�rio pessoa:
*     Comandos de teste espec�ficos para testar o m�dulo tabuleiro:
*
*		"=criar"		     - chama a fun��o TAB_CriarTabuleiro( )
*		"=destruir"          - chama a fun��o TAB_DestruirTabuleiro( )
*		"=exibir"            - chama a fun��o TAB_ExibirTabuleiro( )
*		"=obter"             - chama a fun��o TAB_ObterConteudoCasa( )
*		"=colocarpeca"		 - chama a fun��o TAB_InserirPeca( ) 
*		"=retirarpeca"       - chama a fun��o TAB_RetirarPeca( )
*
***************************************************************************/

#include    <string.h>
#include    <stdio.h>

#include    "TST_ESPC.H"

#include    "generico.h"
#include    "lerparm.h"

#include    "TABULEIRO.h"
#include    "PECA1.h"

/* Tabela dos nomes dos comandos de teste espec�ficos */

#define		RESET_CMD					"=resetatabuleiro"
#define     CRIAR_TAB_CMD               "=criar"
#define     DESTROI_CMD                 "=destruir"
#define     EXIBIR_TAB_CMD              "=exibir"
#define     OBTER_CONTEUDOCASA_CMD      "=obter"
#define     COLOCAR_PECA_CASA_CMD		"=colocarpeca"
#define     RETIRAR_PECA_CASA_CMD		"=retirarpeca"


/* os comandos a seguir somente operam em modo _DEBUG */

#define		VER_TAB_CMD					"=verificartabuleiro"
#define		DETURPAR_CMD				"=deturpar"


int estaInicializado = 0 ;

#define DIM_VT_TABULEIROS 5

TAB_tppTabuleiro vtpTab [DIM_VT_TABULEIROS] ;

/***** Prot�tipos das fun��es encapuladas no m�dulo *****/

   static int VerificarInx( int inxTabuleiro ) ;



/*****  C�digo das fun��es exportadas pelo m�dulo  *****/

/***********************************************************************
*
*  -> Fun��o: TTAB Efetuar opera��es de teste espec�ficas para tabuleiro
*
*  -> Descri��o da fun��o:
*     Efetua os diversos comandos de teste espec�ficos para o m�dulo
*     tabuleiro sendo testado.
*
*  -> Par�metros:
*     ComandoTeste - String contendo o comando
*
*  -> Valor retornado:
*     Ver TST_tpCondRet definido em TST_ESPC.H
*
***********************************************************************/


TST_tpCondRet TST_EfetuarComando( char * ComandoTeste )
{
	PEC_tppPeca  pPeca = NULL;

	PEC_tpCondRet PecCondRetObtido = PEC_CondRetOK;
	PEC_tpCondRet PecCondRetEsperada = PEC_CondRetFaltouMemoria;
	/* inicializa para qualquer coisa */
	TAB_tpCondRet TabCondRetObtido = TAB_CondRetOK;
	TAB_tpCondRet TabCondRetEsperada = TAB_CondRetFaltouMemoria;
	/* inicializa para qualquer coisa */

	int NumLinhas;
	int NumColunas;
	char ValorConteudoDado = '\0';
	char ValorConteudoEsperado = '?';
	char ValorConteudoObtido = '!';
	PEC_tpNomePeca ValorNomeDado = PEC_NomeSemNome;
	PEC_tpCorPeca ValorCorDado = PEC_CorSemCor;
	char ValorCodigoDado = '\0';

	int NumLidos = -1;
	int inxTabuleiro = -1;

	int i;

	TST_tpCondRet Ret;

#ifdef _DEBUG
	int  IntEsperado   = -1 ;
#endif

	
	/*Tratar: inicializar contexto */

	if ( strcmp( ComandoTeste, RESET_CMD) == 0 )
	{
		if (estaInicializado )
		{
			for ( i = 0; i < DIM_VT_TABULEIROS; i++ )
			{
				TAB_DestruirTabuleiro( & ( vtpTab[i] ));
			}/* for */
		}/* if */

		for ( i = 0; i < DIM_VT_TABULEIROS; i++ )
		{
			vtpTab[i] = NULL;
		}/* for */

		estaInicializado = 1;

		return TST_CondRetOK;

	}/* fim ativa: Tratar: inicializar contexto */
	
	
	
	/* Testar TABULEIRO Criar Tabuleiro */

	else if ( strcmp( ComandoTeste, CRIAR_TAB_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "iiii", &inxTabuleiro, &NumLinhas, &NumColunas, &TabCondRetEsperada );
		if ( NumLidos != 4 || !VerificarInx (inxTabuleiro) )
		{
			return TST_CondRetParm;
		} /* if */

		TabCondRetObtido = TAB_CriarTabuleiro(&(vtpTab[inxTabuleiro]) , NumLinhas, NumColunas);

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao criar tabuleiro." );

	} /* fim ativa : Testar TABULEIRO Criar Tabuleiro */


	/* Testar TABULEIRO Destruir Tabuleiro */

	else if ( strcmp( ComandoTeste, DESTROI_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ii", &inxTabuleiro, &TabCondRetEsperada );
		if ( NumLidos != 2 || !VerificarInx (inxTabuleiro) )
		{
			return TST_CondRetParm;
		} /* if */

		TabCondRetObtido = TAB_DestruirTabuleiro(&(vtpTab[inxTabuleiro]));

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao excluir tabuleiro." );

	} /* fim ativa : Testar TABULEIRO Destruir Tabuleiro */


	/* Testar TABULEIRO Exibir Tabuleiro */

	else if ( strcmp( ComandoTeste, EXIBIR_TAB_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ii", &inxTabuleiro, &TabCondRetEsperada );
		if ( NumLidos != 2 || !VerificarInx (inxTabuleiro) )
		{
			return TST_CondRetParm;
		} /* if */

		TabCondRetObtido = TAB_ExibirTabuleiro(&(vtpTab[inxTabuleiro]));

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao exibir tabuleiro." );

	} /* fim ativa : Testar TABULEIRO Exibir Tabuleiro */


	/* Testar TABULEIRO Obter Conteudo da Casa Tabuleiro */

	else if ( strcmp( ComandoTeste, OBTER_CONTEUDOCASA_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "iiici", &inxTabuleiro, &NumLinhas, &NumColunas, &ValorConteudoEsperado, &TabCondRetEsperada );
		if ( NumLidos != 5 || !VerificarInx (inxTabuleiro) )
		{
			return TST_CondRetParm;
		} /* if */

		TabCondRetObtido = TAB_ObterConteudoCasa(&(vtpTab[inxTabuleiro]), &pPeca, NumLinhas, NumColunas, &ValorConteudoObtido);

		Ret = TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao obter conteudo da casa no tabuleiro." );
		
		if ( Ret != TST_CondRetOK )
		{
			return Ret ;
		} /* if */

		return TST_CompararChar ( ValorConteudoEsperado , ValorConteudoObtido, "Conteudo da casa esta esta errado" );

	} /* fim ativa : Testar TABULEIRO Obter Conteudo da Casa Tabuleiro */


	/* Testar TABULEIRO Colocar uma Peca Numa Casa Tabuleiro */

	else if ( strcmp( ComandoTeste, COLOCAR_PECA_CASA_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "iiiiicii", &inxTabuleiro, &NumLinhas, &NumColunas, &ValorNomeDado, &ValorCorDado, &ValorCodigoDado, &PecCondRetEsperada, &TabCondRetEsperada );
		if ( NumLidos != 8 || !VerificarInx (inxTabuleiro) )
		{
			return TST_CondRetParm;
		} /* if */

		
		PecCondRetObtido = PEC_CriarPeca ( &pPeca, ValorNomeDado, ValorCorDado, ValorCodigoDado);

		Ret = TST_CompararInt ( PecCondRetEsperada , PecCondRetObtido, "Retorno errado ao criar peca." );

		if ( Ret != PEC_CondRetOK )
		{
			return Ret;
		}

		TabCondRetObtido = TAB_InserirPeca(&(vtpTab[inxTabuleiro]), &pPeca, NumLinhas, NumColunas);

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao colocar peca no tabuleiro." );

	} /* fim ativa : Testar TABULEIRO Colocar uma Peca Numa Casa Tabuleiro */


	/* Testar TABULEIRO Retirar uma Peca Numa Casa Tabuleiro */

	else if ( strcmp( ComandoTeste, RETIRAR_PECA_CASA_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "iiii", &inxTabuleiro, &NumLinhas, &NumColunas, &TabCondRetEsperada );
		if ( NumLidos != 4 || !VerificarInx (inxTabuleiro) )
		{
			return TST_CondRetParm;
		} /* if */

		TabCondRetObtido = TAB_RetirarPeca(&(vtpTab[inxTabuleiro]), NumLinhas, NumColunas);

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao retirar peca do tabuleiro." );

	} /* fim ativa : Testar TABULEIRO Retirar uma Peca Numa Casa Tabuleiro */


	/* Verificador do Tabuleiro */
#ifdef _DEBUG

	else if ( strcmp( ComandoTeste, VER_TAB_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ("ii", &inxTabuleiro, &TabCondRetEsperada );
		if ( NumLidos != 2 || !VerificarInx (inxTabuleiro) )
		{
			return TST_CondRetParm;
		}/* if */

		TabCondRetObtido = TAB_VerificarTabuleiro (&(vtpTab[inxTabuleiro]));

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao verificar o tabuleiro." );

	}/* fim ativa:  Testar verificador do tabuleiro */
#endif


	/* Deturpar um tabuleiro */
#ifdef _DEBUG

	else if ( strcmp( ComandoTeste, DETURPAR_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "iii", &inxTabuleiro, &IntEsperado, &TabCondRetEsperada );
		if ( (NumLidos != 3 ) || !VerificarInx (inxTabuleiro) )
		{
			return TST_CondRetParm;
		}/* if */

		TabCondRetObtido = TAB_Deturpar ( &(vtpTab[inxTabuleiro]), (TAB_tpModosDeturpacao) IntEsperado );

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao deturpar o tabuleiro." );
	}/* fim ativa: Deturpar Tabuleiro */
#endif
}


/***********************************************************************
*
*  $FC Fun��o: TTAB - Verificar �ndice de tabuleiro
*
*  $FV Valor retornado
*     0 - inxArvore n�o vale
*     1 - inxArvore vale
*
***********************************************************************/

   int VerificarInx( int inxTabuleiro )
   {

      if ( ( inxTabuleiro <   0 )
        || ( inxTabuleiro >= DIM_VT_TABULEIROS ))
      {
         return 0 ;
      } /* if */

      return 1 ;

   } /* Fim fun��o: TTAB -Verificar �ndice de tabuleiro */


/********** Fim do m�dulo de implementa��o: TTAB M�dulo de teste espec�fico para tabuleiro **********/

