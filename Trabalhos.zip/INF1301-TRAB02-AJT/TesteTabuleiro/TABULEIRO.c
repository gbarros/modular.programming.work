/**********************************************************************************************************
*
*  -> M�dulo de implementa��o: TAB M�dulo de tabuleiro gen�rico
*
*  Arquivo gerado: TABULEIRO.c
*  Letras identificadoras: TAB
*
*  Autores: tr - Tadeu Ribeiro
*			ag - Alexandre Garcia
*			jc - Jocimar Candido
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      tr, al, jc   26/set/2012    in�cio do desenvolvimento
*      1.1      tr, al, jc   03/out/2012    revis�o do m�dulo inteiro e implementa��o de manipuladores de c�digo
*      1.2      tr, al, jc   07/out/2012    adi��o de novas fun��es e revis�o do m�dulo inteiro
* 
**********************************************************************************************************/

#include   <stdlib.h>
#include   <stdio.h>
#include   <string.h>
#include   <memory.h>
#include   <malloc.h>
#include   <assert.h>

#include   "TABULEIRO.h"


/***********************************************************************
*
*  Tipo de dados: TAB Estrutura de uma casa
*
***********************************************************************/

typedef struct TAB_tagCasa{

	PEC_tppPeca Peca;
		/* pe�a que ir� ocupar a casa */
	char Casa;
		/* conte�do da casa */

}TAB_tpCasa;

/***********************************************************************
*
*  Tipo de dados: TAB Estrutura de um tabuleiro
*
***********************************************************************/

typedef struct TAB_tagTabuleiro{

	int NumLinhas;
		/* n�mero de linhas do tabuleiro */

	int NumColunas;
		/* n�mero de colunas do tabuleiro */

	TAB_tpCasa * Tab;
		/* matriz de casas representada por um vetor a ser inicializada. Para acessar o elemento ij da matriz deve-se fazer: v[i*NumLinhas + j] */

}TAB_tpTabuleiro;



/*****  C�digo das fun��es exportadas pelo m�dulo  *****/

/***********************************************************************
*
*  Fun��o: TAB Criar Tabuleiro
*
***********************************************************************/

TAB_tpCondRet TAB_CriarTabuleiro (TAB_tppTabuleiro * pTab, int NumLinhas, int NumColunas)
{
	int i, j; //indices para percorrer a matriz
	
	/* Verifica a exist�ncia de um tabuleiro j� criado */
	if ( (*pTab) != NULL)
	{
		return TAB_CondRetErroEstrutura;
	} /* if */

	/* Aloca espa�o na mem�ria para o tabuleiro */
	(*pTab) = ( TAB_tppTabuleiro ) malloc ( sizeof( TAB_tpTabuleiro ) ) ;

	/* Verifica espa�o na mem�ria */
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetFaltouMemoria ;
	} /* If */

	/* Faz as atribui��es */
	(*pTab)->NumLinhas = NumLinhas;
	(*pTab)->NumColunas = NumColunas;
	(*pTab)->Tab = ( TAB_tppCasa) malloc ( NumLinhas * NumColunas * sizeof( TAB_tpCasa ) ) ;

	/* incializa as casas */

	for ( i=0; i<NumLinhas; i++)
	{
		for ( j=0; j<NumColunas; j++)
		{
			(*pTab)->Tab[i*NumLinhas+j].Peca=NULL;
			if ((i%2 == 0) && (j%2 == 0))
			{
				(*pTab)->Tab[i*NumLinhas+j].Casa='0';
			}
			else if ((i%2 == 1) && (j%2 == 1))
			{
				(*pTab)->Tab[i*NumLinhas+j].Casa='0';
			}
			else
			{
				(*pTab)->Tab[i*NumLinhas+j].Casa='1';
			}

		}
	}

	return TAB_CondRetOK ;

} /* Fim fun��o: TAB Criar Tabuleiro */



/***********************************************************************
*
*  Fun��o: TAB Destruir Tabuleiro
*
***********************************************************************/

TAB_tpCondRet TAB_DestruirTabuleiro (TAB_tppTabuleiro * pTab)
{
    int i, j; //indices para percorrer a matriz
	PEC_tpCondRet pecRet;
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	}/* if */
	for ( i=0; i<(*pTab)->NumLinhas; i++)
	{
		for ( j=0; j<(*pTab)->NumColunas; j++)
		{
			if ( (*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca != NULL )
			{
				pecRet = PEC_ExcluirPeca(&(*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca);
			}
		}
	}
	free( (*pTab)->Tab );
	free( (*pTab) );
	
	(*pTab) = NULL;
	
	return TAB_CondRetOK ;

} /* Fim fun��o: TAB Destruir Tabuleiro */



/***********************************************************************
*
*  Fun��o: TAB Exibir Tabuleiro
*
***********************************************************************/

TAB_tpCondRet TAB_ExibirTabuleiro (TAB_tppTabuleiro * pTab)
{
	int i, j; //indices para percorrer a matriz
	PEC_tpCondRet pecRet;
	char peca;

	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Desenha o tabuleiro na tela */
	printf("\n   ");
	for (j=0; j<(*pTab)->NumColunas; j++)
	{
		printf("%d ", j);
	}
	printf("\n   ");
	for (j=0; j<(*pTab)->NumColunas; j++)
	{
		printf("_ ");
	}

	for ( i=0; i<(*pTab)->NumLinhas; i++)
	{
		printf("\n%d| ", i);
		for ( j=0; j<(*pTab)->NumColunas; j++)
		{
			if ( (*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca != NULL )
			{
				pecRet = PEC_ObterCodigoPeca(&(*pTab)->Tab[i*(*pTab)->NumLinhas+j].Peca, &peca);
				printf("%c ", peca);
			}
			else
			{
				printf("%c ",(*pTab)->Tab[i*(*pTab)->NumLinhas+j].Casa);
			}
		}
	}

	return TAB_CondRetOK ;

} /* Fim fun��o: TAB Exibir Tabuleiro */



/***********************************************************************
*
*  Fun��o: TAB Obter Conteudo Casa
*
***********************************************************************/

TAB_tpCondRet TAB_ObterConteudoCasa ( TAB_tppTabuleiro * pTab, PEC_tppPeca * pPeca, int CoordLinha, int CoordColuna, char * ConteudoCasa )
{
	PEC_tpCondRet pecRet;
	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Verifica se a coordenada existe */
	if ((CoordLinha>=(*pTab)->NumLinhas)||(CoordColuna>=(*pTab)->NumColunas))
	{
		return TAB_CondRetErroEstrutura;
	}

	/* Verifica se a pe�a existe */	
	if ( (*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca == NULL )
	{
		(*ConteudoCasa) = (*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Casa;
	}
	else
	{
		(*pPeca)=(*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca;
		pecRet = PEC_ObterCodigoPeca(&(*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca, ConteudoCasa);
		if(pecRet != PEC_CondRetOK)
		{
			return TAB_CondRetErroPeca;
		}
	}
	
	return TAB_CondRetOK ;
	
} /* Fim fun��o: TAB Obter Conteudo Casa */


/***********************************************************************
*
*  Fun��o: TAB Inserir Peca
*
***********************************************************************/

TAB_tpCondRet TAB_InserirPeca (TAB_tppTabuleiro * pTab, PEC_tppPeca * pPeca, int CoordLinha, int CoordColuna)
{
	PEC_tpCondRet pecRet;

	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Verifica se a peca existe */
	if ( (*pPeca) == NULL )
	{
		return TAB_CondRetPecaInexistente;
	} /* if */

	/* Verifica se a coordenada existe */
	if ((CoordLinha>=(*pTab)->NumLinhas)||(CoordColuna>=(*pTab)->NumColunas))
	{
		return TAB_CondRetErroEstrutura;
	}

	(*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca = (*pPeca);
	
	return TAB_CondRetOK ;
	
} /* Fim fun��o: TAB Inserir Peca */


/***********************************************************************
*
*  Fun��o: TAB Retirar Peca
*
***********************************************************************/

TAB_tpCondRet TAB_RetirarPeca (TAB_tppTabuleiro * pTab, int CoordLinha, int CoordColuna)
{
	PEC_tpCondRet pecRet;

	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Verifica se a coordenada existe */
	if ((CoordLinha>=(*pTab)->NumLinhas)||(CoordColuna>=(*pTab)->NumColunas))
	{
		return TAB_CondRetErroEstrutura;
	}

	/* Verifica se a pe�a existe */	
	if ( (*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca == NULL )
	{
		return TAB_CondRetPecaInexistente;
	} /* if */

	pecRet = PEC_ExcluirPeca(&((*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca));
	(*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Peca = NULL;
	
	if(pecRet != PEC_CondRetOK)
	{
		return TAB_CondRetErroPeca;
	}

	return TAB_CondRetOK ;
	
} /* Fim fun��o: TAB Retirar Peca */



/********** Fim do m�dulo de implementa��o: TAB Tabuleiro gen�rico **********/

