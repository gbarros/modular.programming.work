#if ! defined( PEC_CondRet_ )
#define PEC_CondRet_
/**********************************************************************************************************
*
*  -> M�dulo de defini��o: RPEC Condi��es de retorno do m�dulo pe�a
*
*  Arquivo gerado: PEC_CondRet.h
*  Letras identificadoras: RPEC
*
*  Autores: tr - Tadeu Ribeiro
*			ag - Alexandre Garcia
*			jc - Jocimar Candido
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      tr, al, jc   05/out/2012    in�cio do desenvolvimento
*
*  -> Descri��o do m�dulo:
*     Este m�dulo define as condi��es de retorno das fun��es do m�dulo pe�a.
*    
**********************************************************************************************************/

#if defined( PEC_CondRet_OWN )
   #define PEC_CondRet_EXT
#else
   #define PEC_CondRet_EXT extern
#endif


/***********************************************************************
*
*  Tipo de dados: RPEC Condi��es de retorno
*
*  Descri��o do tipo:
*     Condi��es de retorno das fun��es do m�dulo pe�a
*
*  Fun��es por N�mero:
*        -> PECA1.h
*        CriarPeca 		   = 1 
*        ExcluirPeca   	   = 2 
*        ObterNomePeca     = 3 
*        MudarNomePeca	   = 4 
*        ObterCorPeca      = 5 
*        MudarCorPeca	   = 6 
*        ObterCodigoPeca   = 7 
*        MudarCodigoPeca   = 8 
*        -> PECA2.h
*        ObterCodigoPeca   = 9
*        ExcluirPeca   	   = 10
*
***********************************************************************/

typedef enum {

	PEC_CondRetOK = 0 ,
	/* Concluiu corretamente */
	/* Fun��es que utilizam : 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 */

	PEC_CondRetFaltouMemoria = 1 ,
	/* Faltou mem�ria ao tentar criar uma pe�a */
	/* Fun��es que utilizam : 1 */

	PEC_CondRetErroEstrutura = 2 ,
	/* Pe�a j� existe */
	/* Fun��es que utilizam : 1 */

	PEC_CondRetPecaInexistente = 3 ,
	/* Pe�a inv�lida ou inexistente (N�o foi criada) */
	/* Fun��es que utilizam : 2, 3, 4, 5, 6, 7, 8, 9, 10 */

	PEC_CondRetNomeInexistente = 4 ,
	/* Nome inv�lido ou inexistente (Nome n�o foi criado) */
	/* Fun��es que utilizam : 1, 3, 4 */

	PEC_CondRetCorInexistente = 5 ,
	/* Cor inv�lida ou inexistente (Cor n�o foi criada) */
	/* Fun��es que utilizam : 1, 5, 6 */

	PEC_CondRetCodigoInexistente = 6
	/* C�digo inv�lido ou inexistente (Codigo n�o foi criado) */
	/* Fun��es que utilizam : 7, 9 */

} PEC_tpCondRet ;



#undef PECA_CondRet_EXT

/********** Fim do m�dulo de defini��o: RPEC Condi��es de retorno do m�dulo pe�a **********/

#else
#endif