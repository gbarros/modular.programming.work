#if ! defined( PECA1_ )
#define PECA1_
/**********************************************************************************************************
*
*  -> M�dulo de defini��o: PE1 M�dulo de pe�as gen�ricas
*
*  Arquivo gerado: PECA1.h
*  Letras identificadoras: PE1
*
*  Autores: tr - Tadeu Ribeiro
*			ag - Alexandre Garcia
*			jc - Jocimar Candido
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      tr, al, jc   18/set/2012    in�cio do desenvolvimento
*      1.1      tr, al, jc   05/out/2012    modifica��o das explica��es, assertivas, enum e dos prot�tipos das fun��es
*
*  -> Descri��o do m�dulo:
*     Este m�dulo implementa um conjunto de fun��es que manipulam pe�as gen�ricas para que possam ser
*     utilizadas futuramente em qualquer tipo de jogo de tabuleiro.
*     As pe�as possuem um nome, uma cor e um c�digo para identific�-las.
*    
*     Os nomes ser�o representados pelos n�meros abaixo:
*     Sem Nome = 0
*     Peao = 1
*     Dama = 2
*     OBS: O uso futuro poder� necessitar de pequenas e simples altera��es no tipo enumerado que gerencia os
*     nomes das pe�as, conforme o jogo em quest�o. Por exemplo um jogo de xadrez deve acrescentar
*     alguns nomes de pe�as como Bispo, Cavalo e outros. E retirar o nome Dama.
*
*     As cores ser�o representadas pelos n�meros abaixo:
*     Sem Cor = 0
*     Cor Preta = 1
*     Cor Branca = 2
*     Cor Azul = 3
*     Cor Vermelha = 4
*     Cor Verde = 5
*     Cor Amarela = 6
*     OBS: O uso futuro poder� necessitar de pequenas e simples altera��es no tipo enumerado que gerencia as
*     cores das pe�as, conforme o jogo em quest�o. Por exemplo um outro jogo pode necessitar da cor Roxa,
*     ent�o dever� acrescentar a Cor Roxa = 7.
*
*     O c�digo de uma pe�a ser� um char que possui um �nico caractere. Este c�digo � definido pelo usu�rio do m�dulo.
*	
**********************************************************************************************************/

#if defined( PECA1_OWN )
#define PECA1_EXT
#else
#define PECA1_EXT extern
#endif


//inclui as condi��es de retorno das fun��es do modulo PECA
#include "PEC_CondRet.h" 


/***** Declara��es exportadas pelo m�dulo *****/

/* Tipo refer�ncia para uma pe�a */

typedef struct PEC_tagPeca * PEC_tppPeca ;

/***********************************************************************
*
*  Tipo de dados: PE1 Cores de pe�as
*
***********************************************************************/

typedef enum {

	PEC_CorSemCor = 0 ,
	/* Pe�a propositalmente sem cor */

	PEC_CorPreta = 1 ,
	/* Pe�a de cor preta */

	PEC_CorBranca = 2,
	/* Pe�a de cor branca */

	PEC_CorAzul = 3,
	/* Pe�a de cor azul */

	PEC_CorVermelha = 4 ,
	/* Pe�a de cor vermelha */
		
	PEC_CorVerde = 5 ,
	/* Pe�a de cor verde */
	
	PEC_CorAmarela = 6
	/* Pe�a de cor amarela */

} PEC_tpCorPeca ;

/***********************************************************************
*
*  Tipo de dados: PE1 Nomes de pe�as
*
***********************************************************************/

typedef enum {

	PEC_NomeSemNome = 0 ,
	/* Pe�a ser� definida sem nome. */

	PEC_NomePeao = 1 ,
	/* Pe�a do tipo pe�o */

	PEC_NomeDama = 2
	/* Pe�a do tipo dama */

} PEC_tpNomePeca ;

/***********************************************************************
*
*  -> Fun��o: PE1 Criar Peca
*
*  -> Descri��o da fun��o:
*     Cria uma pe�a com os atributos nome, cor e c�digo. 
*
*  -> Par�metros:
*     pPeca       - Ponteiro para uma pe�a.
*	  nome		  - Nome da pe�a.
*	  cor		  - Cor da pe�a.
*	  codigo	  - C�digo da pe�a.
*
*  -> Valor retornado:
*     PEC_CondRetOK
*	  PEC_CondRetFaltouMemoria
*	  PEC_CondRetErroEstrutura
*     PEC_CondRetNomeInexistente
*     PEC_CondRetCorInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe o ponteiro, por refer�ncia, para um tipo pe�a a ser criada juntamente 
*     com os tipos nome, cor e um char codigo que ser�o os atributos que
*     preencher�o essa estrutura pe�a. 
*
*     Sa�da - Se executou corretamente retorna, por refer�ncia, um ponteiro pe�a
*     com os atributos passados como par�metros associados.
*     Se a cor ou o nome passados nao est�o especificados, a fun��o retornar� 
*     o erro respectivo.
*     N�o ser�o dadas mais informa��es quanto ao problema ocorrido.   
*
***********************************************************************/

PEC_tpCondRet PEC_CriarPeca ( PEC_tppPeca * pPeca, PEC_tpNomePeca nome , PEC_tpCorPeca cor , char codigo ) ;

/***********************************************************************
*
*  -> Fun��o: PE1 Excluir Peca
*
*  -> Descri��o da fun��o:
*     Exclui uma pe�a liberando toda mem�ria utilizada por aquela 
*     estrutura.
*
*  -> Par�metros:
*	  pPeca		  - Ponteiro para uma pe�a.
*
*  -> Valor retornado:
*     PEC_CondRetOK
*	  PEC_CondRetPecaInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe o ponteiro, por refer�ncia, para uma estrutura pe�a que utilizou e alocou
*     mem�ria e que se deseja excluir.
*
*     Sa�da - Retorna o ponteiro da pe�a por refer�ncia, desalocada, com toda mem�ria utilizada pela 
*     estrutura dessa pe�a sendo liberada.
*     Caso a pe�a n�o exista retorna a condi��o de retorno correspondente.
*
***********************************************************************/

PEC_tpCondRet PEC_ExcluirPeca (PEC_tppPeca * pPeca) ;

/***********************************************************************
*
*  -> Fun��o: PE1 Obter Nome Peca
*
*  -> Descri��o da fun��o:
*     Obt�m o nome de uma pe�a.
*
*  -> Par�metros:
*	  pPeca		  - Ponteiro para uma pe�a.
*	  nome		  - Ponteiro para o tipo nome da pe�a.
*
*  -> Valor retornado:
*     PEC_CondRetOK
*     PEC_CondRetNomeInexistente
*     PEC_CondRetPecaInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe um ponteiro, por refer�ncia, para uma pe�a que se deseja saber o nome
*     e um ponteiro para o tipo nome de pe�a, onde ser� retornado o nome que
*     se deseja obter.
*
*     Sa�da - Retorna por refer�ncia o nome da pe�a se ele existir. 
*     Caso o nome n�o exista retorna a condi��o de retorno correspondente.
*
***********************************************************************/

PEC_tpCondRet PEC_ObterNomePeca (PEC_tppPeca * pPeca, PEC_tpNomePeca * nome) ;

/***********************************************************************
*
*  -> Fun��o: PE1 Mudar Nome Peca
*
*  -> Descri��o da fun��o:
*     Muda o nome da pe�a.
*
*  -> Par�metros:
*	  pPeca		  - Ponteiro para uma pe�a.
*	  nome		  - Novo nome da pe�a.
*
*  -> Valor retornado:
*     PEC_CondRetOK
*     PEC_CondRetNomeInexistente
*     PEC_CondRetPecaInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe um ponteiro, por refer�ncia, para uma pe�a que se deseja mudar o nome
*     e o tipo nome de pe�a que ser� o novo nome dessa pe�a.
*
*     Sa�da - Retorna o ponteiro da pe�a, por refer�ncia, com o novo nome passado como 
*     par�metro. Se o nome passado for inv�lido, retorna que o nome passado
*     � inexistente.
*
***********************************************************************/

PEC_tpCondRet PEC_MudarNomePeca (PEC_tppPeca * pPeca, PEC_tpNomePeca nome) ;

/***********************************************************************
*
*  -> Fun��o: PE1 Obter Cor Peca
*
*  -> Descri��o da fun��o:
*     Obt�m a cor da pe�a.
*
*  -> Par�metros:
*	  pPeca		  - Ponteiro para uma pe�a.
*	  cor		  - Ponteiro para o tipo cor da pe�a.
*
*  -> Valor retornado:
*     PEC_CondRetOK
*     PEC_CondRetCorInexistente
*     PEC_CondRetPecaInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe um ponteiro, por refer�ncia, para uma pe�a que se deseja saber a cor
*     e um ponteiro para o tipo cor de pe�a, onde ser� retornado a cor que
*     se deseja obter.
*
*     Sa�da - Retorna por refer�ncia a cor da pe�a se ela existir. 
*     Caso a cor n�o exista retorna a condi��o de retorno correspondente.
*
***********************************************************************/

PEC_tpCondRet PEC_ObterCorPeca (PEC_tppPeca * pPeca, PEC_tpCorPeca * cor) ;

/***********************************************************************
*
*  -> Fun��o: PE1 Mudar Cor Peca
*
*  -> Descri��o da fun��o:
*     Muda a cor da pe�a.
*
*  -> Par�metros:
*	  pPeca		  - Ponteiro para uma pe�a.
*	  cor		  - Nova cor da pe�a.
*
*  -> Valor retornado:
*     PEC_CondRetOK
*     PEC_CondRetCorInexistente
*     PEC_CondRetPecaInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe um ponteiro, por refer�ncia, para uma pe�a que se deseja mudar a cor
*     e o tipo cor de pe�a que ser� a nova cor dessa pe�a.
*
*     Sa�da - Retorna por refer�ncia um ponteiro para a pe�a com a nova cor passada como 
*     par�metro. Se a cor passada for inv�lida, retorna que a cor passada
*     � inexistente.
*
***********************************************************************/

PEC_tpCondRet PEC_MudarCorPeca (PEC_tppPeca * pPeca, PEC_tpCorPeca cor) ;

/***********************************************************************
*
*  -> Fun��o: PE1 Obter Codigo Peca
*
*  -> Descri��o da fun��o:
*     Obt�m o c�digo da pe�a.
*
*  -> Par�metros:
*	  pPeca		  - Ponteiro para a pe�a.
*	  codigo	  - Ponteiro para o tipo char do codigo da pe�a.
*
*  -> Valor retornado:
*     PEC_CondRetOK
*     PEC_CondRetCodigoInexistente
*     PEC_CondRetPecaInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe um ponteiro, por refer�ncia, para uma pe�a que se deseja saber o c�digo
*     e um ponteiro para o tipo char do c�digo de pe�a, onde ser� retornado o c�digo
*     que se deseja obter.
*
*     Sa�da - Retorna por refer�ncia o c�digo da pe�a se ele existir. 
*     Caso o c�digo n�o exista retorna a condi��o de retorno correspondente.
*
***********************************************************************/

PEC_tpCondRet PEC_ObterCodigoPeca (PEC_tppPeca * pPeca, char * codigo) ;

/***********************************************************************
*
*  -> Fun��o: PE1 Mudar Codigo Peca
*
*  -> Descri��o da fun��o:
*     Muda o c�digo da pe�a.
*
*  -> Par�metros:
*	  pPeca		  - Ponteiro para uma pe�a.
*	  codigo	  - Novo codigo da pe�a.
*
*  -> Valor retornado:
*     PEC_CondRetOK
*     PEC_CondRetPecaInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe por refer�ncia um ponteiro para uma pe�a que se deseja mudar o c�digo
*     e o char codigo da pe�a que ser� o novo c�digo dessa pe�a.
*
*     Sa�da - Retorna por refer�ncia um ponteiro para a pe�a com o novo c�digo passado como 
*     par�metro.
*
***********************************************************************/

PEC_tpCondRet PEC_MudarCodigoPeca (PEC_tppPeca * pPeca, char  codigo) ;



#undef PECA1_EXT

/********** Fim do m�dulo de defini��o: PE1 M�dulo de pe�as gen�ricas **********/

#else
#endif
