#if ! defined( PECA2_ )
#define PECA2_
/**********************************************************************************************************
*
*  -> M�dulo de defini��o: PE2 M�dulo de pe�as gen�ricas
*
*  Arquivo gerado: PECA2.h
*  Letras identificadoras: PE2
*
*  Autores: tr - Tadeu Ribeiro
*			ag - Alexandre Garcia
*			jc - Jocimar Candido
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      tr, al, jc   18/set/2012    in�cio do desenvolvimento
*      1.1      tr, al, jc   05/out/2012    modifica��o das explica��es, assertivas, enum e dos prot�tipos das fun��es
*
*  -> Descri��o do m�dulo:
*     Este m�dulo implementa um conjunto de fun��es que manipulam pe�as gen�ricas para que possam ser
*     utilizadas futuramente em qualquer tipo de jogo de tabuleiro.
*     As pe�as possuem um nome, uma cor e um c�digo para identific�-las.
*    
*     Os nomes ser�o representados pelos n�meros abaixo:
*     Sem Nome = 0
*     Peao = 1
*     Dama = 2
*     OBS: O uso futuro poder� necessitar de pequenas e simples altera��es no tipo enumerado que gerencia os
*     nomes das pe�as, conforme o jogo em quest�o. Por exemplo um jogo de xadrez deve acrescentar
*     alguns nomes de pe�as como Bispo, Cavalo e outros. E retirar o nome Dama.
*
*     As cores ser�o representadas pelos n�meros abaixo:
*     Sem Cor = 0
*     Cor Preta = 1
*     Cor Branca = 2
*     Cor Azul = 3
*     Cor Vermelha = 4
*     Cor Verde = 5
*     Cor Amarela = 6
*     OBS: O uso futuro poder� necessitar de pequenas e simples altera��es no tipo enumerado que gerencia as
*     cores das pe�as, conforme o jogo em quest�o. Por exemplo um outro jogo pode necessitar da cor Roxa,
*     ent�o dever� acrescentar a Cor Roxa = 7.
*
*     O c�digo de uma pe�a ser� um char que possui um �nico caractere. Este c�digo � definido pelo usu�rio do m�dulo.
*		    
**********************************************************************************************************/

#if defined( PECA2_OWN )
   #define PECA2_EXT
#else
   #define PECA2_EXT extern
#endif


//inclui as condi��es de retorno das fun��es do m�dulo PECA
#include "PEC_CondRet.h" 


/***** Declara��es exportadas pelo m�dulo *****/

/* Tipo refer�ncia para uma pe�a */

typedef struct PEC_tagPeca * PEC_tppPeca ;

/***********************************************************************
*
*  -> Fun��o: PE1 Obter Codigo Peca
*
*  -> Descri��o da fun��o:
*     Obt�m o c�digo da pe�a.
*
*  -> Par�metros:
*	  pPeca		  - Ponteiro para a pe�a.
*	  codigo	  - Ponteiro para o tipo char do codigo da pe�a.
*
*  -> Valor retornado:
*     PEC_CondRetOK
*     PEC_CondRetCodigoInexistente
*     PEC_CondRetPecaInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe um ponteiro, por refer�ncia, para uma pe�a que se deseja saber o c�digo
*     e um ponteiro para o tipo char do c�digo de pe�a, onde ser� retornado o c�digo
*     que se deseja obter.
*
*     Sa�da - Retorna por refer�ncia o c�digo da pe�a se ele existir. 
*     Caso o c�digo n�o exista retorna a condi��o de retorno correspondente.
*
***********************************************************************/

PEC_tpCondRet PEC_ObterCodigoPeca (PEC_tppPeca * pPeca, char * codigo) ;

/***********************************************************************
*
*  -> Fun��o: PE1 Excluir Peca
*
*  -> Descri��o da fun��o:
*     Exclui uma pe�a liberando toda mem�ria utilizada por aquela 
*     estrutura.
*
*  -> Par�metros:
*	  pPeca		  - Ponteiro para uma pe�a.
*
*  -> Valor retornado:
*     PEC_CondRetOK
*	  PEC_CondRetPecaInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe o ponteiro, por refer�ncia, para uma estrutura pe�a que utilizou e alocou
*     mem�ria e que se deseja excluir.
*
*     Sa�da - Retorna o ponteiro da pe�a por refer�ncia, desalocada, com toda mem�ria utilizada pela 
*     estrutura dessa pe�a sendo liberada.
*     Caso a pe�a n�o exista retorna a condi��o de retorno correspondente.
*
***********************************************************************/

PEC_tpCondRet PEC_ExcluirPeca (PEC_tppPeca * pPeca) ;



#undef PECA2_EXT

/********** Fim do m�dulo de defini��o: PE2 M�dulo de pe�as gen�ricas **********/

#else
#endif
