/***************************************************************************
*  -> M�dulo de implementa��o: TPEC M�dulo de teste espec�fico para Pe�a
*
*  Arquivo gerado: TEST_PEC.C
*  Letras identificadoras: TPEC
*
*  Autores: tr - Tadeu Ribeiro
*			ag - Alexandre Garcia
*			jc - Jocimar Candido
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      tr, al, jc   02/out/2012    in�cio do desenvolvimento
*
*  -> Descri��o do m�dulo:
*     Este m�dulo cont�m as fun��es espec�ficas para o teste do
*     m�dulo pe�a.
*
*  -> Interface com o usu�rio pessoa:
*     Comandos de teste espec�ficos para testar o m�dulo pe�a:
*
*		"=criar"		   - chama a fun��o PEC_CriarPeca( )
*		"=exclui"          - chama a fun��o PEC_ExcluirPeca( )
*		"=obternome"       - chama a fun��o PEC_ObterNomePeca( )
*		"=mudarnome"       - chama a fun��o PEC_MudarNomePeca( )
*		"=obtercor"        - chama a fun��o PEC_ObterCorPeca( )
*		"=mudarcor"        - chama a fun��o PEC_MudarCorPeca( )
*		"=obtercodigo"     - chama a fun��o PEC_ObterCodigoPeca( )
*		"=mudarcodigo"     - chama a fun��o PEC_MudarCodigoPeca( )
*
***************************************************************************/

#include    <string.h>
#include    <stdio.h>

#include    "TST_ESPC.H"

#include    "generico.h"
#include    "lerparm.h"

#include    "PECA1.h"
#include    "PECA2.h"

/* Tabela dos nomes dos comandos de teste espec�ficos */

#define     CRIAR_PEC_CMD               "=criar"
#define     EXCLUI_CMD                  "=excluir"
#define     OBTER_NOME_CMD              "=obternome"
#define     OBTER_COR_CMD               "=obtercor"
#define     OBTER_CODIGO_CMD            "=obtercodigo"
#define     MUDAR_NOME_CMD              "=mudarnome"
#define     MUDAR_COR_CMD               "=mudarcor"
#define     MUDAR_CODIGO_CMD            "=mudarcodigo"


/*****  C�digo das fun��es exportadas pelo m�dulo  *****/


/***********************************************************************
*
*  -> Fun��o: TPEC Efetuar opera��es de teste espec�ficas para peca
*
*  -> Descri��o da fun��o:
*     Efetua os diversos comandos de teste espec�ficos para o m�dulo
*     pe�a sendo testado.
*
*  -> Par�metros:
*     ComandoTeste - String contendo o comando
*
*  -> Valor retornado:
*     Ver TST_tpCondRet definido em TST_ESPC.H
*
***********************************************************************/

PEC_tppPeca  pPeca = NULL;

TST_tpCondRet TST_EfetuarComando( char * ComandoTeste )
{
	PEC_tpCondRet CondRetObtido = PEC_CondRetOK;
	PEC_tpCondRet CondRetEsperada = PEC_CondRetFaltouMemoria;
									/* inicializa para qualquer coisa */

	PEC_tpNomePeca ValorNomeDado = PEC_NomeSemNome;
	PEC_tpCorPeca ValorCorDado = PEC_CorSemCor;
	char ValorCodigoDado = '\0';
	PEC_tpNomePeca ValorNomeEsperado = PEC_NomeSemNome;
	PEC_tpCorPeca ValorCorEsperado = PEC_CorSemCor;
	char ValorCodigoEsperado = '?';
	PEC_tpNomePeca ValorNomeObtido = PEC_NomeSemNome;
	PEC_tpCorPeca ValorCorObtido = PEC_CorSemCor;
	char ValorCodigoObtido = '!';

	int NumLidos = -1;

	TST_tpCondRet Ret;

	/* Testar PECA Criar Peca */

	if ( strcmp( ComandoTeste, CRIAR_PEC_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "iici", &ValorNomeDado, &ValorCorDado, &ValorCodigoDado, &CondRetEsperada );
		if ( NumLidos != 4 )
		{
			return TST_CondRetParm;
		} /* if */

		CondRetObtido = PEC_CriarPeca(&pPeca , ValorNomeDado, ValorCorDado, ValorCodigoDado);

		return TST_CompararInt ( CondRetEsperada , CondRetObtido, "Retorno errado ao criar peca." );
	} /* fim ativa : Testar PECA Criar Peca */

	/* Testar PECA Excluir Peca */
	else if ( strcmp( ComandoTeste, EXCLUI_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "i", &CondRetEsperada );
		if ( NumLidos != 1 )
		{
			return TST_CondRetParm;
		} /* if */

		CondRetObtido = PEC_ExcluirPeca ( &pPeca );

		return TST_CompararInt( CondRetEsperada, CondRetObtido, "Retorno errado ao excluir peca." );
	} /* fim ativa : Testar PECA Excluir Peca */

	/* Testar PECA Obter Nome da Peca */
	else if ( strcmp( ComandoTeste, OBTER_NOME_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ii", &ValorNomeEsperado, &CondRetEsperada );
		if ( NumLidos != 2 )
		{
			return TST_CondRetParm;
		} /* if */

		CondRetObtido = PEC_ObterNomePeca ( &pPeca, &ValorNomeObtido );

		Ret = TST_CompararInt( CondRetEsperada, CondRetObtido, "Retorno errado ao obter nome da peca." );
 
		if ( Ret != TST_CondRetOK )
            {
               return Ret ;
            } /* if */

		return TST_CompararInt( ValorNomeEsperado, ValorNomeObtido, "Nome obtido esta errado.");
	} /* fim ativa : Testar PECA Obter Nome da Peca */

	/* Testar PECA Mudar Nome da Peca */
	else if ( strcmp( ComandoTeste, MUDAR_NOME_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ii", &ValorNomeDado, &CondRetEsperada );
		if ( NumLidos != 2 )
		{
			return TST_CondRetParm;
		} /* if */

		CondRetObtido = PEC_MudarNomePeca ( &pPeca, ValorNomeDado );

		return TST_CompararInt( CondRetEsperada, CondRetObtido, "Retorno errado ao mudar o nome da peca." );
	} /* fim ativa : Testar PECA Mudar Nome da Peca */

	/* Testar PECA Obter Cor da Peca */
	else if ( strcmp( ComandoTeste, OBTER_COR_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ii", &ValorCorEsperado, &CondRetEsperada );
		if ( NumLidos != 2 )
		{
			return TST_CondRetParm;
		} /* if */

		CondRetObtido = PEC_ObterCorPeca ( &pPeca, &ValorCorObtido );

		Ret = TST_CompararInt( CondRetEsperada, CondRetObtido, "Retorno errado ao obter cor da peca." );
 
		if ( Ret != TST_CondRetOK )
            {
               return Ret ;
            } /* if */

		return TST_CompararInt( ValorCorEsperado, ValorCorObtido, "Cor obtida esta errada.");
	} /* fim ativa : Testar PECA Obter Cor da Peca */

	/* Testar PECA Mudar Cor da Peca */
	else if ( strcmp( ComandoTeste, MUDAR_COR_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ii", &ValorCorDado, &CondRetEsperada );
		if ( NumLidos != 2 )
		{
			return TST_CondRetParm;
		} /* if */

		CondRetObtido = PEC_MudarCorPeca ( &pPeca, ValorCorDado );

		return TST_CompararInt( CondRetEsperada, CondRetObtido, "Retorno errado ao mudar a cor da peca." );
	} /* fim ativa : Testar PECA Mudar Cor da Peca */

	/* Testar PECA Obter Codigo da Peca */
	else if ( strcmp( ComandoTeste, OBTER_CODIGO_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ci", &ValorCodigoEsperado, &CondRetEsperada );
		if ( NumLidos != 2 )
		{
			return TST_CondRetParm;
		} /* if */

		CondRetObtido = PEC_ObterCodigoPeca ( &pPeca, &ValorCodigoObtido );

		Ret = TST_CompararInt( CondRetEsperada, CondRetObtido, "Retorno errado ao obter codigo da peca." );
 
		if ( Ret != TST_CondRetOK )
            {
               return Ret ;
            } /* if */

		return TST_CompararInt( ValorCodigoEsperado, ValorCodigoObtido, "Codigo obtido esta errado.");
	} /* fim ativa : Testar PECA Obter Codigo da Peca */

	/* Testar PECA Mudar Codigo da Peca */
	else if ( strcmp( ComandoTeste, MUDAR_CODIGO_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ci", &ValorCodigoDado, &CondRetEsperada );
		if ( NumLidos != 2 )
		{
			return TST_CondRetParm;
		} /* if */

		CondRetObtido = PEC_MudarCodigoPeca ( &pPeca, ValorCodigoDado );

		return TST_CompararInt( CondRetEsperada, CondRetObtido, "Retorno errado ao mudar o codigo da peca." );
	} /* fim ativa : Testar PECA Mudar Codigo da Peca */

	return TST_CondRetNaoConhec ;

	} /* Fim fun��o: TPEC Efetuar opera��es de teste espec�ficas para o m�dulo pe�a */

/********** Fim do m�dulo de implementa��o: TPEC M�dulo de teste espec�fico para Pe�a **********/

