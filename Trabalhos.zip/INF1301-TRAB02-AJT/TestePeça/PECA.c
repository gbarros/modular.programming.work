/**********************************************************************************************************
*
*  -> M�dulo de implementa��o: PEC M�dulo de pe�as gen�ricas
*
*  Arquivo gerado: PECA.c
*  Letras identificadoras: PEC
*
*  Autores: tr - Tadeu Ribeiro
*			ag - Alexandre Garcia
*			jc - Jocimar Candido
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      tr, al, jc   22/set/2012    in�cio do desenvolvimento
*      1.1      tr, al, jc   30/set/2012    revis�o do m�dulo inteiro e implementa��o de manipuladores de c�digo
*      1.2      tr, al, jc   05/out/2012    corre��o da utiliza��o do malloc e aprimoramento das fun��es
*
**********************************************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <memory.h>
#include <malloc.h>
#include <assert.h>

#include "PECA1.h"
#include "PECA2.h"


#define N_NOMES 2
#define N_CORES 6

/***********************************************************************
*
*  Tipo de dados: PEC Estrutura de uma pe�a
*
***********************************************************************/

typedef struct PEC_tagPeca{

	PEC_tpNomePeca Nome;
		/* nome da pe�a */

	PEC_tpCorPeca Cor;
		/* cor da pe�a */
		
	char Codigo;
	    /* c�digo da pe�a */

}PEC_tpPeca;



/*****  C�digo das fun��es exportadas pelo m�dulo  *****/

/***************************************************************************
*
*  Fun��o: PEC Criar Peca
*
***************************************************************************/

PEC_tpCondRet PEC_CriarPeca ( PEC_tppPeca * pPeca, PEC_tpNomePeca nome , PEC_tpCorPeca cor , char codigo )
{
	/* Verifica a exist�ncia de uma pe�a j� criada */
	if ( (*pPeca) != NULL)
	{
		return PEC_CondRetErroEstrutura;
	} /* if */

	/* Verifica se o nome � v�lido */
	if( ( nome < 0 ) ||
		( nome > N_NOMES ) )
	{
		return PEC_CondRetNomeInexistente;
	} /* if */

	/* Verifica se a cor � v�lida */
	if( ( cor < 0 ) ||
		( cor > N_CORES ) )
	{
		return PEC_CondRetCorInexistente;
	} /* if */
	

	/* Aloca espa�o na mem�ria para a pe�a */
	(*pPeca) = ( PEC_tppPeca  ) malloc ( sizeof ( PEC_tpPeca ) );
	
	/* Verifica espa�o na mem�ria */
	if ( (*pPeca) == NULL )
	{
		return PEC_CondRetFaltouMemoria;
	} /* if */
	
	/* Faz as atribui��es */
	(*pPeca)->Nome = nome;
	(*pPeca)->Cor = cor;
	(*pPeca)->Codigo = codigo;
	
	return PEC_CondRetOK ;

}  /* Fim fun��o: PEC Criar Peca */



/***************************************************************************
*
*  Fun��o: PEC Destruir Peca
*
***************************************************************************/

PEC_tpCondRet PEC_ExcluirPeca (PEC_tppPeca * pPeca )
{
	if ( (*pPeca) != NULL )
	{
		free ( (*pPeca) ) ;
		(*pPeca) = NULL;
	}
	else
	{
		return PEC_CondRetPecaInexistente;
	} /* if */

	return PEC_CondRetOK ;

} /* Fim fun��o: PEC Destruir Peca */



/***************************************************************************
*
*  Fun��o: PEC Obter Nome Peca
*
***************************************************************************/


PEC_tpCondRet PEC_ObterNomePeca ( PEC_tppPeca * pPeca, PEC_tpNomePeca * nome )
{
	/* Verifica se a pe�a existe */
	if ( (*pPeca) == NULL )
	{
		return PEC_CondRetPecaInexistente;
	} /* if */

	/* Verifica se a pe�a possui nome */
	if ( (((*pPeca)->Nome) < 0)|| ((*pPeca)->Nome) > N_NOMES )
	{
		(*nome) = PEC_NomeSemNome ;
		return  PEC_CondRetNomeInexistente;
	} /* if */

	(*nome) = (*pPeca)->Nome ;
	
	return PEC_CondRetOK ;

} /* Fim fun��o: PEC Obter Nome Peca */



/***************************************************************************
*
*  Fun��o: PEC Mudar Nome Peca
*
***************************************************************************/

PEC_tpCondRet PEC_MudarNomePeca (PEC_tppPeca * pPeca, PEC_tpNomePeca nome)
{
	/* Verifica se a pe�a existe */
	if ( (*pPeca) == NULL )
	{
		return PEC_CondRetPecaInexistente;
	} /* if */

	/* Verifica se o nome � v�lido */
	if( ( nome < 0 ) ||
		( nome > N_NOMES ) )
	{
		return PEC_CondRetNomeInexistente ;
	} /* if */

	(*pPeca)->Nome = nome ;

	return PEC_CondRetOK ;

} /* Fim fun��o: PEC Mudar Nome Peca */



/***************************************************************************
*
*  Fun��o: PEC Obter Cor Peca
*
***************************************************************************/

PEC_tpCondRet PEC_ObterCorPeca ( PEC_tppPeca * pPeca, PEC_tpCorPeca * cor )
{
	/* Verifica se a pe�a existe */
	if ( (*pPeca) == NULL )
	{
		return PEC_CondRetPecaInexistente;
	} /* if */

	/* Verifica se a pe�a possui cor */
	if ( (((*pPeca)->Cor) < 0) || ((*pPeca)->Cor)> N_CORES )
	{
		(*cor) = PEC_CorSemCor ;
		return  PEC_CondRetCorInexistente;
	} /* if */

	(*cor) = (*pPeca)->Cor ;

	return PEC_CondRetOK ;

} /* Fim fun��o: PEC Obter Cor Peca */



/***************************************************************************
*
*  Fun��o: PEC Mudar Cor Peca
*
***************************************************************************/

PEC_tpCondRet PEC_MudarCorPeca (PEC_tppPeca * pPeca, PEC_tpCorPeca cor) 
{
	/* Verifica se a pe�a existe */
	if ( (*pPeca) == NULL )
	{
		return PEC_CondRetPecaInexistente;
	} /* if */
	
	/* Verifica se o nome � v�lido */
	if( ( cor < 0 ) ||
		( cor > N_CORES ) )
	{
		return PEC_CondRetCorInexistente ;
	} /* if */

	(*pPeca)->Cor = cor ;

	return PEC_CondRetOK ;

} /* Fim fun��o: PEC Mudar Cor Peca */



/***************************************************************************
*
*  Fun��o: PEC Obter Codigo Peca
*
***************************************************************************/

PEC_tpCondRet PEC_ObterCodigoPeca ( PEC_tppPeca * pPeca, char * codigo )
{
	/* Verifica se a pe�a existe */
	if ( (*pPeca) == NULL )
	{
		return PEC_CondRetPecaInexistente;
	} /* if */

	/* Verifica se a pe�a possui codigo */
	if ( ((*pPeca)->Codigo) == NULL )
	{
		return  PEC_CondRetCodigoInexistente;
	} /* if */

	(*codigo) = (*pPeca)->Codigo ;

	return PEC_CondRetOK ;

} /* Fim fun��o: PEC Obter Codigo Peca */



/***************************************************************************
*
*  Fun��o: PEC Mudar Codigo Peca
*
***************************************************************************/

PEC_tpCondRet PEC_MudarCodigoPeca (PEC_tppPeca * pPeca, char codigo) 
{
	/* Verifica se a pe�a existe */
	if ( (*pPeca) == NULL )
	{
		return PEC_CondRetPecaInexistente;
	} /* if */

	(*pPeca)->Codigo = codigo ;

	return PEC_CondRetOK ;

} /* Fim fun��o: PEC Mudar Codigo Peca */



/********** Fim do m�dulo de implementa��o: PEC M�dulo de pe�as gen�ricas **********/