/***************************************************************************
*  -> M�dulo de implementa��o: TTAB M�dulo de teste espec�fico para pilha
*
*  Arquivo gerado: TEST_PI.C
*  Letras identificadoras: TTAB
*
*  Autores: ac - Ana Carolina
*			km - Kaury Miranda
*			rd - Rodrigo Dugin
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      ac, km, rd   09/maio/2013    in�cio do desenvolvimento
*      
*
*  -> Descri��o do m�dulo:
*     Este m�dulo cont�m as fun��es espec�ficas para o teste do
*     m�dulo pilha.
*
*  -> Interface com o usu�rio pessoa:
*     Comandos de teste espec�ficos para testar o m�dulo pilha:
*
*
*       
*		"=criar"		     - chama a fun��o PI_CriarPilha( )
*		"=destruir"          - chama a fun��o PI_DestruirPilha( )
*		"=desempilhar"       - chama a fun��o PI_PopElem( )
*		"=empilhar"          - chama a fun��o PI_PushElem( )
*		"=obter"		     - chama a fun��o PI_ObterElem( ) 
*       "=exibir"		     - chama a fun��o PI_ExibirPilha( ) 
***************************************************************************/


#include    <string.h>
#include    <stdio.h>
#include    <malloc.h>

#include    "TST_Espc.h"

#include    "Generico.h"
#include    "LerParm.h"

#include    "PILHA.h"


/* Tabela dos nomes dos comandos de teste espec�ficos */

#define     RESET_CMD		       "=reset"
#define     CRIAR_CMD              "=criar"
#define     DESTROI_CMD            "=destruir"
#define     POP_CMD                "=desempilhar"
#define     PUSH_CMD               "=empilhar"
#define     OBTER_CMD		       "=obter"
#define     EXIBIR_CMD		       "=exibir"

#define TRUE  1
#define FALSE 0

#define VAZIO     0
#define NAO_VAZIO 1


#define DIM_VT_PILHA  10
#define DIM_VALOR     100


 PI_tppPilha   vtPilhas[ DIM_VT_PILHA ] ;

/***** Prot�tipos das fun��es encapuladas no m�dulo *****/


   static int ValidarInxPilha( int inxPilha , int Modo ) ;

   
/*****  C�digo das fun��es exportadas pelo m�dulo  *****/


/***********************************************************************
*
*  -> Fun��o: TPI Efetuar opera��es de teste espec�ficas para pilha
*
*  -> Descri��o da fun��o:
*     Efetua os diversos comandos de teste espec�ficos para o m�dulo
*     pilha sendo testado.
*
*  -> Par�metros:
*     ComandoTeste - String contendo o comando
*
*  -> Valor retornado:
*     Ver TST_tpCondRet definido em TST_ESPC.H
*
***********************************************************************/




TST_tpCondRet TST_EfetuarComando( char * ComandoTeste )
{
	
	

	 int inxPilha  = -1 ;
	

	PI_tpCondRet PiCondRetObtido = PI_CondRetOK;
	PI_tpCondRet PiCondRetEsperada = PI_CondRetFaltouMemoria;
	/* inicializa para qualquer coisa */
	

	int NumElem;
	
	char ValorConteudoDado = '\0';
	char ValorConteudoEsperado = '?';
	
	char* Elem;

	int NumLidos = -1;
	int i;


	
	
	
	
      /* Efetuar reset de teste de pilha */

         if ( strcmp( ComandoTeste , RESET_CMD ) == 0 )
         {

            for( i = 0 ; i < DIM_VT_PILHA ; i++ )
            {
               vtPilhas[ i ] = NULL ;
            } /* for */

            return TST_CondRetOK ;

         } /* fim ativa: Efetuar reset de teste de pilha */

	/* Testar PILHA Criar Pilha */

	if ( strcmp( ComandoTeste, CRIAR_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ii", &inxPilha,&NumElem );
		if ( ( NumLidos != 2 ) || ( ! ValidarInxPilha( inxPilha , VAZIO )))
            {
               return TST_CondRetParm ;
            } /* if */

		vtPilhas[inxPilha] = PI_CriarPilha(NumElem);

		return TST_CompararPonteiroNulo( 1 , vtPilhas[inxPilha] ,
               "Erro em ponteiro de nova pilha."  ) ;

	} /* fim ativa : Testar PILHA Criar Pilha */


	/* Testar PILHA Destruir Pilha */

	if ( strcmp( ComandoTeste, DESTROI_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros( "ii" ,
			&inxPilha, &PiCondRetEsperada ) ;

		if ( ( NumLidos != 2 )
              || ( ! ValidarInxPilha( inxPilha , NAO_VAZIO )))
            {
               return TST_CondRetParm ;
            } /* if */

          PiCondRetObtido =  PI_DestruirPilha( vtPilhas[ inxPilha ] ) ;
            vtPilhas[ inxPilha ] = NULL ;
			

			return TST_CompararInt ( PiCondRetEsperada , PiCondRetObtido, "Retorno errado ao destruir Pilha." );


	} /* fim ativa : Testar PILHA Destruir Pilha */


	/* Testar PILHA Desempilhar Elemento */

	if ( strcmp( ComandoTeste, POP_CMD     ) == 0 )
	{
		
		NumLidos = LER_LerParametros( "ii" ,
			&inxPilha, &PiCondRetEsperada ) ;

		if ( ( NumLidos != 2 )
              || ( ! ValidarInxPilha( inxPilha , NAO_VAZIO )))
            {
               return TST_CondRetParm ;
            } /* if */

		PiCondRetObtido = PI_PopElem(vtPilhas[inxPilha]);

		return TST_CompararInt ( PiCondRetEsperada , PiCondRetObtido, "Retorno errado ao desempilhar elemento." );

	} /* fim ativa : Testar PILHA Desempilhar Elemento */


	/* Testar PILHA Empilha Elemento */

	if ( strcmp( ComandoTeste, PUSH_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ici",&inxPilha,&ValorConteudoDado, &PiCondRetEsperada );
		if ( ( NumLidos != 3 )
              || ( ! ValidarInxPilha( inxPilha , NAO_VAZIO )))
            {
               return TST_CondRetParm ;
            } /* if */

		

		PiCondRetObtido = PI_PushElem(vtPilhas[inxPilha],&ValorConteudoDado);
		
		return TST_CompararInt ( PiCondRetEsperada , PiCondRetObtido, "Retorno errado ao empilhar elemento." );

		
		

		

	} /* fim ativa : Testar PILHA Empilhar Elemento */


	/* Testar PILHA Obter Elemento */

	if ( strcmp( ComandoTeste, OBTER_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ic",&inxPilha, &ValorConteudoDado);
		if ( ( NumLidos != 2 )
              || ( ! ValidarInxPilha( inxPilha , NAO_VAZIO )))
            {
               return TST_CondRetParm ;
            } /* if */

		

		

		Elem = (char*)PI_ObterElemTopo(vtPilhas[inxPilha]);
		if( Elem == NULL)
			return TST_CondRetErro;
		
		 return TST_CompararChar(ValorConteudoDado, *Elem, "Conteudo obtido diferente do da pilha");

		

	} /* fim ativa : Testar PILHA Obter Elemento */



	/* Testar PILHA Exibir Pilha */

	if ( strcmp( ComandoTeste, EXIBIR_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "ii",&inxPilha ,&PiCondRetObtido);
		if ( ( NumLidos != 2 )
              || ( ! ValidarInxPilha( inxPilha , NAO_VAZIO )))
            {
               return TST_CondRetParm ;
            } /* if */

		

		

		PiCondRetEsperada =  PI_ExibirPilha(vtPilhas[inxPilha]);
		
		
		 return TST_CompararInt ( PiCondRetEsperada , PiCondRetObtido, "Retorno errado ao exibir pilha." );


	} /* fim ativa : Testar PILHA Exibir Pilha */

	return TST_CondRetNaoConhec ;

   } /* Fim fun��o: TPI &Testar pilha */


	
	

	/*****  C�digo das fun��es encapsuladas no m�dulo  *****/




/***********************************************************************
*
*  $FC Fun��o: TPI -Validar indice de lista
*
***********************************************************************/

   int ValidarInxPilha( int inxPilha , int Modo )
   {
   

      if ( (  inxPilha <  0 ) || (  inxPilha >= DIM_VT_PILHA ))
	  {
         return FALSE ;
       /* if */
	  }
         
      if ( Modo == VAZIO )
	  {
      
         if ( vtPilhas[  inxPilha ] != 0 )
		 {
            return FALSE ;
		 }
	  }
          /* if */
       else
	   {
         if ( vtPilhas[  inxPilha ] == 0 )
		 {
         
           return FALSE ;
		 }
          /* if */
	  }
       /* if */
         
      return TRUE ;

   }

    /* Fim fun��o: TLIS -Validar indice de lista */




   


/********** Fim do m�dulo de implementa��o: TPI M�dulo de teste espec�fico para pilha **********/

