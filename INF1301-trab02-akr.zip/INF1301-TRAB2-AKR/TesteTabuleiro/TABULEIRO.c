/**********************************************************************************************************
*
*  -> M�dulo de implementa��o: TAB M�dulo de tabuleiro gen�rico
*
*  Arquivo gerado:             TABULEIRO.c
*  Letras identificadoras:     TAB
*
*  Autores: ac - Ana Carolina
*			km - Kaury Miranda
*			rd - Rodrigo Dugin
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      ac, km, rd   19/abril/2013    in�cio do desenvolvimento
*      1.1      ac, km, rd   29/abril/2013    implementa��o das explica��es, assertivas e dos prot�tipos das fun��es
*      1.2      ac, km, rd   08/maio/2013     revis�o/modifica��o da vers�o anterior e implementa��o das fun��es
*      1.3      ac, km, rd   09/maio/2013     revis�o/corre��o das fun��es
* 
**********************************************************************************************************/

#include   <stdlib.h>
#include   <stdio.h>
#include   <string.h>
#include   <memory.h>
#include   <malloc.h>
#include   <assert.h>

#include   "TABULEIRO.h"




/***********************************************************************
*
*  Tipo de dados: TAB Estrutura de uma casa
*
***********************************************************************/

typedef struct TAB_tagCasa{

	PI_tppPilha Pilha;
		/* pilha que ir� ocupar a casa */


}TAB_tpCasa;

/***********************************************************************
*
*  Tipo de dados: TAB Estrutura de um tabuleiro
*
***********************************************************************/

typedef struct TAB_tagTabuleiro{

	int NumLinhas;
		/* n�mero de linhas do tabuleiro */

	int NumColunas;
		/* n�mero de colunas do tabuleiro */

	TAB_tpCasa * Tab;
		/* matriz de casas representada por um vetor a ser inicializada. Para acessar o elemento ij da matriz deve-se fazer: v[i*NumLinhas + j] */

}TAB_tpTabuleiro;


/***********************************************************************
*
*  Fun��o: TAB Criar Tabuleiro
*
***********************************************************************/

TAB_tpCondRet TAB_CriarTabuleiro (TAB_tppTabuleiro * pTab, int NumLinhas, int NumColunas)
{
	int i, j; //indices para percorrer a matriz
	
	/* Verifica a exist�ncia de um tabuleiro j� criado */
	if ( (*pTab) != NULL)
	{
		return TAB_CondRetErroEstrutura;
	} /* if */

	/* Aloca espa�o na mem�ria para o tabuleiro */
	(*pTab) = ( TAB_tppTabuleiro ) malloc ( sizeof( TAB_tpTabuleiro ) ) ;

	/* Verifica espa�o na mem�ria */
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetFaltouMemoria ;
	} /* If */

	/* Faz as atribui��es */
	(*pTab)->NumLinhas = NumLinhas;
	(*pTab)->NumColunas = NumColunas;
	(*pTab)->Tab = ( TAB_tppCasa) malloc ( NumLinhas * NumColunas * sizeof( TAB_tpCasa) ) ;

	/* incializa as casas */

	for ( i=0; i<NumLinhas; i++)
	
		for ( j=0; j<NumColunas; j++)
		
			(*pTab)->Tab[i*NumLinhas+j].Pilha=NULL;
			
	

	return TAB_CondRetOK ;

} /* Fim fun��o: TAB Criar Tabuleiro */



/***********************************************************************
*
*  Fun��o: TAB Destruir Tabuleiro
*
***********************************************************************/

TAB_tpCondRet TAB_DestruirTabuleiro (TAB_tppTabuleiro * pTab)
{
    int i, j; //indices para percorrer a matriz
	PI_tpCondRet piRet;
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	}/* if */
	for ( i=0; i<(*pTab)->NumLinhas; i++)
	{
		for ( j=0; j<(*pTab)->NumColunas; j++)
		{
			if ( (*pTab)->Tab[i*(*pTab)->NumLinhas+j].Pilha != NULL )
			{
				piRet = PI_DestruirPilha((*pTab)->Tab[i*(*pTab)->NumLinhas+j].Pilha);
			}
		}
	}
	free( (*pTab)->Tab );
	free( (*pTab) );
	
	(*pTab) = NULL;
	
	return TAB_CondRetOK ;

} /* Fim fun��o: TAB Destruir Tabuleiro */



/***********************************************************************
*
*  Fun��o: TAB Exibir Tabuleiro
*
***********************************************************************/

TAB_tpCondRet TAB_ExibirTabuleiro (TAB_tppTabuleiro * pTab)
{
	int i, j; //indices para percorrer a matriz
	
	char *elem;

	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Desenha o tabuleiro na tela */
	printf("\n   ");
	for (j=0; j<(*pTab)->NumColunas; j++)
	{
		printf("%d ", j);
	}
	printf("\n   ");
	for (j=0; j<(*pTab)->NumColunas; j++)
	{
		printf("_ ");
	}

	for ( i=0; i<(*pTab)->NumLinhas; i++)
	{
		printf("\n%d| ", i);
		for ( j=0; j<(*pTab)->NumColunas; j++)
		{
			if ( (*pTab)->Tab[i*(*pTab)->NumLinhas+j].Pilha != NULL )
			{
				elem = (char*)PI_ObterElemTopo((*pTab)->Tab[i*(*pTab)->NumLinhas+j].Pilha);
				printf("%c ", *elem);
			}
			else
			{
				printf("  ");
			}
		}
	}

	return TAB_CondRetOK ;

} /* Fim fun��o: TAB Exibir Tabuleiro */



/***********************************************************************
*
*  Fun��o: TAB Obter Conteudo Casa
*
***********************************************************************/

TAB_tpCondRet TAB_ObterConteudoCasa ( TAB_tppTabuleiro * pTab,  int CoordLinha, int CoordColuna, void *ConteudoCasa) 
{
	
	
	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Verifica se a coordenada existe */
	if ((CoordLinha>=(*pTab)->NumLinhas)||(CoordColuna>=(*pTab)->NumColunas))
	{
		return TAB_CondRetErroEstrutura;
	}

	/* Verifica se a pilha existe */	
	if ( (*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Pilha == NULL )
	{
		return TAB_CondRetPilhaInexistente;
	}
	else
	{
	    
		ConteudoCasa = PI_ObterElemTopo((*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Pilha);
		
	}
	
	return TAB_CondRetOK ;
	
} /* Fim fun��o: TAB Obter Conteudo Casa */


/***********************************************************************
*
*  Fun��o: TAB Inserir Elemento
*
***********************************************************************/

TAB_tpCondRet TAB_InserirElemento (TAB_tppTabuleiro * pTab, void* Elem , int CoordLinha, int CoordColuna) 
{
	PI_tpCondRet piRet;
	PI_tppPilha  pPilha = NULL;
	


	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Verifica se a coordenada existe */
	if ((CoordLinha>=(*pTab)->NumLinhas)||(CoordColuna>=(*pTab)->NumColunas)){
	
		return TAB_CondRetErroEstrutura;
}
	/* Verifica se a pilha existe */
	if ( (*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Pilha == NULL )
	{
		/* Cria uma nova pilha e acrescenta o elemento */
		pPilha = PI_CriarPilha(Pilha_MAX);
		piRet = PI_PushElem(pPilha,Elem);
		(*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Pilha = pPilha;

		if(piRet != PI_CondRetOK)
		{
		return TAB_CondRetErroPilha;
		}
			return TAB_CondRetOK;
	

	} /* if */

	
		/* Acrescenta um novo elemento na pilha existente */
		piRet = PI_PushElem(pPilha,Elem);
	(*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Pilha = pPilha;
	
	if(piRet != PI_CondRetOK)
	
		return TAB_CondRetErroPilha;
	
	
	
	return TAB_CondRetOK ;
	
} /* Fim fun��o: TAB Inserir Elemento */


/***********************************************************************
*
*  Fun��o: TAB Retirar Elemento
*
***********************************************************************/

TAB_tpCondRet TAB_RetirarElemento (TAB_tppTabuleiro * pTab, int CoordLinha, int CoordColuna) 
{
	PI_tpCondRet piRet;
	PI_tppPilha pPilha = NULL;
	

	/* Verifica se o tabuleiro existe */	
	if ( (*pTab) == NULL )
	{
		return TAB_CondRetTabInexistente;
	} /* if */

	/* Verifica se a coordenada existe */
	if ((CoordLinha>=(*pTab)->NumLinhas)||(CoordColuna>=(*pTab)->NumColunas))
	{
		return TAB_CondRetErroEstrutura;
	}

	/* Verifica se a pilha existe */	
	if ( (*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Pilha == NULL )
	{
		return TAB_CondRetPilhaInexistente;
	} /* if */
	else
	{

		
	                 /* Desempilha o elemento do topo da pilha */
			piRet = PI_PopElem((*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Pilha);

			if(piRet != PI_CondRetOK)
	
		return TAB_CondRetErroPilha;

			 /* Se a pilha conter um ou mais elementos, retorna OK */
			if( ((*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Pilha) != NULL)
				return TAB_CondRetOK;
	
		
		
			/* Se n�o, a destroi */

	piRet = PI_DestruirPilha(((*pTab)->Tab[CoordLinha*(*pTab)->NumLinhas+CoordColuna].Pilha));
	
	
	
	if(piRet != PI_CondRetOK)
	{
		return TAB_CondRetErroPilha;
	}

	}
	return TAB_CondRetOK ;
	
} /* Fim fun��o: TAB Retirar Elemento */



/********** Fim do m�dulo de implementa��o: TAB Tabuleiro gen�rico **********/


