#if ! defined( TABULEIRO_ )
#define TABULEIRO_
/**********************************************************************************************************
*
*  -> M�dulo de defini��o: TAB M�dulo de tabuleiro de pilhas gen�rico
*
*  Arquivo gerado:         TABULEIRO.h
*  Letras identificadoras: TAB
*
*  Autores: ac - Ana Carolina
*			km - Kaury Miranda
*			rd - Rodrigo Dugin
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      ac, km, rd   19/abril/2013    in�cio do desenvolvimento
*      1.1      ac, km, rd   29/abril/2013    implementa��o das explica��es, assertivas e dos prot�tipos das fun��es
*      1.2      ac, km, rd   08/maio/2013     revis�o/modifica��o da vers�o anterior e implementa��o das fun��es
*      1.3      ac, km, rd   09/maio/2013     revis�o/corre��o das fun��es
*      
*
*  -> Descri��o do m�dulo:
*     Este m�dulo implementa um conjunto de fun��es que manipulam um tabuleiro de pilhas gen�rico para 
*     que possa ser utilizado futuramente em qualquer tipo de jogo de tabuleiro com elementos empilhados.
*     
**********************************************************************************************************/

#if defined( TABULEIRO_OWN )
   #define TABULEIRO_EXT
#else
   #define TABULEIRO_EXT extern
#endif

#include "PILHA.h"


#define Pilha_MAX 10

/***** Declara��es exportadas pelo m�dulo *****/

/* Tipo refer�ncia para uma casa */

typedef struct TAB_tagCasa * TAB_tppCasa ;


/* Tipo refer�ncia para um tabuleiro */

typedef struct TAB_tagTabuleiro * TAB_tppTabuleiro ;

/***********************************************************************
*
*  Tipo de dados: TAB Condi��es de retorno
*
*  Descri��o do tipo:
*     Condi��es de retorno das fun��es do m�dulo tabuleiro
*
*  Fun��es por N�mero:      
*        CriarTabuleiro     = 1 
*        DestruirTabuleiro  = 2 
*        ExibirTabuleiro    = 3 
*        ObterConteudoCasa  = 4 
*        InserirElemento    = 5 
*        RetirarElemento    = 6
*
***********************************************************************/

   typedef enum {

         TAB_CondRetOK ,
               /* Concluiu corretamente */
			   /* Fun��es que utilizam : 1, 2, 3, 4, 5, 6 */

         TAB_CondRetFaltouMemoria ,
               /* Faltou mem�ria ao tentar criar o tabuleiro */
			   /* Fun��es que utilizam : 1 */

		TAB_CondRetErroEstrutura ,
               /* Tabuleiro j� existe */
               /* Fun��es que utilizam : 1, 4, 5, 6 */

		 TAB_CondRetTabInexistente ,
               /* Tabuleiro inv�lido ou inexistente (N�o foi criado) */
			   /* Fun��es que utilizam : 2, 3, 4, 5, 6 */
				 
	     TAB_CondRetPilhaInexistente ,
               /* Pilha inexistente ou vazia  */
			   /* Fun��es que utilizam :  6 */

		 TAB_CondRetErroPilha
               /* Erro ao utilizar uma fun��o da estrutura Pilha */
			   /* Fun��es que utilizam : 4, 5, 6 */


   } TAB_tpCondRet ;


/***********************************************************************
*
*  -> Fun��o: TAB Criar Tabuleiro
*
*  -> Descri��o da fun��o:
*     Cria um tabuleiro quadrado com um dado n�mero de linhas e colunas.
*
*  -> Par�metros:
*	  pTab		      - Ponteiro para o tabuleiro.
*	  NumLinhas		  - N�mero de linhas que o tabuleiro a ser criado 
*                       deve conter.
*	  NumColunas	  - N�mero de colunas que o tabuleiro a ser criado 
*                       deve conter.
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetFaltouMemoria
*	  TAB_CondRetErroEstrutura
*
*  -> Assertivas:
*	  Entrada - Recebe o ponteiro para o tipo tabuleiro, por refer�ncia, a ser criado juntamente 
*     com os tipos int NumLinhas e int NumColunas. Estes ser�o os atributos n�mero de 
*     linhas e n�mero de colunas a preencherem a estrutura do tabuleiro. 
*
*     Sa�da - Se executou corretamente retorna, por refer�ncia, o tabuleiro
*     com o n�mero de linhas e n�mero de colunas passados como par�metros associados. 
*
***********************************************************************/

TAB_tpCondRet TAB_CriarTabuleiro (TAB_tppTabuleiro * pTab, int NumLinhas, int NumColunas) ;

/***********************************************************************
*
*  -> Fun��o: TAB Destruir Tabuleiro
*
*  -> Descri��o da fun��o:
*     Destr�i o tabuleiro liberando toda mem�ria utilizada por aquela 
*     estrutura.
*
*  -> Par�metros:
*	  pTab		  - Ponteiro para o tabuleiro.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe o ponteiro para a estrutura tabuleiro, por refer�ncia, que utilizou e alocou
*     mem�ria e que se deseja destruir.
*
*     Sa�da - Retorna o tabuleiro por refer�ncia, desalocado, com toda mem�ria utilizada pela 
*     estrutura do tabuleiro sendo liberada.
*     Caso o tabuleiro n�o exista retorna o retorno correspondente.
*
***********************************************************************/

TAB_tpCondRet TAB_DestruirTabuleiro (TAB_tppTabuleiro * pTab) ;

/***********************************************************************
*
*  -> Fun��o: TAB Exibir Tabuleiro
*
*  -> Descri��o da fun��o:
*     Imprime o tabuleiro na tela com ou sem elementos conforme o tipo de 
*     jogo e da situa��o durante uma partida.
*
*  -> Par�metros:
*	  pTab		  - Ponteiro para o tabuleiro.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*
*  -> Assertivas:
*	  Entrada - Recebe o ponteiro para a estrutura tabuleiro, por refer�ncia, que ir� exibir na tela.
*
*     Sa�da - Exibe o tabuleiro com todas as casas e seus respectivos conte�dos.
*     Caso o tabuleiro n�o exista retorna o retorno correspondente.
*
***********************************************************************/

TAB_tpCondRet TAB_ExibirTabuleiro (TAB_tppTabuleiro * pTab) ;

/***********************************************************************
*
*  -> Fun��o: TAB Obter Conteudo Casa
*
*  -> Descri��o da fun��o:
*     Obt�m o ponteiro para o elemento procurado.
*
*  -> Par�metros:
*	  pTab		   - Ponteiro para o tabuleiro.
*	  CoordLinha   - Coordenada x (linha) da casa em quest�o.
*	  CoordColuna  - Coordenada y (coluna) da casa em quest�o.
*     ConteudoCasa - Ponteiro que receber�, por refer�ncia, o conte�do
*                    da casa em quest�o.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*     TAB_CondRetErroEstrutura
*     TAB_CondRetErroPilha
*
*  -> Assertivas:
*	  Entrada - Recebe uma posi��o no tabuleiro pelos par�metros CoordLinha 
*     e CoordColuna juntamente com um ponteiro  que ir� guardar a informa��o obtida.
*
*     Sa�da - Retorna, por refer�ncia a situa��o da casa .
*     Se a casa estiver vazia, no par�metro ConteudoCasa retorna NULL . Se ela estiver 
*     ocupada, retorna, por refer�ncia, o elemento do topo da pilha.
*
***********************************************************************/

TAB_tpCondRet TAB_ObterConteudoCasa ( TAB_tppTabuleiro * pTab, int CoordLinha, int CoordColuna, void *ConteudoCasa) ;

/***********************************************************************
*
*  -> Fun��o: TAB Inserir Elemento
*
*  -> Descri��o da fun��o:
*     Insere um elemento na pilha numa dada coordenada do tabuleiro.
*
*  -> Par�metros:
*	  pTab		   - Ponteiro para o tabuleiro.
*	  pElem	       - Ponteiro para o elemento a ser inserido.
*	  CoordLinha   - Coordenada x (linha) da casa onde se deseja inserir o elemento.
*	  CoordColuna  - Coordenada y (coluna) da casa onde se deseja inserir o elemento.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*     TAB_CondRetErroPilha
*	  TAB_CondRetErroEstrutura
*
*  -> Assertivas:
*	  Entrada - Recebe uma posi��o no tabuleiro pelos par�metros CoordLinha e CoordColuna
*     onde se deseja inserir o elemento na pilha no tabuleiro pTab,  recebido
*     por refer�ncia.
*
*     Sa�da - Retorna o tabuleiro, por refer�ncia, com o elemento  incluso nas coordenadas
*     CoordLinha e CoordColuna do tabuleiro. Caso contr�rio retorna a condi��o de retorno correspondente.
*
***********************************************************************/

TAB_tpCondRet TAB_InserirElemento (TAB_tppTabuleiro * pTab, void * pElem, int CoordLinha, int CoordColuna) ;

/***********************************************************************
*
*  -> Fun��o: TAB Retirar Elemento
*
*  -> Descri��o da fun��o:
*     Retira o elemento do topo da pilha contido numa dada coordenada do tabuleiro.
*
*  -> Par�metros:
*	  pTab		   - Ponteiro para o tabuleiro.
*	  CoordLinha   - Coordenada x (linha) da casa onde se deseja retirar um elemento.
*	  CoordColuna  - Coordenada y (coluna) da casa onde se deseja retirar um elemento.
*
*  -> Valor retornado:
*     TAB_CondRetOK
*	  TAB_CondRetTabInexistente
*     TAB_CondRetPilhaInexistente
*	  TAB_CondRetErroEstrutura
*	  TAB_CondRetErroPilha
*
*  -> Assertivas:
*	  Entrada - Recebe uma posi��o no tabuleiro pelos par�metros CoordLinha e CoordColuna de
*     onde se deseja retirar um elemento da pilha contido no tabuleiro passado por refer�ncia.
*
*     Sa�da - Retorna o tabuleiro, por refer�ncia, com o elemento da pilha exclu�da das coordenadas
*     CoordLinha e CoordColuna fornecidas. Caso contr�rio retorna a condi��o de retorno correspondente.
*
***********************************************************************/

TAB_tpCondRet TAB_RetirarElemento (TAB_tppTabuleiro * pTab, int CoordLinha, int CoordColuna) ;



#undef TABULEIRO_EXT

/********** Fim do m�dulo de defini��o: TAB M�dulo de tabuleiro gen�rico **********/

#else
#endif
