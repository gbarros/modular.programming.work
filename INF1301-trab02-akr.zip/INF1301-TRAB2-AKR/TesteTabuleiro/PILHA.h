#if ! defined( PILHA_ )
#define PILHA_
/***************************************************************************
*
*  -> M�dulo de defini��o:      PI  M�dulo de pilha gen�rica
*
*  Arquivo gerado:              PILHA.h
*  Letras identificadoras:      PI
*
*
*  Autores: ac - Ana Carolina
*			km - Kaury Miranda
*			rd - Rodrigo Dugin
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      ac, km, rd   19/abril/2013    in�cio do desenvolvimento
*      1.1      ac, km, rd   29/abril/2013    implementa��o das explica��es, assertivas e dos prot�tipos das fun��es
*      1.2      ac, km, rd   08/maio/2013     revis�o/modifica��o da vers�o anterior e implementa��o das fun��es
*
*  -> Descri��o do m�dulo
*     Esse modulo implementa fun��es para manipula��o de elementos em uma pilha do tipo gen�rica.
*     
*
***************************************************************************/


#if defined( PILHA_OWN )
   #define PILHA_EXT
#else
   #define PILHA_EXT extern
#endif






/***** Declara��es exportadas pelo m�dulo *****/

/* Tipo refer�ncia para uma pilha */

typedef struct PI_tagPilha * PI_tppPilha ;










/***********************************************************************
*
*  $TC Tipo de dados: PI Condi��es de retorno
*
*
*  $ED Descri��o do tipo
*     Condi��es de retorno das fun��es da pilha
*
***********************************************************************/

   typedef enum {

         PI_CondRetOK ,
               /* Concluiu corretamente */

         PI_CondRetPilhaVazia ,
               /* A pilha n�o cont�m elementos */

		 PI_CondRetPilhaCheia ,
		       /* A pilha est� cheia */

	     PI_CondRetFaltouMemoria,
               /* Faltou mem�ria ao tentar criar um elemento de pilha */
	     
	     PI_CondRetPilhaInvalida
			   /* A pilha n�o existe ou � inv�lida */

		 


   } PI_tpCondRet ;



/***********************************************************************
*
*  $FC Fun��o: PI  &Criar pilha
*
*  $ED Descri��o da fun��o
*     Cria uma pilha gen�rica usando uma lista duplamente encadeada.
*     Aloca a pilha, determina os limites m�nimos e maximos na mesma,
*     e certifica que est� vazia.
*     
*
*  $EP Par�metros
*     numElementos  - Inteiro com o n�mero de elementos
*                     que podem ser armazenados.
*     
*
*  $FV Valor retornado
*     Se executou corretamente, retorna a pilha.
*     
*
*     Se ocorreu algum erro, por exemplo falta de mem�ria ou dados errados,
*     a fun��o retornar� NULL.
*     N�o ser� dada mais informa��o quanto ao problema ocorrido.
*
***********************************************************************/

   PI_tppPilha PI_CriarPilha (int numElementos);




/***********************************************************************
*
*  $FC Fun��o: PI  &Destruir pilha
*
*  $ED Descri��o da fun��o
*     Destroi a pilha fornecida. Desaloca todo o espa�o da mem�ria 
*     reservado para a pilha.
*
*  $EP Par�metros
*     pPilha - ponteiro para a pilha a ser destruida
*
*   $FV Valor retornado
*     PI_CondRetOK
*     PI_CondRetPilhaInvalida
*
***********************************************************************/

   PI_tpCondRet   PI_DestruirPilha( PI_tppPilha  pPilha);





/***********************************************************************
*
*  $FC Fun��o: PI  &Desempilhar elemento
*
*  $ED Descri��o da fun��o
*     Retira um elemento do topo da pilha. Se a pilha n�o estiver vazia, 
*     decrementa o topo da pilha. 
*
*  $EP Par�metros
*     pPilha - ponteiro para a pilha
*   
*
*  $FV Valor retornado
*     PI_CondRetOK
*     PI_CondRetPilhaVazia
*     PI_CondRetPilhaInvalida
*
***********************************************************************/
    PI_tpCondRet PI_PopElem(PI_tppPilha  pPilha);


	
/***********************************************************************
*
*  $FC Fun��o: PI  &Empilhar elemento
*
*  $ED Descri��o da fun��o
*     Empilha o elemento recebido. Salva o elemento na pilha. 
*     Se a pilha n�o estiver cheia, avan�a o topo da lista para o 
*     pr�ximo ponto e copia a informa��o do novo elemento.
*
*  $EP Par�metros
*     pPilha - ponteiro para a pilha
*     pElem - ponteiro para o elemento que vai ser
*              armazenado.
*
*  $FV Valor retornado
*     PI_CondRetOK
*     PI_CondRetPilhaCheia
*     PI_CondRetPilhaInvalida
*
***********************************************************************/

	PI_tpCondRet PI_PushElem(PI_tppPilha  pPilha, void *pElem);


/***********************************************************************
*
*  $FC Fun��o: PI  &Obter elemento topo
*
*  $ED Descri��o da fun��o
*     V� um elemento do topo da pilha.
*
*  $EP Par�metros
*     pPilha - ponteiro para a pilha
*
*  $FV Valor retornado
*     
*     Retorna o elemento do topo da pilha, NUll caso a pilha esteja
*     vazia.
*
***********************************************************************/


	void* PI_ObterElemTopo(PI_tppPilha  pPilha);

	
/***********************************************************************
*
*  $FC Fun��o: PI  &Exibir pilha
*  
*   $ED Descri��o da fun��o
*     Exibe todos os elementos da pilha.
*
*  $EP Par�metros
*     pPilha - ponteiro para a pilha
*
*  $FV Valor retornado
*     
*    PI_CondRetOK
*    PI_CondRetPilhaInvalida
*    PI_CondRetPilhaVazia
*
***********************************************************************/


	PI_tpCondRet PI_ExibirPilha(PI_tppPilha  pPilha);


#undef PILHA_EXT

/********** Fim do m�dulo de defini��o: PI  Pilha **********/

#else
#endif
