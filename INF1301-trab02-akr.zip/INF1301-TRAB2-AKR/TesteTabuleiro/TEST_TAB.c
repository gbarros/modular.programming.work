/***************************************************************************
*  -> M�dulo de implementa��o: TTAB M�dulo de teste espec�fico para tabuleiro
*
*  Arquivo gerado: TEST_TAB.C
*  Letras identificadoras: TTAB
*
*  Autores: ac - Ana Carolina
*			km - Kaury Miranda
*			rd - Rodrigo Dugin
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      ac, km, rd   09/maio/2013    in�cio do desenvolvimento
*      
*
*  -> Descri��o do m�dulo:
*     Este m�dulo cont�m as fun��es espec�ficas para o teste do
*     m�dulo tabuleiro.
*
*  -> Interface com o usu�rio pessoa:
*     Comandos de teste espec�ficos para testar o m�dulo tabuleiro:
*
*		"=criar"		     - chama a fun��o TAB_CriarTabuleiro( )
*		"=destruir"          - chama a fun��o TAB_DestruirTabuleiro( )
*		"=exibir"            - chama a fun��o TAB_ExibirTabuleiro( )
*		"=obter"             - chama a fun��o TAB_ObterConteudoCasa( )
*		"=inserirelem"		 - chama a fun��o TAB_InserirElemento( ) 
*		"=retirarelem"       - chama a fun��o TAB_RetirarElemento( )
*
***************************************************************************/

#include    <string.h>
#include    <stdio.h>

#include    "TST_ESPC.H"

#include    "generico.h"
#include    "lerparm.h"

#include    "TABULEIRO.h"
#include    "PILHA.h"

/* Tabela dos nomes dos comandos de teste espec�ficos */

#define     CRIAR_TAB_CMD               "=criar"
#define     DESTROI_CMD                 "=destruir"
#define     EXIBIR_TAB_CMD              "=exibir"
#define     OBTER_CONTEUDOCASA_CMD      "=obter"
#define     INSERIR_ELEM_PILHA_CMD		"=inserirelem"
#define     RETIRAR_ELEM_PILHA_CMD		"=retirarelem"


/*****  C�digo das fun��es exportadas pelo m�dulo  *****/

/***********************************************************************
*
*  -> Fun��o: TTAB Efetuar opera��es de teste espec�ficas para tabuleiro
*
*  -> Descri��o da fun��o:
*     Efetua os diversos comandos de teste espec�ficos para o m�dulo
*     tabuleiro sendo testado.
*
*  -> Par�metros:
*     ComandoTeste - String contendo o comando
*
*  -> Valor retornado:
*     Ver TST_tpCondRet definido em TST_ESPC.H
*
***********************************************************************/

TAB_tppTabuleiro pTab = NULL;


TST_tpCondRet TST_EfetuarComando( char * ComandoTeste )
{
	PI_tppPilha  pPilha = NULL;

	PI_tpCondRet PiCondRetObtido = PI_CondRetOK;
	PI_tpCondRet PiCondRetEsperada = PI_CondRetFaltouMemoria;
	/* inicializa para qualquer coisa */
	TAB_tpCondRet TabCondRetObtido = TAB_CondRetOK;
	TAB_tpCondRet TabCondRetEsperada = TAB_CondRetFaltouMemoria;
	/* inicializa para qualquer coisa */

	int NumLinhas;
	int NumColunas;
	char ValorConteudoDado = '\0';
	char ValorConteudoEsperado = '?';
	char ValorConteudoObtido = '!';
	char ValorCodigoDado = '\0';

	int NumLidos = -1;

	TST_tpCondRet Ret;

	/* Testar TABULEIRO Criar Tabuleiro */

	if ( strcmp( ComandoTeste, CRIAR_TAB_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "iii", &NumLinhas, &NumColunas, &TabCondRetEsperada );
		if ( NumLidos != 3 )
		{
			return TST_CondRetParm;
		} /* if */

		TabCondRetObtido = TAB_CriarTabuleiro(&pTab , NumLinhas, NumColunas);

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao criar tabuleiro." );

	} /* fim ativa : Testar TABULEIRO Criar Tabuleiro */


	/* Testar TABULEIRO Destruir Tabuleiro */

	if ( strcmp( ComandoTeste, DESTROI_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "i", &TabCondRetEsperada );
		if ( NumLidos != 1 )
		{
			return TST_CondRetParm;
		} /* if */

		TabCondRetObtido = TAB_DestruirTabuleiro(&pTab);

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao excluir tabuleiro." );

	} /* fim ativa : Testar TABULEIRO Destruir Tabuleiro */


	/* Testar TABULEIRO Exibir Tabuleiro */

	if ( strcmp( ComandoTeste, EXIBIR_TAB_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "i", &TabCondRetEsperada );
		if ( NumLidos != 1 )
		{
			return TST_CondRetParm;
		} /* if */

		TabCondRetObtido = TAB_ExibirTabuleiro(&pTab);

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao exibir tabuleiro." );

	} /* fim ativa : Testar TABULEIRO Exibir Tabuleiro */


	/* Testar TABULEIRO Obter Conteudo da Casa Tabuleiro */

	if ( strcmp( ComandoTeste, OBTER_CONTEUDOCASA_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "iici", &NumLinhas, &NumColunas, &ValorConteudoEsperado, &TabCondRetEsperada );
		if ( NumLidos != 4 )
		{
			return TST_CondRetParm;
		} /* if */

		TabCondRetObtido = TAB_ObterConteudoCasa(&pTab, NumLinhas, NumColunas, &ValorConteudoObtido);

		Ret = TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao obter conteudo da casa no tabuleiro." );
		
		if ( Ret != TST_CondRetOK )
		{
			return Ret ;
		} /* if */

		return TST_CompararChar ( ValorConteudoEsperado , ValorConteudoObtido, "Conteudo da casa esta errado" );

	} /* fim ativa : Testar TABULEIRO Obter Conteudo da Casa Tabuleiro */


	/* Testar TABULEIRO Inserir um Elemento de uma Pilha Numa Casa Tabuleiro */

	if ( strcmp( ComandoTeste, INSERIR_ELEM_PILHA_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "iici", &NumLinhas, &NumColunas, &ValorConteudoDado,  &TabCondRetEsperada );
		if ( NumLidos != 4 )
		{
			return TST_CondRetParm;
		} /* if */

		
		TabCondRetObtido = TAB_InserirElemento ( &pTab, &ValorConteudoDado, NumLinhas, NumColunas);

		

		

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao colocar elemento no tabuleiro." );

	} /* fim ativa : Testar TABULEIRO Inserir um Elemento de uma Pilha Numa Casa Tabuleiro */


	/* Testar TABULEIRO Retirar um Elemento de uma Pilha Numa Casa Tabuleiro */

	if ( strcmp( ComandoTeste, RETIRAR_ELEM_PILHA_CMD ) == 0 )
	{
		NumLidos = LER_LerParametros ( "iii", &NumLinhas, &NumColunas, &TabCondRetEsperada );
		if ( NumLidos != 3 )
		{
			return TST_CondRetParm;
		} /* if */

		TabCondRetObtido = TAB_RetirarElemento(&pTab, NumLinhas, NumColunas);

		return TST_CompararInt ( TabCondRetEsperada , TabCondRetObtido, "Retorno errado ao retirar elemento do tabuleiro." );

	} /* fim ativa : Testar TABULEIRO Retirar um Elemento de uma Pilha Numa Casa Tabuleiro */

	return TST_CondRetNaoConhec;

}
/********** Fim do m�dulo de implementa��o: TTAB M�dulo de teste espec�fico para tabuleiro **********/

