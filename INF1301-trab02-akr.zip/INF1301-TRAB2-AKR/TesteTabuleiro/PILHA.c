/***************************************************************************
*
*  -> M�dulo de implementa��o:  PI  Pilha
*
*  Arquivo gerado:              PILHA.c
*  Letras identificadoras:      PI
*
*  Autores: ac - Ana Carolina
*			km - Kaury Miranda
*			rd - Rodrigo Dugin
*
*  -> Hist�rico de evolu��o:
*     Vers�o      Autor		    Data		Observa��es
*      1.0      ac, km, rd   19/abril/2013    in�cio do desenvolvimento
*      1.1      ac, km, rd   29/abril/2013    implementa��o das explica��es, assertivas e dos prot�tipos das fun��es
*      1.2      ac, km, rd   08/maio/2013     revis�o/modifica��o da vers�o anterior e implementa��o das fun��es
*
***************************************************************************/

#include   <stdio.h>
#include   <string.h>
#include   <memory.h>
#include   <malloc.h>
#include   <assert.h>

#define PILHA_OWN
#include "PILHA.h"
#include "LISTA.H"
#undef PILHA_OWN

/***********************************************************************
*
*  $TC Tipo de dados: PI Elemento da pilha
*
*
***********************************************************************/

   typedef struct PI_tagPilha {
	    /* Ponteiro para a lista onde guardar� a informa��o da pilha */
	   LIS_tppLista pLista;
	   
	   /* N�mero de Elementos de uma pilha */
	   int NumElementos; 

	   /* Posi��o atual do elemento na pilha */
	   int Pos;

        
   } PI_tpPilha ;
   

   /***** Prot�tipos das fun��es encapuladas no m�dulo *****/

   static void PI_EsvaziarPilha( PI_tppPilha  pPilha);

/*****  C�digo das fun��es exportadas pelo m�dulo  *****/


/***************************************************************************
*
*   Fun��o: PI &Criar Pilha
*****/


   PI_tppPilha PI_CriarPilha (int numElementos)
{
    PI_tpPilha *pPilha = NULL;
	
    // certifica que o tamanho e valido
    if (numElementos > 0) {

        // cria a estrutura de gerenciamento da pilha
        pPilha = (PI_tpPilha *) malloc(sizeof(PI_tpPilha));
        if (pPilha == NULL) {        // verifica se conseguiu alocar
            return (NULL);         // do contrario indica o erro
        }
        // salva as informacao de numero de elementos da pilha
		pPilha->NumElementos = numElementos;
		

        // cria a �rea de dados da pilha
		pPilha->pLista = LIS_CriarLista(NULL);
		if (pPilha->pLista == NULL) {  
            free(pPilha);             
                                    
            return NULL;          
        }

        

        // inicia a pilha
		
		PI_EsvaziarPilha(pPilha);

        // retorna a pilha
        return pPilha;
    }
    else {
        return NULL;              // do contrario indica o erro
    }
}
   /* Fim fun��o: PI  &Criar pilha */

/***************************************************************************
*
*   Fun��o: PI &Destruir Pilha
*****/

   PI_tpCondRet   PI_DestruirPilha( PI_tppPilha  pPilha)
   {
	   /* Verifica se h� elementos na Pilha */
	   if (pPilha->pLista != NULL)
    {
		
		LIS_DestruirLista(pPilha->pLista);
        if (pPilha != NULL)
        {
            free(pPilha);
            return PI_CondRetOK;
        }
    }
	   return PI_CondRetPilhaInvalida;
}
   /* Fim fun��o: PI  &Destruir pilha */

/***************************************************************************
*
*   Fun��o: PI  &Desempilhar elemento
*****/

   PI_tpCondRet PI_PopElem(PI_tppPilha pPilha)
   {
	   LIS_tpCondRet Ret;
	   
	   /* Verifica se a Pilha existe */
	    if( pPilha == NULL)
			   return PI_CondRetPilhaInvalida;
	   
	   /* Verifica se a Pilha est� vazia */
		if( pPilha->Pos < 0)
		   return PI_CondRetPilhaVazia;
    
	   /* Vai para o topo da pilha */
	   IrFinalLista(pPilha->pLista);
	   
	  /* Exclui o valor do topo da pilha */
	  Ret = LIS_ExcluirElemento(pPilha->pLista);

	  pPilha->Pos--;
    

    


    return ( PI_tpCondRet) Ret;
}

    /* Fim fun��o: PI  &Desempilhar elemento */

/***************************************************************************
*
*   Fun��o: PI &Empilhar elemento
*****/

   PI_tpCondRet PI_PushElem(PI_tppPilha  pPilha, void *pElem)
	   {
		   
		   PI_tpCondRet Ret;
		   /* Verifica se a Pilha existe */
		   if( pPilha == NULL)
			   return PI_CondRetPilhaInvalida;

		   if( pPilha->Pos >= pPilha->NumElementos-1)
			   return PI_CondRetPilhaCheia;
		   
		   IrFinalLista(pPilha->pLista);
		   
		   Ret = (PI_tpCondRet)LIS_InserirElementoApos(pPilha->pLista, pElem);

		   pPilha->Pos++;

		   return Ret;
    

	
}
   /* Fim fun��o: PI  &Empilhar elemento */

/***************************************************************************
*
*   Fun��o: PI  &Exibir Pilha
*****/
   PI_tpCondRet PI_ExibirPilha(PI_tppPilha  pPilha)
   {
	   int i = pPilha->Pos;
	   int j = pPilha->NumElementos;
	   int k = pPilha->NumElementos - pPilha->Pos -1;

	   char* pElem;

	   if (pPilha == NULL)
		   return PI_CondRetPilhaInvalida;

	   printf("\n");
	   if(i ==-1)
	   {
		   while(j != 0){
		   printf("|   |\n");
		   printf("----- \n");
		   j--;
		   }
		   return PI_CondRetPilhaVazia;
	   }
	   IrFinalLista(pPilha->pLista);


	   while(k != 0 ){
		   printf("|   |\n");
		   printf("----- \n");
		   k--;
		   }
	   while(i != -1)
	   {
		   pElem = (char*)LIS_ObterValor(pPilha->pLista);
		   printf("| %d |\n",*pElem);
		   printf("----- \n");
		   LIS_AvancarElementoCorrente(pPilha->pLista,-1);
		   i--;
		  
	   }
	   
	   return PI_CondRetOK;
   }

   /* Fim fun��o: PI  &Exibir pilha */

/***************************************************************************
*
*   Fun��o: PI  &Obter elemento
*****/


   void* PI_ObterElemTopo(PI_tppPilha  pPilha )
   {
	   
	   /* Verifica se h� elementos na pilha */
	   if(pPilha->Pos < 0)
		   return NULL;

	   IrFinalLista(pPilha->pLista);
	  return LIS_ObterValor(pPilha->pLista);
	   

   }
    /* Fim fun��o: PI  &Obter elemento */

   

/***********************************************************************
*
*  $FC Fun��o: PI  &Esvaziar pilha
*
*  $ED Descri��o da fun��o
*     Elimina todos os elementos, ao direcionar a posi��o atual de 
*     dados para -1 e chamando a fun��o LIS_EsvaziarLista.
*
*
*  $EP Par�metros
*     pPilha - ponteiro para a pilha a ser esvaziada
*
***********************************************************************/

 static  void   PI_EsvaziarPilha( PI_tppPilha pPilha)
   {
	   
		   LIS_EsvaziarLista(pPilha->pLista);

		   pPilha->Pos = -1;

		  

   }
	   
	/* Fim fun��o: PI  &Esvaziar Pilha */


   /********** Fim do m�dulo de implementa��o: PI  Pilha gen�rica**********/

